import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ArrowUp, Menu, X } from "lucide-react";

interface NavItem {
  id: string;
  label: string;
  icon?: string;
}

export default function QuickNav() {
  const [isVisible, setIsVisible] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("");

  const navItems: NavItem[] = [
    { id: "overview", label: "学习导航", icon: "🎯" },
    { id: "knowledge", label: "知识图谱", icon: "🕸️" },
    { id: "tasks", label: "任务卡片", icon: "📝" },
    { id: "tutorials", label: "教程", icon: "📷" },
    { id: "theory", label: "理论", icon: "📚" },
    { id: "examples", label: "案例", icon: "🖼️" },
    { id: "ai", label: "AI应用", icon: "✨" },
    { id: "works", label: "优秀作业", icon: "🏆" },
    { id: "resources", label: "拓展资源", icon: "🔗" }
  ];

  useEffect(() => {
    const toggleVisibility = () => {
      if (window.pageYOffset > 300) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    const handleScroll = () => {
      toggleVisibility();
      
      // Detect active section
      const sections = navItems.map(item => item.id);
      for (const sectionId of sections) {
        const element = document.getElementById(sectionId);
        if (element) {
          const rect = element.getBoundingClientRect();
          if (rect.top >= 0 && rect.top <= window.innerHeight / 2) {
            setActiveSection(sectionId);
            break;
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });
  };

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const offset = 80; // Account for fixed header
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
      setIsMenuOpen(false);
    }
  };

  return (
    <>
      {/* Quick Navigation Menu */}
      {isVisible && (
        <div className="fixed top-20 right-4 z-40 animate-in fade-in slide-in-from-right duration-300">
          {/* Menu Toggle Button */}
          <Button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="mb-2 shadow-lg"
            size="icon"
            variant={isMenuOpen ? "default" : "secondary"}
          >
            {isMenuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </Button>

          {/* Navigation Menu */}
          {isMenuOpen && (
            <div className="bg-white border-2 border-primary/20 rounded-lg shadow-xl p-2 space-y-1 max-h-[70vh] overflow-y-auto animate-in fade-in slide-in-from-right duration-200">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors flex items-center space-x-2 ${
                    activeSection === item.id
                      ? "bg-primary text-primary-foreground"
                      : "hover:bg-muted"
                  }`}
                >
                  <span>{item.icon}</span>
                  <span className="whitespace-nowrap">{item.label}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Back to Top Button */}
      {isVisible && (
        <Button
          onClick={scrollToTop}
          className="fixed bottom-8 right-4 z-40 shadow-lg animate-in fade-in slide-in-from-bottom duration-300"
          size="icon"
          variant="default"
        >
          <ArrowUp className="h-4 w-4" />
        </Button>
      )}
    </>
  );
}

