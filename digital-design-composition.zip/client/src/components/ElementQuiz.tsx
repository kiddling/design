import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Circle, Minus, Square, Check, X, RotateCcw, Trophy } from "lucide-react";

interface QuizQuestion {
  id: number;
  image: string;
  question: string;
  options: {
    type: "point" | "line" | "plane";
    label: string;
  }[];
  correctAnswer: "point" | "line" | "plane";
  explanation: string;
}

export default function ElementQuiz() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [quizCompleted, setQuizCompleted] = useState(false);

  const questions: QuizQuestion[] = [
    {
      id: 1,
      image: "🌟",
      question: "夜空中的星星在设计中属于什么元素？",
      options: [
        { type: "point", label: "点 - 视觉焦点" },
        { type: "line", label: "线 - 连接元素" },
        { type: "plane", label: "面 - 区域划分" }
      ],
      correctAnswer: "point",
      explanation: "星星是独立的、具有位置的视觉焦点，符合点的特征：小、聚焦、吸引注意力。"
    },
    {
      id: 2,
      image: "🌊",
      question: "海平线在构成中主要体现了什么元素？",
      options: [
        { type: "point", label: "点 - 视觉焦点" },
        { type: "line", label: "线 - 方向引导" },
        { type: "plane", label: "面 - 空间分割" }
      ],
      correctAnswer: "line",
      explanation: "海平线是一条水平线，具有方向性和延展性，将画面分为天空和海洋两部分，体现线的特征。"
    },
    {
      id: 3,
      image: "🏢",
      question: "建筑的墙面在设计中属于什么元素？",
      options: [
        { type: "point", label: "点 - 细节装饰" },
        { type: "line", label: "线 - 边缘轮廓" },
        { type: "plane", label: "面 - 主体结构" }
      ],
      correctAnswer: "plane",
      explanation: "墙面是具有面积和形状的二维区域，承载色彩和质感，是典型的面元素。"
    },
    {
      id: 4,
      image: "🎯",
      question: "靶心在视觉构成中主要是什么元素？",
      options: [
        { type: "point", label: "点 - 视觉中心" },
        { type: "line", label: "线 - 同心圆线" },
        { type: "plane", label: "面 - 圆形区域" }
      ],
      correctAnswer: "point",
      explanation: "靶心虽然有一定面积，但作为视觉中心和焦点，在构成中主要发挥点的作用：吸引注意力、标记位置。"
    },
    {
      id: 5,
      image: "🌈",
      question: "彩虹在设计构成中体现了什么元素？",
      options: [
        { type: "point", label: "点 - 色彩点缀" },
        { type: "line", label: "线 - 弧形线条" },
        { type: "plane", label: "面 - 色带区域" }
      ],
      correctAnswer: "line",
      explanation: "彩虹呈现为弧形线条，具有方向性和流动感，虽然有宽度但主要体现线的特征：方向、韵律、引导视线。"
    }
  ];

  const handleAnswer = (answer: "point" | "line" | "plane") => {
    setSelectedAnswer(answer);
    setShowResult(true);
    
    if (answer === questions[currentQuestion].correctAnswer) {
      setScore(score + 1);
    }
  };

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    } else {
      setQuizCompleted(true);
    }
  };

  const handleRestart = () => {
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setShowResult(false);
    setScore(0);
    setQuizCompleted(false);
  };

  const getElementIcon = (type: string) => {
    switch (type) {
      case "point":
        return <Circle className="h-4 w-4" />;
      case "line":
        return <Minus className="h-4 w-4" />;
      case "plane":
        return <Square className="h-4 w-4" />;
      default:
        return null;
    }
  };

  const getElementColor = (type: string) => {
    switch (type) {
      case "point":
        return "border-red-400 hover:bg-red-50";
      case "line":
        return "border-blue-400 hover:bg-blue-50";
      case "plane":
        return "border-green-400 hover:bg-green-50";
      default:
        return "";
    }
  };

  if (quizCompleted) {
    const percentage = (score / questions.length) * 100;
    const grade = percentage >= 80 ? "优秀" : percentage >= 60 ? "良好" : "继续加油";
    
    return (
      <Card className="bg-gradient-to-br from-yellow-50 to-orange-50 border-yellow-300">
        <CardHeader>
          <div className="flex items-center justify-center mb-4">
            <Trophy className="h-16 w-16 text-yellow-500" />
          </div>
          <CardTitle className="text-center text-2xl">测验完成！</CardTitle>
          <CardDescription className="text-center">
            你已完成点线面识别测验
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center">
            <div className="text-5xl font-bold text-primary mb-2">
              {score}/{questions.length}
            </div>
            <div className="text-lg text-muted-foreground mb-4">
              正确率：{percentage.toFixed(0)}%
            </div>
            <Badge variant="outline" className="text-lg px-4 py-2">
              {grade}
            </Badge>
          </div>

          <div className="space-y-3">
            <h4 className="font-semibold text-center">学习建议</h4>
            {percentage >= 80 ? (
              <p className="text-sm text-center text-muted-foreground">
                太棒了！你已经很好地掌握了点线面的识别。可以继续学习更高级的构成原理了。
              </p>
            ) : percentage >= 60 ? (
              <p className="text-sm text-center text-muted-foreground">
                不错！建议回顾一下理论部分，特别关注点线面的定义和特征。
              </p>
            ) : (
              <p className="text-sm text-center text-muted-foreground">
                建议重新学习点线面的基础理论，多观察生活中的实例，然后再次尝试测验。
              </p>
            )}
          </div>

          <div className="flex justify-center space-x-4">
            <Button onClick={handleRestart} variant="outline">
              <RotateCcw className="h-4 w-4 mr-2" />
              重新测验
            </Button>
            <Button onClick={() => {
              const element = document.getElementById("theory");
              if (element) {
                element.scrollIntoView({ behavior: "smooth" });
              }
            }}>
              复习理论
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  const question = questions[currentQuestion];

  return (
    <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200">
      <CardHeader>
        <div className="flex items-center justify-between mb-2">
          <Badge variant="outline">
            问题 {currentQuestion + 1}/{questions.length}
          </Badge>
          <Badge variant="outline" className="bg-primary/10">
            得分：{score}
          </Badge>
        </div>
        <CardTitle>点线面识别小测验</CardTitle>
        <CardDescription>
          选择正确的元素类型，测试你的理解程度
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Question */}
        <div className="text-center space-y-4">
          <div className="text-6xl">{question.image}</div>
          <h3 className="text-lg font-semibold">{question.question}</h3>
        </div>

        {/* Progress Bar */}
        <div className="space-y-2">
          <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-purple-500 to-pink-500 transition-all duration-300"
              style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
            ></div>
          </div>
        </div>

        {/* Options */}
        <div className="space-y-3">
          {question.options.map((option) => (
            <button
              key={option.type}
              onClick={() => !showResult && handleAnswer(option.type)}
              disabled={showResult}
              className={`w-full p-4 border-2 rounded-lg transition-all ${
                showResult
                  ? option.type === question.correctAnswer
                    ? "border-green-500 bg-green-50"
                    : option.type === selectedAnswer
                    ? "border-red-500 bg-red-50"
                    : "border-gray-300 bg-gray-50 opacity-50"
                  : getElementColor(option.type)
              } ${!showResult && "cursor-pointer hover:shadow-md"}`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  {getElementIcon(option.type)}
                  <span className="font-medium">{option.label}</span>
                </div>
                {showResult && option.type === question.correctAnswer && (
                  <Check className="h-5 w-5 text-green-600" />
                )}
                {showResult && option.type === selectedAnswer && option.type !== question.correctAnswer && (
                  <X className="h-5 w-5 text-red-600" />
                )}
              </div>
            </button>
          ))}
        </div>

        {/* Explanation */}
        {showResult && (
          <div className={`p-4 rounded-lg border-2 animate-in fade-in duration-300 ${
            selectedAnswer === question.correctAnswer
              ? "bg-green-50 border-green-300"
              : "bg-red-50 border-red-300"
          }`}>
            <div className="flex items-start space-x-2 mb-2">
              {selectedAnswer === question.correctAnswer ? (
                <Check className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
              ) : (
                <X className="h-5 w-5 text-red-600 flex-shrink-0 mt-0.5" />
              )}
              <div>
                <h4 className="font-semibold mb-1">
                  {selectedAnswer === question.correctAnswer ? "回答正确！" : "回答错误"}
                </h4>
                <p className="text-sm text-muted-foreground">{question.explanation}</p>
              </div>
            </div>
          </div>
        )}

        {/* Next Button */}
        {showResult && (
          <Button onClick={handleNext} className="w-full" size="lg">
            {currentQuestion < questions.length - 1 ? "下一题" : "查看结果"}
          </Button>
        )}
      </CardContent>
    </Card>
  );
}

