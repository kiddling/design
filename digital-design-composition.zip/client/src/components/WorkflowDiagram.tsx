import { Camera, Pencil, FileText, ArrowRight } from "lucide-react";

export default function WorkflowDiagram() {
  return (
    <div className="my-6">
      <div className="flex items-center justify-center gap-4 flex-wrap">
        {/* Step 1 */}
        <div className="flex flex-col items-center space-y-2 flex-1 min-w-[150px]">
          <div className="relative">
            <div className="h-20 w-20 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center shadow-lg">
              <Camera className="h-10 w-10 text-white" />
            </div>
            <div className="absolute -top-2 -right-2 h-8 w-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm">
              1
            </div>
          </div>
          <div className="text-center">
            <p className="font-semibold">拍照</p>
            <p className="text-xs text-muted-foreground">捕捉场景</p>
          </div>
        </div>

        {/* Arrow */}
        <ArrowRight className="h-6 w-6 text-muted-foreground hidden md:block" />

        {/* Step 2 */}
        <div className="flex flex-col items-center space-y-2 flex-1 min-w-[150px]">
          <div className="relative">
            <div className="h-20 w-20 rounded-full bg-gradient-to-br from-purple-500 to-purple-600 flex items-center justify-center shadow-lg">
              <Pencil className="h-10 w-10 text-white" />
            </div>
            <div className="absolute -top-2 -right-2 h-8 w-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm">
              2
            </div>
          </div>
          <div className="text-center">
            <p className="font-semibold">圈画</p>
            <p className="text-xs text-muted-foreground">标注元素</p>
          </div>
        </div>

        {/* Arrow */}
        <ArrowRight className="h-6 w-6 text-muted-foreground hidden md:block" />

        {/* Step 3 */}
        <div className="flex flex-col items-center space-y-2 flex-1 min-w-[150px]">
          <div className="relative">
            <div className="h-20 w-20 rounded-full bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center shadow-lg">
              <FileText className="h-10 w-10 text-white" />
            </div>
            <div className="absolute -top-2 -right-2 h-8 w-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm">
              3
            </div>
          </div>
          <div className="text-center">
            <p className="font-semibold">整理</p>
            <p className="text-xs text-muted-foreground">制作卡片</p>
          </div>
        </div>
      </div>

      {/* Timeline */}
      <div className="mt-6 flex items-center justify-center">
        <div className="flex items-center space-x-2 text-xs text-muted-foreground">
          <span>⏱️ 总用时</span>
          <span className="font-semibold">30-90分钟</span>
          <span className="text-muted-foreground/50">|</span>
          <span>📍 地点</span>
          <span className="font-semibold">校园任意场景</span>
        </div>
      </div>
    </div>
  );
}

