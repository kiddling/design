import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Copy, Sparkles, Check } from "lucide-react";
import { toast } from "sonner";

type ElementType = "point" | "line" | "plane" | "combined";
type Style = "bauhaus" | "mondrian" | "minimalist" | "abstract";
type ColorScheme = "blackwhite" | "primary" | "monochrome" | "colorful";

export default function PromptGenerator() {
  const [userInput, setUserInput] = useState("");
  const [elementType, setElementType] = useState<ElementType>("point");
  const [style, setStyle] = useState<Style>("bauhaus");
  const [colorScheme, setColorScheme] = useState<ColorScheme>("blackwhite");
  const [generatedPrompts, setGeneratedPrompts] = useState<{
    midjourney: string;
    chinese: string;
  } | null>(null);
  const [copiedMJ, setCopiedMJ] = useState(false);
  const [copiedCN, setCopiedCN] = useState(false);

  const generatePrompts = () => {
    if (!userInput.trim()) {
      toast.error("请输入你的设计想法");
      return;
    }

    // Element type keywords
    const elementKeywords = {
      point: {
        en: "dots, scattered points, circular elements, point composition",
        cn: "点状元素，圆点，散布的点"
      },
      line: {
        en: "lines, linear composition, intersecting lines, line patterns",
        cn: "线条，线性构成，交叉线条"
      },
      plane: {
        en: "geometric shapes, rectangular planes, color blocks, overlapping shapes",
        cn: "几何形状，矩形平面，色块"
      },
      combined: {
        en: "combining points lines and planes, geometric elements, balanced composition",
        cn: "点线面结合，几何元素，平衡构图"
      }
    };

    // Style keywords
    const styleKeywords = {
      bauhaus: {
        en: "Bauhaus style, geometric design, modernist",
        cn: "包豪斯风格，几何设计，现代主义"
      },
      mondrian: {
        en: "Mondrian inspired, De Stijl movement, grid composition",
        cn: "蒙德里安风格，风格派，网格构图"
      },
      minimalist: {
        en: "minimalist design, clean, simple",
        cn: "极简主义，简洁，干净"
      },
      abstract: {
        en: "abstract composition, artistic, creative",
        cn: "抽象构成，艺术性，创意"
      }
    };

    // Color scheme keywords
    const colorKeywords = {
      blackwhite: {
        en: "black and white, monochromatic",
        cn: "黑白，单色"
      },
      primary: {
        en: "primary colors, red yellow blue",
        cn: "三原色，红黄蓝"
      },
      monochrome: {
        en: "monochrome palette, single color variations",
        cn: "单色调，同色系"
      },
      colorful: {
        en: "vibrant colors, colorful, multi-colored",
        cn: "鲜艳色彩，多彩"
      }
    };

    // Generate Midjourney prompt
    const mjPrompt = `abstract composition, ${elementKeywords[elementType].en}, ${userInput}, ${styleKeywords[style].en}, ${colorKeywords[colorScheme].en}, clean background, high quality, --ar 1:1 --v 6`;

    // Generate Chinese prompt
    const cnPrompt = `抽象几何构成，${elementKeywords[elementType].cn}，${userInput}，${styleKeywords[style].cn}，${colorKeywords[colorScheme].cn}，干净背景，高清`;

    setGeneratedPrompts({
      midjourney: mjPrompt,
      chinese: cnPrompt
    });

    toast.success("提示词已生成！");
  };

  const copyToClipboard = async (text: string, type: "mj" | "cn") => {
    try {
      await navigator.clipboard.writeText(text);
      if (type === "mj") {
        setCopiedMJ(true);
        setTimeout(() => setCopiedMJ(false), 2000);
      } else {
        setCopiedCN(true);
        setTimeout(() => setCopiedCN(false), 2000);
      }
      toast.success("已复制到剪贴板");
    } catch (err) {
      toast.error("复制失败，请手动复制");
    }
  };

  return (
    <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200">
      <CardHeader>
        <div className="flex items-center space-x-2">
          <Sparkles className="h-5 w-5 text-purple-600" />
          <CardTitle>AI提示词生成器</CardTitle>
        </div>
        <CardDescription>
          输入你的设计想法，自动生成适合的AI绘画提示词
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Input Section */}
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="userInput">你的设计想法</Label>
            <Textarea
              id="userInput"
              placeholder="例如：密集的圆点形成波浪状排列 / 垂直线条与水平线条交织 / 红色矩形与蓝色圆形重叠"
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              rows={3}
              className="bg-white"
            />
            <p className="text-xs text-muted-foreground">
              💡 描述你想要的构成效果、元素排列方式或视觉感受
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="elementType">元素类型</Label>
              <Select value={elementType} onValueChange={(value) => setElementType(value as ElementType)}>
                <SelectTrigger id="elementType" className="bg-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="point">点元素</SelectItem>
                  <SelectItem value="line">线元素</SelectItem>
                  <SelectItem value="plane">面元素</SelectItem>
                  <SelectItem value="combined">点线面结合</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="style">设计风格</Label>
              <Select value={style} onValueChange={(value) => setStyle(value as Style)}>
                <SelectTrigger id="style" className="bg-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="bauhaus">包豪斯</SelectItem>
                  <SelectItem value="mondrian">蒙德里安</SelectItem>
                  <SelectItem value="minimalist">极简主义</SelectItem>
                  <SelectItem value="abstract">抽象艺术</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="colorScheme">配色方案</Label>
              <Select value={colorScheme} onValueChange={(value) => setColorScheme(value as ColorScheme)}>
                <SelectTrigger id="colorScheme" className="bg-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="blackwhite">黑白</SelectItem>
                  <SelectItem value="primary">三原色</SelectItem>
                  <SelectItem value="monochrome">单色调</SelectItem>
                  <SelectItem value="colorful">多彩</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button 
            onClick={generatePrompts} 
            className="w-full"
            size="lg"
          >
            <Sparkles className="h-4 w-4 mr-2" />
            生成AI提示词
          </Button>
        </div>

        {/* Generated Prompts */}
        {generatedPrompts && (
          <div className="space-y-4 animate-in fade-in duration-500">
            {/* Midjourney Prompt */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Label>Midjourney / Stable Diffusion</Label>
                  <Badge variant="outline">英文</Badge>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => copyToClipboard(generatedPrompts.midjourney, "mj")}
                >
                  {copiedMJ ? (
                    <>
                      <Check className="h-4 w-4 mr-2 text-green-600" />
                      已复制
                    </>
                  ) : (
                    <>
                      <Copy className="h-4 w-4 mr-2" />
                      复制
                    </>
                  )}
                </Button>
              </div>
              <div className="p-4 bg-white border-2 border-purple-200 rounded-lg">
                <p className="text-sm font-mono leading-relaxed">
                  {generatedPrompts.midjourney}
                </p>
              </div>
              <p className="text-xs text-muted-foreground">
                💡 适用于Midjourney、Stable Diffusion等国际AI绘画工具
              </p>
            </div>

            {/* Chinese Prompt */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Label>文心一格 / 通义万相</Label>
                  <Badge variant="outline">中文</Badge>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => copyToClipboard(generatedPrompts.chinese, "cn")}
                >
                  {copiedCN ? (
                    <>
                      <Check className="h-4 w-4 mr-2 text-green-600" />
                      已复制
                    </>
                  ) : (
                    <>
                      <Copy className="h-4 w-4 mr-2" />
                      复制
                    </>
                  )}
                </Button>
              </div>
              <div className="p-4 bg-white border-2 border-orange-200 rounded-lg">
                <p className="text-sm leading-relaxed">
                  {generatedPrompts.chinese}
                </p>
              </div>
              <p className="text-xs text-muted-foreground">
                💡 适用于文心一格、通义万相等国内AI绘画工具
              </p>
            </div>

            {/* Tips */}
            <div className="p-4 bg-amber-50 border-l-4 border-amber-500 rounded-lg">
              <p className="text-sm font-medium mb-2">📝 使用建议</p>
              <ul className="text-xs space-y-1 text-muted-foreground">
                <li>• 复制提示词后，粘贴到AI绘画工具的输入框中</li>
                <li>• 如果第一次生成的效果不理想，可以调整参数重新生成</li>
                <li>• 尝试修改提示词中的部分关键词，探索不同效果</li>
                <li>• AI生成的图像可以作为灵感参考，不要直接提交作业</li>
              </ul>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

