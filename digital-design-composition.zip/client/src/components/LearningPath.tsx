import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Check, Circle, Lock, ArrowRight, Target, Lightbulb } from "lucide-react";

interface PathStep {
  id: string;
  title: string;
  level: "base" | "advance" | "stretch";
  status: "completed" | "current" | "locked";
  description: string;
  section: string;
  estimatedTime: string;
}

export default function LearningPath() {
  const [currentStep, setCurrentStep] = useState("step1");

  const steps: PathStep[] = [
    {
      id: "step1",
      title: "理解点线面基本概念",
      level: "base",
      status: "completed",
      description: "学习点、线、面的定义和基本特征",
      section: "theory",
      estimatedTime: "15分钟"
    },
    {
      id: "step2",
      title: "观察生活中的点线面",
      level: "base",
      status: "current",
      description: "完成寻宝游戏，拍摄并标注场景中的元素",
      section: "tasks",
      estimatedTime: "30分钟"
    },
    {
      id: "step3",
      title: "分析经典案例",
      level: "advance",
      status: "locked",
      description: "深入研究蒙德里安、故宫等经典作品",
      section: "cases",
      estimatedTime: "20分钟"
    },
    {
      id: "step4",
      title: "使用AI生成构成作品",
      level: "advance",
      status: "locked",
      description: "运用AI工具创作点线面构成",
      section: "ai",
      estimatedTime: "25分钟"
    },
    {
      id: "step5",
      title: "创作个人作品集",
      level: "stretch",
      status: "locked",
      description: "整合所学，创作3-5幅原创构成作品",
      section: "tasks",
      estimatedTime: "60分钟"
    }
  ];

  const getLevelColor = (level: string) => {
    switch (level) {
      case "base":
        return "bg-green-100 text-green-700 border-green-300";
      case "advance":
        return "bg-blue-100 text-blue-700 border-blue-300";
      case "stretch":
        return "bg-purple-100 text-purple-700 border-purple-300";
      default:
        return "bg-gray-100 text-gray-700";
    }
  };

  const getLevelLabel = (level: string) => {
    switch (level) {
      case "base":
        return "基础线";
      case "advance":
        return "进阶A";
      case "stretch":
        return "进阶S";
      default:
        return "";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <Check className="h-5 w-5 text-green-600" />;
      case "current":
        return <Circle className="h-5 w-5 text-blue-600 fill-blue-600" />;
      case "locked":
        return <Lock className="h-5 w-5 text-gray-400" />;
      default:
        return null;
    }
  };

  const handleStepClick = (step: PathStep) => {
    if (step.status !== "locked") {
      setCurrentStep(step.id);
      const element = document.getElementById(step.section);
      if (element) {
        element.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    }
  };

  const getNextStep = () => {
    const currentIndex = steps.findIndex(s => s.id === currentStep);
    if (currentIndex < steps.length - 1) {
      return steps[currentIndex + 1];
    }
    return null;
  };

  const nextStep = getNextStep();
  const completedCount = steps.filter(s => s.status === "completed").length;
  const progress = (completedCount / steps.length) * 100;

  return (
    <Card className="bg-gradient-to-br from-green-50 to-blue-50 border-green-200">
      <CardHeader>
        <div className="flex items-center space-x-2">
          <Target className="h-5 w-5 text-green-600" />
          <CardTitle>学习路径导航</CardTitle>
        </div>
        <CardDescription>
          跟随路径循序渐进，从基础到进阶逐步掌握
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Progress Bar */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="font-medium">整体进度</span>
            <span className="text-muted-foreground">{completedCount}/{steps.length} 已完成</span>
          </div>
          <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-green-500 to-blue-500 transition-all duration-500"
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        </div>

        {/* Learning Steps */}
        <div className="space-y-4">
          {steps.map((step, index) => (
            <div key={step.id}>
              <div
                className={`p-4 rounded-lg border-2 transition-all cursor-pointer ${
                  step.status === "current"
                    ? "bg-blue-50 border-blue-400 shadow-md"
                    : step.status === "completed"
                    ? "bg-white border-green-300 hover:shadow-sm"
                    : "bg-gray-50 border-gray-300 opacity-60 cursor-not-allowed"
                }`}
                onClick={() => handleStepClick(step)}
              >
                <div className="flex items-start space-x-4">
                  {/* Step Number & Status */}
                  <div className="flex-shrink-0">
                    <div className={`h-10 w-10 rounded-full flex items-center justify-center ${
                      step.status === "completed" ? "bg-green-100" :
                      step.status === "current" ? "bg-blue-100" : "bg-gray-200"
                    }`}>
                      {getStatusIcon(step.status)}
                    </div>
                  </div>

                  {/* Step Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <h4 className="font-semibold">{step.title}</h4>
                        {step.status === "current" && (
                          <Badge variant="default" className="text-xs">进行中</Badge>
                        )}
                      </div>
                      <Badge variant="outline" className={`${getLevelColor(step.level)} text-xs`}>
                        {getLevelLabel(step.level)}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">{step.description}</p>
                    <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                      <span>⏱️ {step.estimatedTime}</span>
                      {step.status !== "locked" && (
                        <span className="flex items-center text-blue-600">
                          <ArrowRight className="h-3 w-3 mr-1" />
                          点击跳转
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Connection Line */}
              {index < steps.length - 1 && (
                <div className="flex justify-center">
                  <div className={`h-6 w-0.5 ${
                    steps[index + 1].status === "locked" ? "bg-gray-300" : "bg-blue-300"
                  }`}></div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Next Step Recommendation */}
        {nextStep && (
          <div className="p-4 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-lg">
            <div className="flex items-start space-x-3">
              <Lightbulb className="h-6 w-6 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-semibold mb-1">推荐下一步</h4>
                <p className="text-sm opacity-90 mb-3">{nextStep.title}</p>
                <Button 
                  size="sm" 
                  variant="secondary"
                  onClick={() => handleStepClick(nextStep)}
                  disabled={nextStep.status === "locked"}
                >
                  {nextStep.status === "locked" ? "完成当前步骤后解锁" : "开始学习"}
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Completion Message */}
        {completedCount === steps.length && (
          <div className="p-4 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-lg text-center">
            <div className="text-4xl mb-2">🎉</div>
            <h4 className="font-semibold mb-1">恭喜完成第1节课！</h4>
            <p className="text-sm opacity-90">你已经掌握了点线面的基础知识，可以继续学习第2节课了</p>
          </div>
        )}

        {/* Learning Tips */}
        <div className="p-3 bg-amber-50 border-l-4 border-amber-500 rounded-lg">
          <p className="text-sm">
            <strong>💡 学习建议：</strong>建议按照路径顺序学习，完成基础线内容后再挑战进阶任务。每个步骤都可以点击跳转到对应内容。
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

