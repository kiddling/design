import { Check, X } from "lucide-react";

export default function PhotoTipsVisual() {
  return (
    <div className="grid md:grid-cols-2 gap-6 my-6">
      {/* Good Examples */}
      <div className="space-y-4">
        <div className="flex items-center space-x-2 mb-3">
          <div className="h-8 w-8 rounded-full bg-green-500 flex items-center justify-center">
            <Check className="h-5 w-5 text-white" />
          </div>
          <h4 className="font-semibold text-green-700 text-lg">好的拍摄</h4>
        </div>

        <div className="space-y-3">
          {/* Good Example 1 */}
          <div className="p-4 bg-green-50 border-2 border-green-200 rounded-lg">
            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0 mt-1">
                <div className="h-12 w-12 rounded bg-gradient-to-br from-green-400 to-green-500 flex items-center justify-center">
                  <span className="text-2xl">☀️</span>
                </div>
              </div>
              <div>
                <p className="font-semibold text-sm mb-1">光线充足</p>
                <p className="text-xs text-muted-foreground">自然光下拍摄，细节清晰可见，色彩真实</p>
              </div>
            </div>
          </div>

          {/* Good Example 2 */}
          <div className="p-4 bg-green-50 border-2 border-green-200 rounded-lg">
            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0 mt-1">
                <div className="h-12 w-12 rounded bg-gradient-to-br from-green-400 to-green-500 flex items-center justify-center">
                  <span className="text-2xl">📐</span>
                </div>
              </div>
              <div>
                <p className="font-semibold text-sm mb-1">构图稳定</p>
                <p className="text-xs text-muted-foreground">水平线平直，垂直线垂直，画面平衡</p>
              </div>
            </div>
          </div>

          {/* Good Example 3 */}
          <div className="p-4 bg-green-50 border-2 border-green-200 rounded-lg">
            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0 mt-1">
                <div className="h-12 w-12 rounded bg-gradient-to-br from-green-400 to-green-500 flex items-center justify-center">
                  <span className="text-2xl">🎯</span>
                </div>
              </div>
              <div>
                <p className="font-semibold text-sm mb-1">焦点清晰</p>
                <p className="text-xs text-muted-foreground">主体清晰，元素可辨，便于分析</p>
              </div>
            </div>
          </div>

          {/* Good Example 4 */}
          <div className="p-4 bg-green-50 border-2 border-green-200 rounded-lg">
            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0 mt-1">
                <div className="h-12 w-12 rounded bg-gradient-to-br from-green-400 to-green-500 flex items-center justify-center">
                  <span className="text-2xl">🎨</span>
                </div>
              </div>
              <div>
                <p className="font-semibold text-sm mb-1">元素丰富</p>
                <p className="text-xs text-muted-foreground">包含多种点线面元素，便于标注</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bad Examples */}
      <div className="space-y-4">
        <div className="flex items-center space-x-2 mb-3">
          <div className="h-8 w-8 rounded-full bg-red-500 flex items-center justify-center">
            <X className="h-5 w-5 text-white" />
          </div>
          <h4 className="font-semibold text-red-700 text-lg">要避免的</h4>
        </div>

        <div className="space-y-3">
          {/* Bad Example 1 */}
          <div className="p-4 bg-red-50 border-2 border-red-200 rounded-lg">
            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0 mt-1">
                <div className="h-12 w-12 rounded bg-gradient-to-br from-red-400 to-red-500 flex items-center justify-center">
                  <span className="text-2xl">🌑</span>
                </div>
              </div>
              <div>
                <p className="font-semibold text-sm mb-1">光线不足</p>
                <p className="text-xs text-muted-foreground">逆光或太暗，主体看不清，细节丢失</p>
              </div>
            </div>
          </div>

          {/* Bad Example 2 */}
          <div className="p-4 bg-red-50 border-2 border-red-200 rounded-lg">
            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0 mt-1">
                <div className="h-12 w-12 rounded bg-gradient-to-br from-red-400 to-red-500 flex items-center justify-center">
                  <span className="text-2xl">📱</span>
                </div>
              </div>
              <div>
                <p className="font-semibold text-sm mb-1">照片倾斜</p>
                <p className="text-xs text-muted-foreground">画面歪斜，水平线不平，影响分析</p>
              </div>
            </div>
          </div>

          {/* Bad Example 3 */}
          <div className="p-4 bg-red-50 border-2 border-red-200 rounded-lg">
            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0 mt-1">
                <div className="h-12 w-12 rounded bg-gradient-to-br from-red-400 to-red-500 flex items-center justify-center">
                  <span className="text-2xl">😵</span>
                </div>
              </div>
              <div>
                <p className="font-semibold text-sm mb-1">画面模糊</p>
                <p className="text-xs text-muted-foreground">手抖或对焦不准，元素边界不清</p>
              </div>
            </div>
          </div>

          {/* Bad Example 4 */}
          <div className="p-4 bg-red-50 border-2 border-red-200 rounded-lg">
            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0 mt-1">
                <div className="h-12 w-12 rounded bg-gradient-to-br from-red-400 to-red-500 flex items-center justify-center">
                  <span className="text-2xl">🔍</span>
                </div>
              </div>
              <div>
                <p className="font-semibold text-sm mb-1">距离不当</p>
                <p className="text-xs text-muted-foreground">太远看不清细节，太近视野太窄</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

