import { Badge } from "@/components/ui/badge";

export type DifficultyLevel = "Base" | "Advance" | "Stretch";

interface DifficultyBadgeProps {
  level: DifficultyLevel;
  className?: string;
}

const difficultyConfig = {
  Base: {
    label: "基础线",
    variant: "secondary" as const,
    description: "低负担基础要求",
  },
  Advance: {
    label: "进阶A",
    variant: "default" as const,
    description: "中等难度挑战",
  },
  Stretch: {
    label: "进阶S",
    variant: "destructive" as const,
    description: "高难度探索",
  },
};

export default function DifficultyBadge({ level, className }: DifficultyBadgeProps) {
  const config = difficultyConfig[level];
  
  return (
    <Badge variant={config.variant} className={className} title={config.description}>
      {config.label}
    </Badge>
  );
}

