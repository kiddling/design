import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Network, ArrowRight, Circle, Minus, Square } from "lucide-react";

interface ConceptNode {
  id: string;
  label: string;
  type: "core" | "related" | "application";
  description: string;
  section?: string;
}

export default function KnowledgeGraph() {
  const [selectedNode, setSelectedNode] = useState<ConceptNode | null>(null);

  const nodes: ConceptNode[] = [
    {
      id: "point",
      label: "点",
      type: "core",
      description: "视觉焦点，最小的造型单位，具有位置和大小",
      section: "theory"
    },
    {
      id: "line",
      label: "线",
      type: "core",
      description: "点的运动轨迹，具有方向、长度和粗细",
      section: "theory"
    },
    {
      id: "plane",
      label: "面",
      type: "core",
      description: "线的移动形成的区域，具有形状、大小和色彩",
      section: "theory"
    },
    {
      id: "visual-focus",
      label: "视觉焦点",
      type: "related",
      description: "点作为视觉中心，吸引注意力",
      section: "theory"
    },
    {
      id: "direction",
      label: "方向引导",
      type: "related",
      description: "线引导视线流动，创造动势",
      section: "theory"
    },
    {
      id: "space-division",
      label: "空间分割",
      type: "related",
      description: "面划分空间，创造层次",
      section: "theory"
    },
    {
      id: "logo-design",
      label: "标志设计",
      type: "application",
      description: "点线面在品牌标识中的应用",
      section: "cases"
    },
    {
      id: "architecture",
      label: "建筑设计",
      type: "application",
      description: "建筑中的点线面构成",
      section: "cases"
    },
    {
      id: "ui-design",
      label: "界面设计",
      type: "application",
      description: "数字界面的点线面运用",
      section: "cases"
    }
  ];

  const connections = [
    { from: "point", to: "visual-focus" },
    { from: "point", to: "line" },
    { from: "line", to: "direction" },
    { from: "line", to: "plane" },
    { from: "plane", to: "space-division" },
    { from: "visual-focus", to: "logo-design" },
    { from: "direction", to: "architecture" },
    { from: "space-division", to: "ui-design" }
  ];

  const handleNodeClick = (node: ConceptNode) => {
    setSelectedNode(node);
    if (node.section) {
      // Scroll to the section
      const element = document.getElementById(node.section);
      if (element) {
        element.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    }
  };

  const getNodeColor = (type: string) => {
    switch (type) {
      case "core":
        return "bg-gradient-to-br from-blue-500 to-blue-600";
      case "related":
        return "bg-gradient-to-br from-purple-500 to-purple-600";
      case "application":
        return "bg-gradient-to-br from-green-500 to-green-600";
      default:
        return "bg-gray-500";
    }
  };

  const getNodeIcon = (id: string) => {
    if (id === "point") return <Circle className="h-4 w-4" />;
    if (id === "line") return <Minus className="h-4 w-4" />;
    if (id === "plane") return <Square className="h-4 w-4" />;
    return null;
  };

  return (
    <Card className="bg-gradient-to-br from-blue-50 to-purple-50 border-blue-200">
      <CardHeader>
        <div className="flex items-center space-x-2">
          <Network className="h-5 w-5 text-blue-600" />
          <CardTitle>知识图谱：点线面概念网络</CardTitle>
        </div>
        <CardDescription>
          点击节点探索概念关系，自动跳转到对应内容
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Legend */}
        <div className="flex flex-wrap gap-4 text-sm">
          <div className="flex items-center space-x-2">
            <div className="h-3 w-3 rounded-full bg-gradient-to-br from-blue-500 to-blue-600"></div>
            <span className="text-muted-foreground">核心概念</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="h-3 w-3 rounded-full bg-gradient-to-br from-purple-500 to-purple-600"></div>
            <span className="text-muted-foreground">相关概念</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="h-3 w-3 rounded-full bg-gradient-to-br from-green-500 to-green-600"></div>
            <span className="text-muted-foreground">应用领域</span>
          </div>
        </div>

        {/* Graph Visualization */}
        <div className="relative bg-white rounded-lg border-2 border-blue-200 p-8 min-h-[400px]">
          {/* Core Concepts Layer */}
          <div className="absolute top-8 left-1/2 -translate-x-1/2 flex space-x-8">
            {nodes.filter(n => n.type === "core").map((node) => (
              <div
                key={node.id}
                className="flex flex-col items-center cursor-pointer group"
                onClick={() => handleNodeClick(node)}
              >
                <div className={`h-16 w-16 rounded-full ${getNodeColor(node.type)} flex items-center justify-center text-white shadow-lg group-hover:scale-110 transition-transform`}>
                  {getNodeIcon(node.id) || <span className="font-bold text-sm">{node.label}</span>}
                </div>
                <span className="mt-2 text-sm font-semibold text-center">{node.label}</span>
              </div>
            ))}
          </div>

          {/* Connection Lines */}
          <svg className="absolute inset-0 pointer-events-none" style={{ zIndex: 0 }}>
            {/* Simplified connection visualization */}
            <line x1="50%" y1="80" x2="30%" y2="180" stroke="#9333ea" strokeWidth="2" strokeDasharray="4" />
            <line x1="50%" y1="80" x2="70%" y2="180" stroke="#9333ea" strokeWidth="2" strokeDasharray="4" />
            <line x1="30%" y1="200" x2="20%" y2="300" stroke="#22c55e" strokeWidth="2" strokeDasharray="4" />
            <line x1="50%" y1="200" x2="50%" y2="300" stroke="#22c55e" strokeWidth="2" strokeDasharray="4" />
            <line x1="70%" y1="200" x2="80%" y2="300" stroke="#22c55e" strokeWidth="2" strokeDasharray="4" />
          </svg>

          {/* Related Concepts Layer */}
          <div className="absolute top-[180px] left-1/2 -translate-x-1/2 flex space-x-16">
            {nodes.filter(n => n.type === "related").map((node) => (
              <div
                key={node.id}
                className="flex flex-col items-center cursor-pointer group"
                onClick={() => handleNodeClick(node)}
              >
                <div className={`h-12 w-12 rounded-full ${getNodeColor(node.type)} flex items-center justify-center text-white shadow-md group-hover:scale-110 transition-transform`}>
                  <span className="font-bold text-xs">{node.label.slice(0, 2)}</span>
                </div>
                <span className="mt-2 text-xs font-medium text-center max-w-[80px]">{node.label}</span>
              </div>
            ))}
          </div>

          {/* Application Layer */}
          <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex space-x-12">
            {nodes.filter(n => n.type === "application").map((node) => (
              <div
                key={node.id}
                className="flex flex-col items-center cursor-pointer group"
                onClick={() => handleNodeClick(node)}
              >
                <div className={`h-12 w-12 rounded-full ${getNodeColor(node.type)} flex items-center justify-center text-white shadow-md group-hover:scale-110 transition-transform`}>
                  <span className="font-bold text-xs">{node.label.slice(0, 2)}</span>
                </div>
                <span className="mt-2 text-xs font-medium text-center max-w-[80px]">{node.label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Selected Node Info */}
        {selectedNode && (
          <div className="p-4 bg-white border-2 border-blue-300 rounded-lg animate-in fade-in duration-300">
            <div className="flex items-start justify-between mb-2">
              <h4 className="font-semibold text-lg">{selectedNode.label}</h4>
              <Badge variant={selectedNode.type === "core" ? "default" : "secondary"}>
                {selectedNode.type === "core" ? "核心概念" : selectedNode.type === "related" ? "相关概念" : "应用领域"}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground mb-3">{selectedNode.description}</p>
            {selectedNode.section && (
              <div className="flex items-center text-xs text-blue-600">
                <ArrowRight className="h-3 w-3 mr-1" />
                <span>已自动跳转到对应内容</span>
              </div>
            )}
          </div>
        )}

        {/* Usage Tip */}
        <div className="p-3 bg-amber-50 border-l-4 border-amber-500 rounded-lg">
          <p className="text-sm">
            <strong>💡 使用提示：</strong>点击任意节点查看详细说明，系统会自动滚动到对应的理论或案例部分
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

