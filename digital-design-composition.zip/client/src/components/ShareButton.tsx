import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Share2, Link as LinkIcon, Check, QrCode } from "lucide-react";
import { toast } from "sonner";

interface ShareButtonProps {
  title?: string;
  description?: string;
}

export default function ShareButton({ title = "数字设计构成", description = "在线教学平台" }: ShareButtonProps) {
  const [showQR, setShowQR] = useState(false);

  const currentUrl = typeof window !== "undefined" ? window.location.href : "";

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(currentUrl);
      toast.success("链接已复制到剪贴板");
    } catch (err) {
      toast.error("复制失败，请手动复制");
    }
  };

  const handleShareWeChat = () => {
    // Show QR code for WeChat sharing
    setShowQR(true);
    toast.info("请使用微信扫描二维码分享");
  };

  const handleShareWeibo = () => {
    const weiboUrl = `https://service.weibo.com/share/share.php?url=${encodeURIComponent(currentUrl)}&title=${encodeURIComponent(title + " - " + description)}`;
    window.open(weiboUrl, "_blank", "width=600,height=400");
  };

  const handleShareQQ = () => {
    const qqUrl = `https://connect.qq.com/widget/shareqq/index.html?url=${encodeURIComponent(currentUrl)}&title=${encodeURIComponent(title)}&summary=${encodeURIComponent(description)}`;
    window.open(qqUrl, "_blank", "width=600,height=400");
  };

  const handleShareQZone = () => {
    const qzoneUrl = `https://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=${encodeURIComponent(currentUrl)}&title=${encodeURIComponent(title)}&summary=${encodeURIComponent(description)}`;
    window.open(qzoneUrl, "_blank", "width=600,height=400");
  };

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm">
            <Share2 className="h-4 w-4 mr-2" />
            分享
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-48">
          <DropdownMenuItem onClick={handleCopyLink}>
            <LinkIcon className="h-4 w-4 mr-2" />
            复制链接
          </DropdownMenuItem>
          <DropdownMenuItem onClick={handleShareWeChat}>
            <span className="mr-2">💬</span>
            分享到微信
          </DropdownMenuItem>
          <DropdownMenuItem onClick={handleShareWeibo}>
            <span className="mr-2">🔴</span>
            分享到微博
          </DropdownMenuItem>
          <DropdownMenuItem onClick={handleShareQQ}>
            <span className="mr-2">🐧</span>
            分享到QQ
          </DropdownMenuItem>
          <DropdownMenuItem onClick={handleShareQZone}>
            <span className="mr-2">⭐</span>
            分享到QQ空间
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* QR Code Modal */}
      {showQR && (
        <div 
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 animate-in fade-in duration-200"
          onClick={() => setShowQR(false)}
        >
          <div 
            className="bg-white rounded-lg p-6 max-w-sm mx-4 animate-in zoom-in duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-lg">微信扫码分享</h3>
              <button 
                onClick={() => setShowQR(false)}
                className="text-muted-foreground hover:text-foreground"
              >
                ✕
              </button>
            </div>
            
            <div className="bg-gray-100 p-4 rounded-lg mb-4 flex items-center justify-center">
              <div className="bg-white p-4 rounded-lg shadow-inner">
                <QrCode className="h-32 w-32 text-gray-400" />
              </div>
            </div>
            
            <p className="text-sm text-center text-muted-foreground mb-4">
              使用微信扫描二维码分享给好友
            </p>
            
            <div className="flex space-x-2">
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={handleCopyLink}
              >
                <LinkIcon className="h-4 w-4 mr-2" />
                复制链接
              </Button>
              <Button 
                className="flex-1"
                onClick={() => setShowQR(false)}
              >
                关闭
              </Button>
            </div>
            
            <p className="text-xs text-center text-muted-foreground mt-3">
              💡 提示：也可以复制链接后在微信中粘贴分享
            </p>
          </div>
        </div>
      )}
    </>
  );
}

