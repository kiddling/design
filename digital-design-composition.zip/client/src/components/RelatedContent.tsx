import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { ExternalLink, BookOpen, Lightbulb, ArrowRight } from "lucide-react";

interface RelatedItem {
  type: "lesson" | "knowledge" | "external";
  title: string;
  description: string;
  link: string;
  tag?: string;
}

interface RelatedContentProps {
  currentSection: string;
}

export default function RelatedContent({ currentSection }: RelatedContentProps) {
  const getRelatedItems = (section: string): RelatedItem[] => {
    const relatedMap: Record<string, RelatedItem[]> = {
      theory: [
        {
          type: "knowledge",
          title: "平面构成原理",
          description: "深入了解平面构成的基础理论",
          link: "/knowledge",
          tag: "知识卡片"
        },
        {
          type: "lesson",
          title: "第2节：触·材质发现",
          description: "学习如何观察和分类不同材质",
          link: "/lesson/2",
          tag: "下一节课"
        },
        {
          type: "external",
          title: "包豪斯设计理念",
          description: "了解现代设计的起源和核心思想",
          link: "https://www.zcool.com.cn/",
          tag: "外部资源"
        }
      ],
      examples: [
        {
          type: "knowledge",
          title: "色彩构成原理",
          description: "探索色彩在设计中的应用",
          link: "/knowledge",
          tag: "知识卡片"
        },
        {
          type: "lesson",
          title: "第3节：构·动态平衡",
          description: "学习如何创造视觉平衡",
          link: "/lesson/3",
          tag: "相关课程"
        },
        {
          type: "external",
          title: "站酷设计案例",
          description: "浏览更多优秀设计作品",
          link: "https://www.zcool.com.cn/",
          tag: "案例库"
        }
      ],
      ai: [
        {
          type: "knowledge",
          title: "AI设计工具指南",
          description: "了解常用的AI设计工具",
          link: "/resources",
          tag: "学习资源"
        },
        {
          type: "lesson",
          title: "第6节：色·情感联想",
          description: "用AI探索色彩情感表达",
          link: "/lesson/6",
          tag: "进阶课程"
        },
        {
          type: "external",
          title: "Midjourney官方文档",
          description: "学习AI绘画的高级技巧",
          link: "https://docs.midjourney.com/",
          tag: "官方教程"
        }
      ],
      tasks: [
        {
          type: "knowledge",
          title: "构成设计基础",
          description: "回顾设计构成的核心概念",
          link: "/knowledge",
          tag: "理论基础"
        },
        {
          type: "lesson",
          title: "第4节：塑·空间幻觉",
          description: "学习如何创造空间深度",
          link: "/lesson/4",
          tag: "相关技能"
        },
        {
          type: "external",
          title: "Canva设计学院",
          description: "学习更多设计工具使用技巧",
          link: "https://www.canva.cn/learn/",
          tag: "工具教程"
        }
      ]
    };

    return relatedMap[section] || [
      {
        type: "knowledge",
        title: "设计构成知识卡片",
        description: "浏览完整的知识卡片库",
        link: "/knowledge",
        tag: "知识库"
      },
      {
        type: "lesson",
        title: "课程大纲",
        description: "查看完整的12节课程",
        link: "/curriculum",
        tag: "课程列表"
      },
      {
        type: "external",
        title: "设计资源库",
        description: "探索更多学习资源",
        link: "/resources",
        tag: "资源中心"
      }
    ];
  };

  const items = getRelatedItems(currentSection);

  const getIcon = (type: string) => {
    switch (type) {
      case "lesson":
        return <BookOpen className="h-4 w-4" />;
      case "knowledge":
        return <Lightbulb className="h-4 w-4" />;
      case "external":
        return <ExternalLink className="h-4 w-4" />;
      default:
        return <ArrowRight className="h-4 w-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "lesson":
        return "bg-blue-100 text-blue-700 border-blue-300";
      case "knowledge":
        return "bg-purple-100 text-purple-700 border-purple-300";
      case "external":
        return "bg-green-100 text-green-700 border-green-300";
      default:
        return "bg-gray-100 text-gray-700";
    }
  };

  return (
    <Card className="bg-gradient-to-br from-orange-50 to-yellow-50 border-orange-200">
      <CardHeader>
        <div className="flex items-center space-x-2">
          <Lightbulb className="h-5 w-5 text-orange-600" />
          <CardTitle>相关内容推荐</CardTitle>
        </div>
        <CardDescription>
          继续探索相关的课程、知识和资源
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid md:grid-cols-3 gap-4">
          {items.map((item, index) => (
            <div key={index}>
              {item.type === "external" ? (
                <a
                  href={item.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block p-4 bg-white border-2 border-orange-200 rounded-lg hover:shadow-md transition-all group"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      {getIcon(item.type)}
                      <h4 className="font-semibold text-sm group-hover:text-primary transition-colors">
                        {item.title}
                      </h4>
                    </div>
                    {item.tag && (
                      <Badge variant="outline" className={`${getTypeColor(item.type)} text-xs`}>
                        {item.tag}
                      </Badge>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">{item.description}</p>
                  <div className="flex items-center text-xs text-primary mt-2">
                    <span>访问</span>
                    <ArrowRight className="h-3 w-3 ml-1 group-hover:translate-x-1 transition-transform" />
                  </div>
                </a>
              ) : (
                <Link href={item.link}>
                  <div className="block p-4 bg-white border-2 border-orange-200 rounded-lg hover:shadow-md transition-all cursor-pointer group">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        {getIcon(item.type)}
                        <h4 className="font-semibold text-sm group-hover:text-primary transition-colors">
                          {item.title}
                        </h4>
                      </div>
                      {item.tag && (
                        <Badge variant="outline" className={`${getTypeColor(item.type)} text-xs`}>
                          {item.tag}
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">{item.description}</p>
                    <div className="flex items-center text-xs text-primary mt-2">
                      <span>查看</span>
                      <ArrowRight className="h-3 w-3 ml-1 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                </Link>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

