import { Button } from "@/components/ui/button";
import { APP_TITLE } from "@/const";
import { BookOpen, Boxes, Lightbulb, Library, Sparkles } from "lucide-react";
import { Link, useLocation } from "wouter";

const navItems = [
  { path: "/", label: "首页", icon: Sparkles },
  { path: "/curriculum", label: "课程大纲", icon: BookOpen },
  { path: "/knowledge", label: "知识卡片", icon: Lightbulb },
  { path: "/cases", label: "案例库", icon: Boxes },
  { path: "/resources", label: "学习资源", icon: Library },
];

export default function Navigation() {
  const [location] = useLocation();

  return (
    <nav className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <Link href="/">
          <div className="flex items-center space-x-2 font-bold text-xl text-primary hover:opacity-80 transition-opacity cursor-pointer">
            <Sparkles className="h-6 w-6" />
            <span>{APP_TITLE}</span>
          </div>
        </Link>

        <div className="hidden md:flex items-center space-x-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.path;
            
            return (
              <Link key={item.path} href={item.path}>
                <Button
                  variant={isActive ? "default" : "ghost"}
                  className="flex items-center space-x-2"
                >
                  <Icon className="h-4 w-4" />
                  <span>{item.label}</span>
                </Button>
              </Link>
            );
          })}
        </div>

        {/* Mobile menu button - to be implemented */}
        <div className="md:hidden">
          <Button variant="ghost" size="icon">
            <svg
              className="h-6 w-6"
              fill="none"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </Button>
        </div>
      </div>
    </nav>
  );
}

