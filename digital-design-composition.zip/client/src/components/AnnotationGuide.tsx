export default function AnnotationGuide() {
  return (
    <div className="grid md:grid-cols-3 gap-6 my-6">
      {/* Point Annotation */}
      <div className="p-6 bg-gradient-to-br from-red-50 to-red-100 border-2 border-red-200 rounded-xl">
        <div className="flex items-center justify-between mb-4">
          <h4 className="font-semibold text-red-700">标注"点"</h4>
          <span className="text-2xl">🔴</span>
        </div>
        
        {/* Visual Example */}
        <div className="relative h-32 bg-white rounded-lg border-2 border-red-300 mb-4 overflow-hidden">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="relative">
              {/* Simulated image background */}
              <div className="h-24 w-32 bg-gray-200 rounded"></div>
              
              {/* Point annotations */}
              <div className="absolute top-2 left-4 h-4 w-4 rounded-full border-2 border-red-500 bg-transparent"></div>
              <div className="absolute bottom-4 right-6 h-4 w-4 rounded-full border-2 border-red-500 bg-transparent"></div>
              <div className="absolute top-8 right-8 h-4 w-4 rounded-full border-2 border-red-500 bg-transparent"></div>
            </div>
          </div>
        </div>

        <div className="space-y-2 text-sm">
          <div className="flex items-start space-x-2">
            <span className="text-red-600 font-bold">①</span>
            <p className="text-xs">用<strong className="text-red-700">红色圆圈</strong>标注</p>
          </div>
          <div className="flex items-start space-x-2">
            <span className="text-red-600 font-bold">②</span>
            <p className="text-xs">圈住小而集中的元素</p>
          </div>
          <div className="flex items-start space-x-2">
            <span className="text-red-600 font-bold">③</span>
            <p className="text-xs">如：灯泡、开关、装饰</p>
          </div>
        </div>
      </div>

      {/* Line Annotation */}
      <div className="p-6 bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-200 rounded-xl">
        <div className="flex items-center justify-between mb-4">
          <h4 className="font-semibold text-blue-700">标注"线"</h4>
          <span className="text-2xl">📏</span>
        </div>
        
        {/* Visual Example */}
        <div className="relative h-32 bg-white rounded-lg border-2 border-blue-300 mb-4 overflow-hidden">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="relative">
              {/* Simulated image background */}
              <div className="h-24 w-32 bg-gray-200 rounded"></div>
              
              {/* Line annotations */}
              <div className="absolute top-4 left-2 right-2 h-0.5 bg-blue-500"></div>
              <div className="absolute top-8 left-4 w-0.5 h-12 bg-blue-500"></div>
              <div className="absolute bottom-6 left-6 right-6 h-0.5 bg-blue-500 transform rotate-12"></div>
            </div>
          </div>
        </div>

        <div className="space-y-2 text-sm">
          <div className="flex items-start space-x-2">
            <span className="text-blue-600 font-bold">①</span>
            <p className="text-xs">用<strong className="text-blue-700">蓝色线条/箭头</strong>标注</p>
          </div>
          <div className="flex items-start space-x-2">
            <span className="text-blue-600 font-bold">②</span>
            <p className="text-xs">沿着延伸的元素绘制</p>
          </div>
          <div className="flex items-start space-x-2">
            <span className="text-blue-600 font-bold">③</span>
            <p className="text-xs">如：墙角、栏杆、线条</p>
          </div>
        </div>
      </div>

      {/* Plane Annotation */}
      <div className="p-6 bg-gradient-to-br from-green-50 to-green-100 border-2 border-green-200 rounded-xl">
        <div className="flex items-center justify-between mb-4">
          <h4 className="font-semibold text-green-700">标注"面"</h4>
          <span className="text-2xl">▭</span>
        </div>
        
        {/* Visual Example */}
        <div className="relative h-32 bg-white rounded-lg border-2 border-green-300 mb-4 overflow-hidden">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="relative">
              {/* Simulated image background */}
              <div className="h-24 w-32 bg-gray-200 rounded"></div>
              
              {/* Plane annotations */}
              <div className="absolute top-2 left-2 h-16 w-20 border-2 border-green-500 bg-green-500/20 rounded"></div>
              <div className="absolute bottom-2 right-2 h-12 w-16 border-2 border-green-500 bg-green-500/20 rounded"></div>
            </div>
          </div>
        </div>

        <div className="space-y-2 text-sm">
          <div className="flex items-start space-x-2">
            <span className="text-green-600 font-bold">①</span>
            <p className="text-xs">用<strong className="text-green-700">绿色半透明矩形</strong>标注</p>
          </div>
          <div className="flex items-start space-x-2">
            <span className="text-green-600 font-bold">②</span>
            <p className="text-xs">覆盖大面积的元素</p>
          </div>
          <div className="flex items-start space-x-2">
            <span className="text-green-600 font-bold">③</span>
            <p className="text-xs">如：墙面、桌面、窗户</p>
          </div>
        </div>
      </div>
    </div>
  );
}

