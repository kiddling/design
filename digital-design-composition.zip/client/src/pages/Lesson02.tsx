import Navigation from "@/components/Navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Target, 
  BookOpen, 
  Lightbulb, 
  Image, 
  Award, 
  ExternalLink, 
  ChevronLeft, 
  ChevronRight,
  Camera,
  Pencil,
  Eye,
  AlertCircle,
  Hand
} from "lucide-react";
import { Link } from "wouter";

export default function Lesson02() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1 py-8">
        <div className="container">
          <div className="max-w-6xl mx-auto">
            {/* Header */}
            <div className="mb-8">
              <Link href="/curriculum">
                <Button variant="ghost" className="mb-4">
                  <ChevronLeft className="h-4 w-4 mr-2" />
                  返回课程大纲
                </Button>
              </Link>
              
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <Badge>第2节</Badge>
                    <Badge variant="outline">3小时</Badge>
                    <Badge variant="outline">课前15分钟 + 课中90分钟</Badge>
                  </div>
                  <h1 className="text-4xl font-bold mb-2">触·材质发现</h1>
                  <p className="text-xl text-muted-foreground">Material Discovery</p>
                </div>
              </div>
            </div>

            {/* Learning Objectives */}
            <Card className="mb-8">
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <Target className="h-5 w-5 text-primary" />
                  <CardTitle>学习目标</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span>培养对材质的敏感度，学会用视觉和触觉感知材质特性</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span>掌握材质采集和摄影记录的方法</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span>理解材质的视觉属性：纹理、光泽、透明度、粗糙度等</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span>建立个人材质库，为后续设计提供素材基础</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Main Content Tabs */}
            <Tabs defaultValue="tasks" className="space-y-6">
              <TabsList className="grid w-full grid-cols-6">
                <TabsTrigger value="tasks">
                  <Hand className="h-4 w-4 mr-2" />
                  任务卡片
                </TabsTrigger>
                <TabsTrigger value="tutorials">
                  <Camera className="h-4 w-4 mr-2" />
                  教程
                </TabsTrigger>
                <TabsTrigger value="theory">
                  <BookOpen className="h-4 w-4 mr-2" />
                  理论
                </TabsTrigger>
                <TabsTrigger value="examples">
                  <Image className="h-4 w-4 mr-2" />
                  案例
                </TabsTrigger>
                <TabsTrigger value="works">
                  <Award className="h-4 w-4 mr-2" />
                  优秀作业
                </TabsTrigger>
                <TabsTrigger value="resources">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  拓展
                </TabsTrigger>
              </TabsList>

              {/* Tasks Tab */}
              <TabsContent value="tasks" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-2xl">材质采集游戏：用手和眼睛去发现</CardTitle>
                    <CardDescription className="text-base">
                      设计不仅是视觉的，更是触觉的！这节课，我们要在你的微空间里，寻找至少10种不同的材质，
                      用相机记录它们的样子，用手感受它们的质感，建立你的第一个材质库。
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Step 1 */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-lg flex items-center space-x-2">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground text-sm">1</span>
                        <span>步骤1：材质寻宝 - 找到10种不同材质</span>
                      </h4>
                      <p className="text-muted-foreground ml-8">
                        在你的微空间里，寻找至少10种视觉和触感都不同的材质。不要只看，要用手去摸！
                      </p>
                      <div className="ml-8 p-4 bg-muted/50 rounded-lg">
                        <p className="font-medium mb-2 text-sm">💡 材质寻找提示：</p>
                        <ul className="space-y-1">
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>硬质材料：石材、混凝土、金属、玻璃、陶瓷</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>软质材料：木材、布料、皮革、纸张、塑料</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>自然材料：树叶、树皮、泥土、沙石、水面</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>特殊效果：透明的、反光的、粗糙的、光滑的</span>
                          </li>
                        </ul>
                      </div>
                    </div>

                    {/* Step 2 */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-lg flex items-center space-x-2">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground text-sm">2</span>
                        <span>步骤2：近距离拍摄 - 记录材质细节</span>
                      </h4>
                      <p className="text-muted-foreground ml-8">
                        为每种材质拍摄一张近距离特写照片，要能看清纹理和质感。
                      </p>
                      <div className="ml-8 p-4 bg-muted/50 rounded-lg">
                        <p className="font-medium mb-2 text-sm">💡 拍摄技巧：</p>
                        <ul className="space-y-1">
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>距离：靠近拍，填满画面，看清纹理</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>光线：注意光影，侧光能更好地表现质感</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>对焦：点击屏幕对焦，确保材质清晰</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>角度：尝试不同角度，找到最能表现材质特点的视角</span>
                          </li>
                        </ul>
                      </div>
                    </div>

                    {/* Step 3 */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-lg flex items-center space-x-2">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground text-sm">3</span>
                        <span>步骤3：材质卡片 - 整理你的材质库</span>
                      </h4>
                      <p className="text-muted-foreground ml-8">
                        在Canva中创建材质卡片，为每种材质添加标签和描述。
                      </p>
                      <div className="ml-8 p-4 bg-muted/50 rounded-lg">
                        <p className="font-medium mb-2 text-sm">💡 卡片内容：</p>
                        <ul className="space-y-1">
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>材质照片（主体）</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>材质名称（如：粗糙混凝土、光滑金属等）</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>视觉特征（颜色、纹理、光泽）</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>触觉感受（粗糙/光滑、硬/软、冷/暖）</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>情绪联想（这种材质给你什么感觉？）</span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Material Thinking */}
                <Card className="border-2 border-primary/20">
                  <CardHeader>
                    <div className="flex items-center space-x-2">
                      <Eye className="h-5 w-5 text-primary" />
                      <CardTitle>材质思考：为什么这些材质出现在这里？</CardTitle>
                    </div>
                    <CardDescription>
                      思考材质与空间功能、使用者体验的关系
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="p-4 bg-muted/30 rounded-lg">
                      <h4 className="font-semibold mb-2">思考1：功能匹配</h4>
                      <p className="text-sm text-muted-foreground">
                        这些材质为什么被选择用在这里？它们的物理特性（防水、耐磨、保温等）与空间功能是否匹配？
                      </p>
                    </div>
                    <div className="p-4 bg-muted/30 rounded-lg">
                      <h4 className="font-semibold mb-2">思考2：感官体验</h4>
                      <p className="text-sm text-muted-foreground">
                        不同材质给人的感觉如何？冰冷的金属、温暖的木头、柔软的布料——它们如何影响空间氛围？
                      </p>
                    </div>
                    <div className="p-4 bg-muted/30 rounded-lg">
                      <h4 className="font-semibold mb-2">思考3：视觉和谐</h4>
                      <p className="text-sm text-muted-foreground">
                        空间中的材质搭配是否和谐？有没有冲突或不协调的地方？如果让你重新选择，会怎么搭配？
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Tutorials Tab */}
              <TabsContent value="tutorials" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>材质摄影技巧</CardTitle>
                    <CardDescription>如何用手机拍出材质的质感</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ol className="space-y-3">
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">1</span>
                        <div>
                          <p className="font-medium">使用微距模式</p>
                          <p className="text-sm text-muted-foreground">大部分手机都有微距或近距离拍摄模式，能拍出更清晰的细节</p>
                        </div>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">2</span>
                        <div>
                          <p className="font-medium">注意光线方向</p>
                          <p className="text-sm text-muted-foreground">侧光能更好地表现材质的凹凸和纹理，避免正面直射的平光</p>
                        </div>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">3</span>
                        <div>
                          <p className="font-medium">保持稳定</p>
                          <p className="text-sm text-muted-foreground">近距离拍摄容易模糊，可以靠在墙上或使用支撑物保持稳定</p>
                        </div>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">4</span>
                        <div>
                          <p className="font-medium">填满画面</p>
                          <p className="text-sm text-muted-foreground">让材质占据大部分画面，减少无关背景干扰</p>
                        </div>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">5</span>
                        <div>
                          <p className="font-medium">多拍几张</p>
                          <p className="text-sm text-muted-foreground">尝试不同角度和光线，回去再挑选最好的一张</p>
                        </div>
                      </li>
                    </ol>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Canva材质卡片制作</CardTitle>
                    <CardDescription>创建专业的材质库卡片</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ol className="space-y-2">
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">1</span>
                        <span>在Canva中选择Instagram帖子或正方形尺寸（1080x1080px）</span>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">2</span>
                        <span>上传材质照片作为主要视觉元素</span>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">3</span>
                        <span>添加半透明色块作为文字背景，确保文字清晰可读</span>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">4</span>
                        <span>添加材质名称、特征描述和触感标签</span>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">5</span>
                        <span>使用统一的字体和配色方案，保持整体风格一致</span>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">6</span>
                        <span>导出为JPG或PNG，建议使用网格排版展示多张卡片</span>
                      </li>
                    </ol>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Theory Tab */}
              <TabsContent value="theory" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-2xl">材质的视觉属性</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-3">
                      <h3 className="text-xl font-semibold">纹理（Texture）</h3>
                      <p className="text-muted-foreground">材质表面的图案和肌理，可以是规则的（如瓷砖）或随机的（如木纹）</p>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <p className="font-medium mb-2 text-sm">常见纹理类型：</p>
                        <div className="flex flex-wrap gap-2">
                          <Badge variant="secondary">光滑无纹</Badge>
                          <Badge variant="secondary">细密纹理</Badge>
                          <Badge variant="secondary">粗糙纹理</Badge>
                          <Badge variant="secondary">规则图案</Badge>
                          <Badge variant="secondary">自然肌理</Badge>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <h3 className="text-xl font-semibold">光泽度（Glossiness）</h3>
                      <p className="text-muted-foreground">材质反射光线的能力，从完全哑光到镜面反射</p>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <p className="font-medium mb-2 text-sm">光泽等级：</p>
                        <div className="flex flex-wrap gap-2">
                          <Badge variant="secondary">哑光/无光</Badge>
                          <Badge variant="secondary">半哑光</Badge>
                          <Badge variant="secondary">缎面光</Badge>
                          <Badge variant="secondary">半光泽</Badge>
                          <Badge variant="secondary">高光泽/镜面</Badge>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <h3 className="text-xl font-semibold">透明度（Transparency）</h3>
                      <p className="text-muted-foreground">材质允许光线穿透的程度</p>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <p className="font-medium mb-2 text-sm">透明等级：</p>
                        <div className="flex flex-wrap gap-2">
                          <Badge variant="secondary">不透明</Badge>
                          <Badge variant="secondary">半透明</Badge>
                          <Badge variant="secondary">透明</Badge>
                          <Badge variant="secondary">磨砂透明</Badge>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <h3 className="text-xl font-semibold">粗糙度（Roughness）</h3>
                      <p className="text-muted-foreground">材质表面的平整程度，影响触感和视觉质感</p>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <p className="font-medium mb-2 text-sm">粗糙等级：</p>
                        <div className="flex flex-wrap gap-2">
                          <Badge variant="secondary">极度光滑</Badge>
                          <Badge variant="secondary">轻微粗糙</Badge>
                          <Badge variant="secondary">中度粗糙</Badge>
                          <Badge variant="secondary">非常粗糙</Badge>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <h3 className="text-xl font-semibold">颜色与色温</h3>
                      <p className="text-muted-foreground">材质的固有色和给人的冷暖感受</p>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <p className="font-medium mb-2 text-sm">色温感受：</p>
                        <div className="flex flex-wrap gap-2">
                          <Badge variant="secondary">冷色调（金属、石材）</Badge>
                          <Badge variant="secondary">暖色调（木材、织物）</Badge>
                          <Badge variant="secondary">中性色调（混凝土、玻璃）</Badge>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Examples Tab */}
              <TabsContent value="examples" className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>对比材质组合</CardTitle>
                      <CardDescription>粗糙混凝土 + 光滑金属</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="aspect-video bg-muted rounded-lg flex items-center justify-center mb-4">
                        <Image className="h-12 w-12 text-muted-foreground" />
                      </div>
                      <div className="p-3 bg-primary/5 rounded-lg">
                        <p className="text-sm">
                          <span className="font-medium">分析：</span>
                          通过粗糙与光滑的对比，创造视觉张力。混凝土的工业感与金属的现代感形成互补。
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>自然材质层次</CardTitle>
                      <CardDescription>木材纹理的细节捕捉</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="aspect-video bg-muted rounded-lg flex items-center justify-center mb-4">
                        <Image className="h-12 w-12 text-muted-foreground" />
                      </div>
                      <div className="p-3 bg-primary/5 rounded-lg">
                        <p className="text-sm">
                          <span className="font-medium">分析：</span>
                          木材的年轮、色差和纹理变化展现了自然材质的丰富性，温暖而有生命力。
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>透明材质的光影</CardTitle>
                      <CardDescription>玻璃的反射与透射</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="aspect-video bg-muted rounded-lg flex items-center justify-center mb-4">
                        <Image className="h-12 w-12 text-muted-foreground" />
                      </div>
                      <div className="p-3 bg-primary/5 rounded-lg">
                        <p className="text-sm">
                          <span className="font-medium">分析：</span>
                          玻璃同时具有透明和反射特性，在不同光线下呈现不同效果，增加空间层次。
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>织物的柔软质感</CardTitle>
                      <CardDescription>布料的褶皱和纹理</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="aspect-video bg-muted rounded-lg flex items-center justify-center mb-4">
                        <Image className="h-12 w-12 text-muted-foreground" />
                      </div>
                      <div className="p-3 bg-primary/5 rounded-lg">
                        <p className="text-sm">
                          <span className="font-medium">分析：</span>
                          织物的柔软触感通过褶皱和光影变化传达，为空间带来温馨和舒适感。
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              {/* Works Tab */}
              <TabsContent value="works">
                <Card>
                  <CardHeader>
                    <CardTitle>优秀学生作业</CardTitle>
                    <CardDescription>查看往届学生的材质采集作品</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-12 text-muted-foreground">
                      <Award className="h-16 w-16 mx-auto mb-4 opacity-50" />
                      <p>优秀作业正在收集整理中...</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Resources Tab */}
              <TabsContent value="resources" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>拓展资源</CardTitle>
                    <CardDescription>材质相关的参考资料和工具</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <a
                        href="https://www.materialbank.com/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center space-x-3">
                          <Lightbulb className="h-5 w-5 text-primary" />
                          <span>Material Bank - 在线材质库</span>
                        </div>
                        <ExternalLink className="h-4 w-4 text-muted-foreground" />
                      </a>
                      <a
                        href="https://www.pinterest.com/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center space-x-3">
                          <BookOpen className="h-5 w-5 text-primary" />
                          <span>Pinterest - 材质灵感收集</span>
                        </div>
                        <ExternalLink className="h-4 w-4 text-muted-foreground" />
                      </a>
                      <a
                        href="https://www.canva.cn/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center space-x-3">
                          <Lightbulb className="h-5 w-5 text-primary" />
                          <span>Canva - 材质卡片制作工具</span>
                        </div>
                        <ExternalLink className="h-4 w-4 text-muted-foreground" />
                      </a>
                    </div>
                  </CardContent>
                </Card>

                {/* Common Pitfalls */}
                <Card className="border-destructive/50">
                  <CardHeader>
                    <div className="flex items-center space-x-2">
                      <AlertCircle className="h-5 w-5 text-destructive" />
                      <CardTitle>常见问题</CardTitle>
                    </div>
                    <CardDescription>材质采集中的常见错误</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex items-start space-x-2">
                          <span className="text-destructive font-bold">❌</span>
                          <p className="text-sm">只拍远景：材质细节看不清，失去了采集的意义</p>
                        </div>
                        <div className="flex items-start space-x-2 ml-6">
                          <span className="text-green-600 font-bold">✅</span>
                          <p className="text-sm font-medium text-green-600">靠近拍摄，填满画面，看清纹理！</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-start space-x-2">
                          <span className="text-destructive font-bold">❌</span>
                          <p className="text-sm">材质类型单一：只收集了硬质材料或只收集了自然材料</p>
                        </div>
                        <div className="flex items-start space-x-2 ml-6">
                          <span className="text-green-600 font-bold">✅</span>
                          <p className="text-sm font-medium text-green-600">追求多样性！硬软、粗糙光滑、自然人工都要有！</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-start space-x-2">
                          <span className="text-destructive font-bold">❌</span>
                          <p className="text-sm">只看不摸：忽略了触觉感受，材质描述空洞</p>
                        </div>
                        <div className="flex items-start space-x-2 ml-6">
                          <span className="text-green-600 font-bold">✅</span>
                          <p className="text-sm font-medium text-green-600">用手去感受！温度、质感、粗糙度都要记录！</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-start space-x-2">
                          <span className="text-destructive font-bold">❌</span>
                          <p className="text-sm">光线不佳：逆光或阴影太重，材质特征无法呈现</p>
                        </div>
                        <div className="flex items-start space-x-2 ml-6">
                          <span className="text-green-600 font-bold">✅</span>
                          <p className="text-sm font-medium text-green-600">选择合适的光线，侧光最能表现质感！</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Next Steps */}
                <Card className="bg-primary/5 border-primary/20">
                  <CardHeader>
                    <CardTitle>下一步</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <p className="text-sm">恭喜！你已经建立了自己的材质库，开始用设计师的眼光观察世界。</p>
                      <p className="text-sm">这些材质不仅是视觉元素，更是情绪和氛围的载体。</p>
                      <p className="text-sm">思考：如果让你为你的微空间重新选择材质，你会如何搭配？为什么？</p>
                      <p className="text-sm">准备：在接下来的课程中，我们将学习如何用这些材质元素进行设计组合和创意表达！</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>

            {/* Navigation */}
            <div className="flex justify-between mt-12 pt-8 border-t">
              <Link href="/curriculum/1">
                <Button variant="outline">
                  <ChevronLeft className="h-4 w-4 mr-2" />
                  上一节：观·元素解构
                </Button>
              </Link>
              <Link href="/curriculum">
                <Button>
                  返回课程大纲
                  <ChevronRight className="h-4 w-4 ml-2" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t py-8 bg-muted/30">
        <div className="container">
          <div className="text-center text-sm text-muted-foreground">
            <p>© 2025 数字设计构成课程</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

