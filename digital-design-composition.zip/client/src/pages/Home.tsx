import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Navigation from "@/components/Navigation";
import { BookOpen, Boxes, Brain, Lightbulb, Library, Sparkles, Target } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-primary/10 via-accent/5 to-background py-20">
          <div className="container">
            <div className="max-w-4xl mx-auto text-center space-y-6">
              <div className="inline-flex items-center space-x-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium">
                <Sparkles className="h-4 w-4" />
                <span>设计的"字母表"正在进化</span>
              </div>
              
              <h1 className="text-5xl md:text-6xl font-bold tracking-tight">
                数字设计构成
              </h1>
              
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                探索设计最底层的构成原理——点线面、色彩情绪、空间秩序。
                用最前沿的数字工具（特别是AI）作为画笔和刻刀，
                掌握能伴随整个设计生涯的思考框架和实战工作流。
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
                <Link href="/curriculum">
                  <Button size="lg" className="text-lg px-8">
                    开始学习
                  </Button>
                </Link>
                <Link href="/knowledge">
                  <Button size="lg" variant="outline" className="text-lg px-8">
                    浏览知识卡片
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Core Philosophy */}
        <section className="py-16 bg-muted/30">
          <div className="container">
            <h2 className="text-3xl font-bold text-center mb-12">核心理念</h2>
            
            <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              <Card className="border-2 hover:border-primary/50 transition-colors">
                <CardHeader>
                  <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                    <Brain className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>构成是思维</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    工具日新月异，但构成原理（和谐、对比、节奏、平衡）是设计的永恒根基。
                    掌握它，你就能驾驭任何工具。
                  </CardDescription>
                </CardContent>
              </Card>

              <Card className="border-2 hover:border-primary/50 transition-colors">
                <CardHeader>
                  <div className="h-12 w-12 rounded-lg bg-accent/20 flex items-center justify-center mb-4">
                    <Sparkles className="h-6 w-6 text-accent-foreground" />
                  </div>
                  <CardTitle>AI 是伙伴</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    AI不是取代设计师的"魔法盒"，而是加速创意、探索未知的智能伙伴。
                    我们要学会"提问"、"引导"、"指挥"AI。
                  </CardDescription>
                </CardContent>
              </Card>

              <Card className="border-2 hover:border-primary/50 transition-colors">
                <CardHeader>
                  <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                    <Target className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>过程即学习</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    好的设计很少一蹴而就。拥抱迭代、试错、反思。
                    每一次"失败"的尝试都比"完美"的停滞更有价值。
                  </CardDescription>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Three Spiral Loops */}
        <section className="py-16">
          <div className="container">
            <h2 className="text-3xl font-bold text-center mb-4">三轮螺旋教学法</h2>
            <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
              设计不是直线跑，而是螺旋上升的过程。每一轮都在上一轮的基础上，提升精度和深度。
            </p>
            
            <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
              <Card className="relative overflow-hidden">
                <div className="absolute top-0 right-0 w-24 h-24 bg-primary/10 rounded-bl-full" />
                <CardHeader>
                  <div className="text-sm font-medium text-primary mb-2">Loop 1 · 6小时</div>
                  <CardTitle className="text-2xl">概念冲刺</CardTitle>
                  <CardDescription>第1-2节课</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-start space-x-2">
                    <div className="h-2 w-2 rounded-full bg-primary mt-2" />
                    <p className="text-sm">快速感知：AI头脑风暴</p>
                  </div>
                  <div className="flex items-start space-x-2">
                    <div className="h-2 w-2 rounded-full bg-primary mt-2" />
                    <p className="text-sm">低保真原型：概念草图 + 情绪体块</p>
                  </div>
                  <div className="flex items-start space-x-2">
                    <div className="h-2 w-2 rounded-full bg-primary mt-2" />
                    <p className="text-sm">初步反馈：概念汇报</p>
                  </div>
                  <div className="pt-2 border-t">
                    <p className="text-sm font-medium">🎯 目标：定义方向</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="relative overflow-hidden">
                <div className="absolute top-0 right-0 w-24 h-24 bg-accent/20 rounded-bl-full" />
                <CardHeader>
                  <div className="text-sm font-medium text-accent-foreground mb-2">Loop 2 · 15小时</div>
                  <CardTitle className="text-2xl">形态冲刺</CardTitle>
                  <CardDescription>第3-7节课</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-start space-x-2">
                    <div className="h-2 w-2 rounded-full bg-accent-foreground mt-2" />
                    <p className="text-sm">深化构成：平面迭代 + 精细手工</p>
                  </div>
                  <div className="flex items-start space-x-2">
                    <div className="h-2 w-2 rounded-full bg-accent-foreground mt-2" />
                    <p className="text-sm">物理转译：模型拍摄 + AI图生图</p>
                  </div>
                  <div className="flex items-start space-x-2">
                    <div className="h-2 w-2 rounded-full bg-accent-foreground mt-2" />
                    <p className="text-sm">迭代反馈：形态汇报</p>
                  </div>
                  <div className="pt-2 border-t">
                    <p className="text-sm font-medium">🎯 目标：确立形态</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="relative overflow-hidden">
                <div className="absolute top-0 right-0 w-24 h-24 bg-primary/10 rounded-bl-full" />
                <CardHeader>
                  <div className="text-sm font-medium text-primary mb-2">Loop 3 · 15小时</div>
                  <CardTitle className="text-2xl">精炼冲刺</CardTitle>
                  <CardDescription>第8-12节课</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-start space-x-2">
                    <div className="h-2 w-2 rounded-full bg-primary mt-2" />
                    <p className="text-sm">数字迭代：数字建模 + AI精修</p>
                  </div>
                  <div className="flex items-start space-x-2">
                    <div className="h-2 w-2 rounded-full bg-primary mt-2" />
                    <p className="text-sm">方案整合：5页方案书</p>
                  </div>
                  <div className="flex items-start space-x-2">
                    <div className="h-2 w-2 rounded-full bg-primary mt-2" />
                    <p className="text-sm">专业呈现：最终汇报</p>
                  </div>
                  <div className="pt-2 border-t">
                    <p className="text-sm font-medium">🎯 目标：优化方案</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Quick Navigation */}
        <section className="py-16 bg-muted/30">
          <div className="container">
            <h2 className="text-3xl font-bold text-center mb-12">快速导航</h2>
            
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
              <Link href="/curriculum">
                <Card className="hover:shadow-lg transition-shadow cursor-pointer h-full">
                  <CardHeader>
                    <BookOpen className="h-8 w-8 text-primary mb-2" />
                    <CardTitle>课程大纲</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription>
                      12节课程详细内容，包含学习目标、核心活动和交付成果
                    </CardDescription>
                  </CardContent>
                </Card>
              </Link>

              <Link href="/knowledge">
                <Card className="hover:shadow-lg transition-shadow cursor-pointer h-full">
                  <CardHeader>
                    <Lightbulb className="h-8 w-8 text-primary mb-2" />
                    <CardTitle>知识卡片</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription>
                      平面构成、色彩构成、空间构成的理论要点和案例分析
                    </CardDescription>
                  </CardContent>
                </Card>
              </Link>

              <Link href="/cases">
                <Card className="hover:shadow-lg transition-shadow cursor-pointer h-full">
                  <CardHeader>
                    <Boxes className="h-8 w-8 text-primary mb-2" />
                    <CardTitle>案例库</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription>
                      优秀学生作品和专业设计案例，按专业和构成原理分类
                    </CardDescription>
                  </CardContent>
                </Card>
              </Link>

              <Link href="/resources">
                <Card className="hover:shadow-lg transition-shadow cursor-pointer h-full">
                  <CardHeader>
                    <Library className="h-8 w-8 text-primary mb-2" />
                    <CardTitle>学习资源</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription>
                      在线工具、教程视频、拓展阅读和AI提示词模板
                    </CardDescription>
                  </CardContent>
                </Card>
              </Link>
            </div>
          </div>
        </section>

        {/* Learning Outcomes */}
        <section className="py-16">
          <div className="container">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl font-bold text-center mb-4">学习成果</h2>
              <p className="text-center text-muted-foreground mb-12">
                完成36小时的学习旅程后，你将能够：
              </p>
              
              <div className="grid sm:grid-cols-2 gap-6">
                <div className="flex items-start space-x-4">
                  <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <span className="text-primary font-bold">✓</span>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">看懂设计</h3>
                    <p className="text-sm text-muted-foreground">
                      运用构成原理（点线面、色彩、空间）分析现实空间与设计作品
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <span className="text-primary font-bold">✓</span>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">玩转工具</h3>
                    <p className="text-sm text-muted-foreground">
                      掌握包含手工、轻量数字工具及AI的现代设计工作流
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <span className="text-primary font-bold">✓</span>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">独立创作</h3>
                    <p className="text-sm text-muted-foreground">
                      完成一个从概念到呈现的"构成单元设计"跨专业项目
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <span className="text-primary font-bold">✓</span>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">设计思维</h3>
                    <p className="text-sm text-muted-foreground">
                      建立迭代、反思的设计思维习惯，并能清晰地沟通你的设计
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t py-8 bg-muted/30">
        <div className="container">
          <div className="text-center text-sm text-muted-foreground">
            <p>© 2025 数字设计构成课程 · 面向环境设计、产品设计、视觉设计、公共艺术设计本科一年级学生</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

