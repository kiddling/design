import Navigation from "@/components/Navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Target, 
  BookOpen, 
  Lightbulb, 
  Image, 
  Award, 
  ExternalLink, 
  ChevronLeft, 
  ChevronRight,
  Layers,
  Eye,
  AlertCircle,
  Box
} from "lucide-react";
import { Link } from "wouter";

export default function Lesson04() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1 py-8">
        <div className="container">
          <div className="max-w-6xl mx-auto">
            {/* Header */}
            <div className="mb-8">
              <Link href="/curriculum">
                <Button variant="ghost" className="mb-4">
                  <ChevronLeft className="h-4 w-4 mr-2" />
                  返回课程大纲
                </Button>
              </Link>
              
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <Badge>第4节</Badge>
                    <Badge variant="outline">3小时</Badge>
                    <Badge variant="outline">课前20分钟 + 课中90分钟</Badge>
                  </div>
                  <h1 className="text-4xl font-bold mb-2">塑·空间幻觉</h1>
                  <p className="text-xl text-muted-foreground">Spatial Illusion</p>
                </div>
              </div>
            </div>

            {/* Learning Objectives */}
            <Card className="mb-8">
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <Target className="h-5 w-5 text-primary" />
                  <CardTitle>学习目标</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span>理解平面如何创造空间深度的幻觉</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span>掌握五种空间表现技法：重叠、大小对比、透视、明暗、清晰度</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span>学会运用图层和透明度创造层次感</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span>培养三维空间思维，能够在二维平面上表现深度</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Main Content Tabs */}
            <Tabs defaultValue="tasks" className="space-y-6">
              <TabsList className="grid w-full grid-cols-6">
                <TabsTrigger value="tasks">
                  <Box className="h-4 w-4 mr-2" />
                  任务卡片
                </TabsTrigger>
                <TabsTrigger value="tutorials">
                  <Layers className="h-4 w-4 mr-2" />
                  教程
                </TabsTrigger>
                <TabsTrigger value="theory">
                  <BookOpen className="h-4 w-4 mr-2" />
                  理论
                </TabsTrigger>
                <TabsTrigger value="examples">
                  <Image className="h-4 w-4 mr-2" />
                  案例
                </TabsTrigger>
                <TabsTrigger value="works">
                  <Award className="h-4 w-4 mr-2" />
                  优秀作业
                </TabsTrigger>
                <TabsTrigger value="resources">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  拓展
                </TabsTrigger>
              </TabsList>

              {/* Tasks Tab */}
              <TabsContent value="tasks" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-2xl">空间幻觉创造：让平面拥有深度</CardTitle>
                    <CardDescription className="text-base">
                      二维的屏幕如何表现三维的世界？这节课，我们要学习在平面上创造空间深度的魔法，
                      让你的设计从"扁平"变得"立体"，从"单薄"变得"丰富"。
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Task 1 */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-lg flex items-center space-x-2">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground text-sm">1</span>
                        <span>任务1：重叠层次构成（Base难度）</span>
                      </h4>
                      <p className="text-muted-foreground ml-8">
                        使用重叠技法创作一幅具有前中后景的构成，至少包含三个层次。
                      </p>
                      <div className="ml-8 p-4 bg-muted/50 rounded-lg">
                        <p className="font-medium mb-2 text-sm">💡 创作要求：</p>
                        <ul className="space-y-1">
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>画布尺寸：横向矩形（如1920x1080px）</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>至少3个图层：前景、中景、后景</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>前景元素遮挡中景，中景遮挡后景</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>可以使用几何形状或你拍摄的材质照片</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>颜色从前到后逐渐变浅或变灰</span>
                          </li>
                        </ul>
                      </div>
                    </div>

                    {/* Task 2 */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-lg flex items-center space-x-2">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground text-sm">2</span>
                        <span>任务2：透视空间构成（Advance难度）</span>
                      </h4>
                      <p className="text-muted-foreground ml-8">
                        运用线性透视原理，创作一幅具有明显消失点的空间构成。
                      </p>
                      <div className="ml-8 p-4 bg-muted/50 rounded-lg">
                        <p className="font-medium mb-2 text-sm">💡 创作要求：</p>
                        <ul className="space-y-1">
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>画布尺寸：正方形或横向矩形</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>确定一个或两个消失点</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>使用线条或形状表现透视关系</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>近大远小：前景元素大，远景元素小</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>可以表现道路、建筑、隧道等具有透视感的场景</span>
                          </li>
                        </ul>
                      </div>
                    </div>

                    {/* Task 3 */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-lg flex items-center space-x-2">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground text-sm">3</span>
                        <span>任务3：综合空间表现（Stretch难度）</span>
                      </h4>
                      <p className="text-muted-foreground ml-8">
                        综合运用重叠、透视、明暗、清晰度等多种技法，创作一幅层次丰富的空间构成。
                      </p>
                      <div className="ml-8 p-4 bg-muted/50 rounded-lg">
                        <p className="font-medium mb-2 text-sm">💡 创作要求：</p>
                        <ul className="space-y-1">
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>画布尺寸：自由选择</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>至少使用4种空间表现技法</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>重叠：前中后景明确</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>透视：近大远小的关系</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>明暗：前景明亮清晰，后景暗淡模糊</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>清晰度：前景锐利，后景柔和</span>
                          </li>
                        </ul>
                      </div>
                    </div>

                    {/* Workflow */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-lg flex items-center space-x-2">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground text-sm">4</span>
                        <span>工作流程</span>
                      </h4>
                      <div className="ml-8 space-y-2">
                        <div className="p-3 bg-primary/5 rounded-lg">
                          <p className="font-medium text-sm mb-1">步骤1：规划层次</p>
                          <p className="text-sm text-muted-foreground">在草图上规划前中后景的内容和位置，确定空间关系</p>
                        </div>
                        <div className="p-3 bg-primary/5 rounded-lg">
                          <p className="font-medium text-sm mb-1">步骤2：创建图层</p>
                          <p className="text-sm text-muted-foreground">在Canva中创建多个图层，从后景开始绘制</p>
                        </div>
                        <div className="p-3 bg-primary/5 rounded-lg">
                          <p className="font-medium text-sm mb-1">步骤3：调整深度</p>
                          <p className="text-sm text-muted-foreground">通过大小、颜色、清晰度调整各层次的空间感</p>
                        </div>
                        <div className="p-3 bg-primary/5 rounded-lg">
                          <p className="font-medium text-sm mb-1">步骤4：细节优化</p>
                          <p className="text-sm text-muted-foreground">添加阴影、光效、模糊等细节，增强空间深度</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Depth Perception */}
                <Card className="border-2 border-primary/20">
                  <CardHeader>
                    <div className="flex items-center space-x-2">
                      <Eye className="h-5 w-5 text-primary" />
                      <CardTitle>空间深度感知训练</CardTitle>
                    </div>
                    <CardDescription>
                      如何判断你的构成是否具有空间深度？
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="p-4 bg-muted/30 rounded-lg">
                      <h4 className="font-semibold mb-2">测试1：遮挡关系</h4>
                      <p className="text-sm text-muted-foreground">
                        能否清晰分辨哪些元素在前，哪些在后？前景是否遮挡了后景？
                      </p>
                    </div>
                    <div className="p-4 bg-muted/30 rounded-lg">
                      <h4 className="font-semibold mb-2">测试2：视线引导</h4>
                      <p className="text-sm text-muted-foreground">
                        画面是否引导你的视线从前景移动到后景，产生纵深感？
                      </p>
                    </div>
                    <div className="p-4 bg-muted/30 rounded-lg">
                      <h4 className="font-semibold mb-2">测试3：层次数量</h4>
                      <p className="text-sm text-muted-foreground">
                        能否识别出至少3个不同的空间层次？层次越多，空间感越强。
                      </p>
                    </div>
                    <div className="p-4 bg-muted/30 rounded-lg">
                      <h4 className="font-semibold mb-2">测试4：对比明显</h4>
                      <p className="text-sm text-muted-foreground">
                        前景和后景的对比是否明显？大小、明暗、清晰度的差异是否足够？
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Tutorials Tab */}
              <TabsContent value="tutorials" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Canva图层管理技巧</CardTitle>
                    <CardDescription>如何在Canva中创建和管理空间层次</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ol className="space-y-3">
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">1</span>
                        <div>
                          <p className="font-medium">理解图层顺序</p>
                          <p className="text-sm text-muted-foreground">在Canva中，后添加的元素会覆盖先添加的元素。使用"图层"面板调整前后顺序。</p>
                        </div>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">2</span>
                        <div>
                          <p className="font-medium">使用"置于顶层/底层"</p>
                          <p className="text-sm text-muted-foreground">右键点击元素，选择"置于顶层"或"置于底层"快速调整层次</p>
                        </div>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">3</span>
                        <div>
                          <p className="font-medium">调整透明度</p>
                          <p className="text-sm text-muted-foreground">选中元素，调整透明度滑块，后景可以设置为50-70%透明度</p>
                        </div>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">4</span>
                        <div>
                          <p className="font-medium">应用模糊效果</p>
                          <p className="text-sm text-muted-foreground">使用"效果"中的"模糊"功能，让后景元素变得柔和，增强空间感</p>
                        </div>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">5</span>
                        <div>
                          <p className="font-medium">组合与锁定</p>
                          <p className="text-sm text-muted-foreground">将同一层次的元素组合，避免误操作；完成的图层可以锁定</p>
                        </div>
                      </li>
                    </ol>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>空间深度增强技巧</CardTitle>
                    <CardDescription>让你的构成更有立体感</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2">技巧1：色彩大气透视</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          前景使用饱和度高、对比强的颜色；后景使用饱和度低、偏蓝灰的颜色。
                        </p>
                        <p className="text-xs text-muted-foreground">
                          例如：前景用鲜红色，中景用暗红色，后景用灰蓝色
                        </p>
                      </div>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2">技巧2：细节递减</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          前景元素细节丰富、边缘清晰；后景元素简化、边缘柔和。
                        </p>
                        <p className="text-xs text-muted-foreground">
                          例如：前景的树叶清晰可见，后景的树只是模糊的剪影
                        </p>
                      </div>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2">技巧3：阴影投射</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          为前景元素添加阴影，让它们"浮"在画面上，与背景分离。
                        </p>
                        <p className="text-xs text-muted-foreground">
                          使用Canva的"阴影"效果，调整偏移和模糊程度
                        </p>
                      </div>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2">技巧4：视线引导线</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          使用线条或元素排列引导视线从前景延伸到后景，创造纵深感。
                        </p>
                        <p className="text-xs text-muted-foreground">
                          例如：道路、栅栏、河流等线性元素
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Theory Tab */}
              <TabsContent value="theory" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-2xl">五种空间表现技法</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-3">
                      <h3 className="text-xl font-semibold">1. 重叠（Overlapping）</h3>
                      <p className="text-muted-foreground">
                        当一个物体遮挡另一个物体时，我们的大脑会自动判断被遮挡的物体在后面。这是最直接、最有效的空间表现方法。
                      </p>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <p className="font-medium mb-2 text-sm">应用要点：</p>
                        <div className="space-y-1">
                          <p className="text-sm">✓ 前景元素完整，后景元素被部分遮挡</p>
                          <p className="text-sm">✓ 遮挡关系要清晰，避免模糊不清</p>
                          <p className="text-sm">✓ 可以创建多个层次的重叠</p>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <h3 className="text-xl font-semibold">2. 大小对比（Size Contrast）</h3>
                      <p className="text-muted-foreground">
                        近大远小是透视的基本原理。相同大小的物体，离我们越近看起来越大，越远看起来越小。
                      </p>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <p className="font-medium mb-2 text-sm">应用要点：</p>
                        <div className="space-y-1">
                          <p className="text-sm">✓ 前景元素尺寸大，后景元素尺寸小</p>
                          <p className="text-sm">✓ 大小变化要有规律，形成渐变</p>
                          <p className="text-sm">✓ 可以用重复元素的大小变化表现深度</p>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <h3 className="text-xl font-semibold">3. 线性透视（Linear Perspective）</h3>
                      <p className="text-muted-foreground">
                        平行线在远处会汇聚到一个消失点。这是文艺复兴时期发现的重要空间表现原理。
                      </p>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <p className="font-medium mb-2 text-sm">透视类型：</p>
                        <div className="space-y-2">
                          <div>
                            <p className="text-sm font-medium">一点透视</p>
                            <p className="text-xs text-muted-foreground">适合表现正面观看的场景，如道路、走廊</p>
                          </div>
                          <div>
                            <p className="text-sm font-medium">两点透视</p>
                            <p className="text-xs text-muted-foreground">适合表现建筑物的转角视角</p>
                          </div>
                          <div>
                            <p className="text-sm font-medium">三点透视</p>
                            <p className="text-xs text-muted-foreground">适合表现仰视或俯视的场景</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <h3 className="text-xl font-semibold">4. 明暗层次（Value Gradient）</h3>
                      <p className="text-muted-foreground">
                        前景明亮清晰，后景暗淡模糊。明暗对比可以有效区分空间层次。
                      </p>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <p className="font-medium mb-2 text-sm">应用要点：</p>
                        <div className="space-y-1">
                          <p className="text-sm">✓ 前景使用高对比度的明暗关系</p>
                          <p className="text-sm">✓ 后景降低对比度，趋向中间灰</p>
                          <p className="text-sm">✓ 可以配合光源方向增强立体感</p>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <h3 className="text-xl font-semibold">5. 清晰度渐变（Atmospheric Perspective）</h3>
                      <p className="text-muted-foreground">
                        也称为大气透视。由于空气中的微粒，远处的物体看起来更模糊、更偏蓝灰色。
                      </p>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <p className="font-medium mb-2 text-sm">应用要点：</p>
                        <div className="space-y-1">
                          <p className="text-sm">✓ 前景边缘锐利，细节清晰</p>
                          <p className="text-sm">✓ 后景边缘柔和，细节模糊</p>
                          <p className="text-sm">✓ 后景颜色饱和度降低，偏向蓝灰</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-2xl">空间深度的心理学</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-4">
                      我们的大脑是如何从二维图像中感知三维空间的？这涉及到视觉心理学的深度线索（Depth Cues）理论。
                    </p>
                    <div className="space-y-3">
                      <div className="p-4 border-l-4 border-primary">
                        <h4 className="font-semibold mb-1">单眼线索</h4>
                        <p className="text-sm text-muted-foreground">
                          只需要一只眼睛就能感知的深度信息，包括重叠、大小、透视、明暗、清晰度等。这些是平面设计中最常用的技法。
                        </p>
                      </div>
                      <div className="p-4 border-l-4 border-primary">
                        <h4 className="font-semibold mb-1">双眼线索</h4>
                        <p className="text-sm text-muted-foreground">
                          需要两只眼睛协同工作才能感知的深度信息，如立体视觉。在平面设计中无法直接应用，但可以通过VR/AR技术实现。
                        </p>
                      </div>
                      <div className="p-4 border-l-4 border-primary">
                        <h4 className="font-semibold mb-1">运动线索</h4>
                        <p className="text-sm text-muted-foreground">
                          通过物体或观察者的运动感知深度，如运动视差。在动态设计（动画、视频）中可以应用。
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Examples Tab */}
              <TabsContent value="examples" className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>经典重叠构成</CardTitle>
                      <CardDescription>日本浮世绘的空间表现</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="aspect-square bg-muted rounded-lg flex items-center justify-center mb-4">
                        <Image className="h-12 w-12 text-muted-foreground" />
                      </div>
                      <div className="p-3 bg-primary/5 rounded-lg">
                        <p className="text-sm">
                          <span className="font-medium">分析：</span>
                          葛饰北斋的《神奈川冲浪里》通过前景的巨浪、中景的船只、远景的富士山，创造了三个清晰的空间层次。
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>透视空间杰作</CardTitle>
                      <CardDescription>文艺复兴的透视法</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="aspect-square bg-muted rounded-lg flex items-center justify-center mb-4">
                        <Image className="h-12 w-12 text-muted-foreground" />
                      </div>
                      <div className="p-3 bg-primary/5 rounded-lg">
                        <p className="text-sm">
                          <span className="font-medium">分析：</span>
                          达芬奇《最后的晚餐》运用一点透视，所有线条汇聚到画面中心的基督头部，创造强烈的纵深感。
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>大气透视典范</CardTitle>
                      <CardDescription>中国山水画的空间表现</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="aspect-square bg-muted rounded-lg flex items-center justify-center mb-4">
                        <Image className="h-12 w-12 text-muted-foreground" />
                      </div>
                      <div className="p-3 bg-primary/5 rounded-lg">
                        <p className="text-sm">
                          <span className="font-medium">分析：</span>
                          中国山水画通过墨色浓淡表现空间：近山浓墨，远山淡墨，营造出"远山如黛"的空间感。
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>现代空间设计</CardTitle>
                      <CardDescription>UI设计中的层次感</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="aspect-square bg-muted rounded-lg flex items-center justify-center mb-4">
                        <Image className="h-12 w-12 text-muted-foreground" />
                      </div>
                      <div className="p-3 bg-primary/5 rounded-lg">
                        <p className="text-sm">
                          <span className="font-medium">分析：</span>
                          Material Design通过阴影和高度（elevation）创造层次感，让界面元素具有空间深度。
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              {/* Works Tab */}
              <TabsContent value="works">
                <Card>
                  <CardHeader>
                    <CardTitle>优秀学生作业</CardTitle>
                    <CardDescription>查看往届学生的空间构成作品</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-12 text-muted-foreground">
                      <Award className="h-16 w-16 mx-auto mb-4 opacity-50" />
                      <p>优秀作业正在收集整理中...</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Resources Tab */}
              <TabsContent value="resources" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>拓展资源</CardTitle>
                    <CardDescription>空间表现相关的参考资料和工具</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <a
                        href="https://www.canva.cn/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center space-x-3">
                          <Lightbulb className="h-5 w-5 text-primary" />
                          <span>Canva - 在线设计工具</span>
                        </div>
                        <ExternalLink className="h-4 w-4 text-muted-foreground" />
                      </a>
                      <a
                        href="https://www.zcool.com.cn/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center space-x-3">
                          <BookOpen className="h-5 w-5 text-primary" />
                          <span>站酷 - 空间设计作品参考</span>
                        </div>
                        <ExternalLink className="h-4 w-4 text-muted-foreground" />
                      </a>
                      <a
                        href="https://www.bilibili.com/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center space-x-3">
                          <BookOpen className="h-5 w-5 text-primary" />
                          <span>哔哩哔哩 - 透视原理视频教程</span>
                        </div>
                        <ExternalLink className="h-4 w-4 text-muted-foreground" />
                      </a>
                    </div>
                  </CardContent>
                </Card>

                {/* Common Pitfalls */}
                <Card className="border-destructive/50">
                  <CardHeader>
                    <div className="flex items-center space-x-2">
                      <AlertCircle className="h-5 w-5 text-destructive" />
                      <CardTitle>常见问题</CardTitle>
                    </div>
                    <CardDescription>空间构成中的常见错误</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex items-start space-x-2">
                          <span className="text-destructive font-bold">❌</span>
                          <p className="text-sm">层次不清：所有元素都在同一平面上，没有前后关系</p>
                        </div>
                        <div className="flex items-start space-x-2 ml-6">
                          <span className="text-green-600 font-bold">✅</span>
                          <p className="text-sm font-medium text-green-600">使用重叠和大小对比明确层次！</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-start space-x-2">
                          <span className="text-destructive font-bold">❌</span>
                          <p className="text-sm">透视混乱：不同元素的消失点不一致</p>
                        </div>
                        <div className="flex items-start space-x-2 ml-6">
                          <span className="text-green-600 font-bold">✅</span>
                          <p className="text-sm font-medium text-green-600">确定统一的消失点和视平线！</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-start space-x-2">
                          <span className="text-destructive font-bold">❌</span>
                          <p className="text-sm">对比不足：前景和后景的差异太小，空间感弱</p>
                        </div>
                        <div className="flex items-start space-x-2 ml-6">
                          <span className="text-green-600 font-bold">✅</span>
                          <p className="text-sm font-medium text-green-600">加大前后景的大小、明暗、清晰度对比！</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-start space-x-2">
                          <span className="text-destructive font-bold">❌</span>
                          <p className="text-sm">过度模糊：后景模糊过度，失去了形态特征</p>
                        </div>
                        <div className="flex items-start space-x-2 ml-6">
                          <span className="text-green-600 font-bold">✅</span>
                          <p className="text-sm font-medium text-green-600">保持后景的基本形态，适度模糊！</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Next Steps */}
                <Card className="bg-primary/5 border-primary/20">
                  <CardHeader>
                    <CardTitle>下一步</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <p className="text-sm">恭喜你！你已经掌握了在平面上创造空间幻觉的技法。</p>
                      <p className="text-sm">空间感是设计中的重要元素——它让画面更有深度、更有吸引力、更能引导观众的视线。</p>
                      <p className="text-sm">思考：在你喜欢的设计作品中，设计师是如何创造空间深度的？用了哪些技法？</p>
                      <p className="text-sm">准备：接下来我们将学习色彩的情感表达，让你的设计不仅有形，更有情！</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>

            {/* Navigation */}
            <div className="flex justify-between mt-12 pt-8 border-t">
              <Link href="/curriculum/3">
                <Button variant="outline">
                  <ChevronLeft className="h-4 w-4 mr-2" />
                  上一节：构·动态平衡
                </Button>
              </Link>
              <Link href="/curriculum">
                <Button>
                  返回课程大纲
                  <ChevronRight className="h-4 w-4 ml-2" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t py-8 bg-muted/30">
        <div className="container">
          <div className="text-center text-sm text-muted-foreground">
            <p>© 2025 数字设计构成课程</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

