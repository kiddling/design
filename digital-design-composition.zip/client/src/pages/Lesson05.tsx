import Navigation from "@/components/Navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Target, 
  BookOpen, 
  Lightbulb, 
  Image, 
  Award, 
  ExternalLink, 
  ChevronLeft, 
  ChevronRight,
  Sun,
  Moon,
  Eye,
  AlertCircle,
  Zap
} from "lucide-react";
import { Link } from "wouter";

export default function Lesson05() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1 py-8">
        <div className="container">
          <div className="max-w-6xl mx-auto">
            {/* Header */}
            <div className="mb-8">
              <Link href="/curriculum">
                <Button variant="ghost" className="mb-4">
                  <ChevronLeft className="h-4 w-4 mr-2" />
                  返回课程大纲
                </Button>
              </Link>
              
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <Badge>第5节</Badge>
                    <Badge variant="outline">3小时</Badge>
                    <Badge variant="outline">课前20分钟 + 课中90分钟</Badge>
                  </div>
                  <h1 className="text-4xl font-bold mb-2">光·明暗表现</h1>
                  <p className="text-xl text-muted-foreground">Light and Shadow</p>
                </div>
              </div>
            </div>

            {/* Learning Objectives */}
            <Card className="mb-8">
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <Target className="h-5 w-5 text-primary" />
                  <CardTitle>学习目标</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span>理解光影在设计中的重要作用和表现力</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span>掌握明暗五调子：高光、亮面、明暗交界线、暗面、反光</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span>学会运用光影创造体积感、氛围感和戏剧性</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span>培养对光线的敏感度，能够观察和表现不同光源效果</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Main Content Tabs */}
            <Tabs defaultValue="tasks" className="space-y-6">
              <TabsList className="grid w-full grid-cols-6">
                <TabsTrigger value="tasks">
                  <Sun className="h-4 w-4 mr-2" />
                  任务卡片
                </TabsTrigger>
                <TabsTrigger value="tutorials">
                  <Zap className="h-4 w-4 mr-2" />
                  教程
                </TabsTrigger>
                <TabsTrigger value="theory">
                  <BookOpen className="h-4 w-4 mr-2" />
                  理论
                </TabsTrigger>
                <TabsTrigger value="examples">
                  <Image className="h-4 w-4 mr-2" />
                  案例
                </TabsTrigger>
                <TabsTrigger value="works">
                  <Award className="h-4 w-4 mr-2" />
                  优秀作业
                </TabsTrigger>
                <TabsTrigger value="resources">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  拓展
                </TabsTrigger>
              </TabsList>

              {/* Tasks Tab */}
              <TabsContent value="tasks" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-2xl">光影魔法：让设计充满生命力</CardTitle>
                    <CardDescription className="text-base">
                      光是设计的灵魂！没有光，就没有色彩、没有形态、没有空间。这节课，我们要学习如何用光影
                      赋予设计作品体积感、氛围感和情感表达，让平面设计"活"起来。
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Task 1 */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-lg flex items-center space-x-2">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground text-sm">1</span>
                        <span>任务1：单一光源构成（Base难度）</span>
                      </h4>
                      <p className="text-muted-foreground ml-8">
                        创作一幅具有明确单一光源的构成，表现明暗对比和体积感。
                      </p>
                      <div className="ml-8 p-4 bg-muted/50 rounded-lg">
                        <p className="font-medium mb-2 text-sm">💡 创作要求：</p>
                        <ul className="space-y-1">
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>画布尺寸：正方形（如1080x1080px）</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>确定一个光源位置（如左上角）</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>使用几何形状（球体、立方体等）</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>表现明暗五调子：高光、亮面、明暗交界线、暗面、反光</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>添加投影，增强立体感</span>
                          </li>
                        </ul>
                      </div>
                    </div>

                    {/* Task 2 */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-lg flex items-center space-x-2">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground text-sm">2</span>
                        <span>任务2：氛围光影构成（Advance难度）</span>
                      </h4>
                      <p className="text-muted-foreground ml-8">
                        创作一幅具有特定氛围的光影构成，如日出、黄昏、夜晚或戏剧性光线。
                      </p>
                      <div className="ml-8 p-4 bg-muted/50 rounded-lg">
                        <p className="font-medium mb-2 text-sm">💡 创作要求：</p>
                        <ul className="space-y-1">
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>画布尺寸：横向矩形</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>选择一个氛围主题（温暖/冷峻/神秘/梦幻）</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>使用渐变和光晕效果</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>运用色温对比：暖光与冷光</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>创造光线穿透、散射或聚焦的效果</span>
                          </li>
                        </ul>
                      </div>
                    </div>

                    {/* Task 3 */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-lg flex items-center space-x-2">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground text-sm">3</span>
                        <span>任务3：多光源戏剧性构成（Stretch难度）</span>
                      </h4>
                      <p className="text-muted-foreground ml-8">
                        创作一幅具有多个光源、强烈戏剧性的复杂光影构成。
                      </p>
                      <div className="ml-8 p-4 bg-muted/50 rounded-lg">
                        <p className="font-medium mb-2 text-sm">💡 创作要求：</p>
                        <ul className="space-y-1">
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>画布尺寸：自由选择</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>至少2-3个不同的光源</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>光源有主次之分：主光、辅光、轮廓光</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>创造强烈的明暗对比和戏剧张力</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>运用光影引导视线，突出视觉焦点</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>表达特定情绪或叙事性</span>
                          </li>
                        </ul>
                      </div>
                    </div>

                    {/* Workflow */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-lg flex items-center space-x-2">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground text-sm">4</span>
                        <span>工作流程</span>
                      </h4>
                      <div className="ml-8 space-y-2">
                        <div className="p-3 bg-primary/5 rounded-lg">
                          <p className="font-medium text-sm mb-1">步骤1：确定光源</p>
                          <p className="text-sm text-muted-foreground">决定光源的位置、类型（点光源/面光源）和色温（暖/冷）</p>
                        </div>
                        <div className="p-3 bg-primary/5 rounded-lg">
                          <p className="font-medium text-sm mb-1">步骤2：建立明暗</p>
                          <p className="text-sm text-muted-foreground">根据光源位置，确定物体的亮面和暗面</p>
                        </div>
                        <div className="p-3 bg-primary/5 rounded-lg">
                          <p className="font-medium text-sm mb-1">步骤3：细化层次</p>
                          <p className="text-sm text-muted-foreground">添加高光、反光、投影等细节，丰富明暗层次</p>
                        </div>
                        <div className="p-3 bg-primary/5 rounded-lg">
                          <p className="font-medium text-sm mb-1">步骤4：调整氛围</p>
                          <p className="text-sm text-muted-foreground">通过整体色调、对比度、光晕效果营造氛围</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Light Observation */}
                <Card className="border-2 border-primary/20">
                  <CardHeader>
                    <div className="flex items-center space-x-2">
                      <Eye className="h-5 w-5 text-primary" />
                      <CardTitle>光影观察训练</CardTitle>
                    </div>
                    <CardDescription>
                      如何培养对光线的敏感度？
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="p-4 bg-muted/30 rounded-lg">
                      <h4 className="font-semibold mb-2">练习1：观察日常光线</h4>
                      <p className="text-sm text-muted-foreground">
                        注意观察不同时间的光线变化：清晨的柔和、正午的强烈、黄昏的温暖、夜晚的神秘。
                      </p>
                    </div>
                    <div className="p-4 bg-muted/30 rounded-lg">
                      <h4 className="font-semibold mb-2">练习2：分析光源方向</h4>
                      <p className="text-sm text-muted-foreground">
                        看到一个物体时，判断光从哪里来：顶光、侧光、逆光？光源是单一还是多个？
                      </p>
                    </div>
                    <div className="p-4 bg-muted/30 rounded-lg">
                      <h4 className="font-semibold mb-2">练习3：感受光的色温</h4>
                      <p className="text-sm text-muted-foreground">
                        白炽灯是暖黄色，日光灯是冷白色，夕阳是橙红色。不同光源有不同的情感。
                      </p>
                    </div>
                    <div className="p-4 bg-muted/30 rounded-lg">
                      <h4 className="font-semibold mb-2">练习4：研究经典作品</h4>
                      <p className="text-sm text-muted-foreground">
                        观察伦勃朗、卡拉瓦乔等大师的光影处理，学习他们如何用光讲故事。
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Tutorials Tab */}
              <TabsContent value="tutorials" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Canva光影效果技巧</CardTitle>
                    <CardDescription>如何在Canva中创造光影效果</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ol className="space-y-3">
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">1</span>
                        <div>
                          <p className="font-medium">使用渐变工具</p>
                          <p className="text-sm text-muted-foreground">创建从亮到暗的渐变，模拟光线的过渡。线性渐变适合平面光，径向渐变适合点光源。</p>
                        </div>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">2</span>
                        <div>
                          <p className="font-medium">添加阴影效果</p>
                          <p className="text-sm text-muted-foreground">使用"效果"中的"阴影"功能，调整偏移、模糊和透明度，创造投影</p>
                        </div>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">3</span>
                        <div>
                          <p className="font-medium">应用光晕效果</p>
                          <p className="text-sm text-muted-foreground">使用模糊的白色或黄色圆形，叠加在光源位置，创造光晕和光芒</p>
                        </div>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">4</span>
                        <div>
                          <p className="font-medium">调整混合模式</p>
                          <p className="text-sm text-muted-foreground">使用"叠加"、"滤色"等混合模式，让光效更自然地融入画面</p>
                        </div>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">5</span>
                        <div>
                          <p className="font-medium">运用透明度</p>
                          <p className="text-sm text-muted-foreground">通过调整元素透明度，创造光线穿透、半透明的效果</p>
                        </div>
                      </li>
                    </ol>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>明暗对比增强技巧</CardTitle>
                    <CardDescription>让你的光影更有冲击力</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2">技巧1：加大明暗跨度</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          不要害怕使用纯黑和纯白。强烈的明暗对比能创造戏剧性效果。
                        </p>
                        <p className="text-xs text-muted-foreground">
                          例如：高光用100%白色，暗部用80%黑色
                        </p>
                      </div>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2">技巧2：控制中间调</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          明暗交界线是最重要的区域，这里的过渡要柔和但清晰。
                        </p>
                        <p className="text-xs text-muted-foreground">
                          使用渐变工具创造平滑过渡
                        </p>
                      </div>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2">技巧3：添加环境光</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          暗部不是纯黑，会有环境反射的光。添加微弱的反光让画面更真实。
                        </p>
                        <p className="text-xs text-muted-foreground">
                          在暗部边缘添加低透明度的浅色
                        </p>
                      </div>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2">技巧4：用光引导视线</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          最亮的地方会吸引视线。把高光放在你想让观众注意的位置。
                        </p>
                        <p className="text-xs text-muted-foreground">
                          主体物最亮，背景相对暗淡
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Theory Tab */}
              <TabsContent value="theory" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-2xl">明暗五调子</CardTitle>
                    <CardDescription>素描光影的基础理论</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <p className="text-muted-foreground">
                      当光线照射在物体上时，会产生五个明暗层次，称为"明暗五调子"。理解这五个层次是表现立体感的关键。
                    </p>

                    <div className="space-y-4">
                      <div className="p-4 border-l-4 border-primary">
                        <h4 className="font-semibold mb-1">1. 高光（Highlight）</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          光线直接照射且反射最强的部分，通常是物体最凸出、最接近光源的点。
                        </p>
                        <p className="text-xs text-muted-foreground">
                          特点：最亮、面积最小、位置明确
                        </p>
                      </div>

                      <div className="p-4 border-l-4 border-primary">
                        <h4 className="font-semibold mb-1">2. 亮面（Light Side）</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          受光面，光线直接照射的区域，但不如高光明亮。
                        </p>
                        <p className="text-xs text-muted-foreground">
                          特点：明亮、面积较大、色彩饱和度高
                        </p>
                      </div>

                      <div className="p-4 border-l-4 border-primary">
                        <h4 className="font-semibold mb-1">3. 明暗交界线（Terminator）</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          亮面与暗面的分界线，是整个画面中最重要的区域，决定了物体的体积感。
                        </p>
                        <p className="text-xs text-muted-foreground">
                          特点：最暗、对比最强、形态明确
                        </p>
                      </div>

                      <div className="p-4 border-l-4 border-primary">
                        <h4 className="font-semibold mb-1">4. 暗面（Shadow Side）</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          背光面，光线照射不到的区域，但不是纯黑，会受到环境光的影响。
                        </p>
                        <p className="text-xs text-muted-foreground">
                          特点：较暗、面积较大、有微弱的环境色
                        </p>
                      </div>

                      <div className="p-4 border-l-4 border-primary">
                        <h4 className="font-semibold mb-1">5. 反光（Reflected Light）</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          暗面中较亮的部分，由周围物体或地面反射的光线造成。
                        </p>
                        <p className="text-xs text-muted-foreground">
                          特点：比暗面亮但比亮面暗、柔和、带有环境色彩
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-2xl">光源类型与特点</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <h4 className="font-semibold flex items-center space-x-2">
                          <Sun className="h-4 w-4 text-primary" />
                          <span>点光源（Point Light）</span>
                        </h4>
                        <p className="text-sm text-muted-foreground">
                          从一个点向四周发散的光，如灯泡、蜡烛。特点是有明确的光源位置，阴影边缘清晰，明暗对比强烈。
                        </p>
                        <div className="flex flex-wrap gap-2 mt-2">
                          <Badge variant="secondary">强对比</Badge>
                          <Badge variant="secondary">硬阴影</Badge>
                          <Badge variant="secondary">戏剧性</Badge>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <h4 className="font-semibold flex items-center space-x-2">
                          <Sun className="h-4 w-4 text-primary" />
                          <span>面光源（Area Light）</span>
                        </h4>
                        <p className="text-sm text-muted-foreground">
                          从一个面发出的光，如窗户、柔光箱。特点是光线柔和，阴影边缘模糊，明暗过渡平缓。
                        </p>
                        <div className="flex flex-wrap gap-2 mt-2">
                          <Badge variant="secondary">柔和</Badge>
                          <Badge variant="secondary">软阴影</Badge>
                          <Badge variant="secondary">自然</Badge>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <h4 className="font-semibold flex items-center space-x-2">
                          <Sun className="h-4 w-4 text-primary" />
                          <span>平行光（Directional Light）</span>
                        </h4>
                        <p className="text-sm text-muted-foreground">
                          光线平行照射，如阳光。特点是所有物体的阴影方向一致，适合表现室外场景。
                        </p>
                        <div className="flex flex-wrap gap-2 mt-2">
                          <Badge variant="secondary">统一方向</Badge>
                          <Badge variant="secondary">室外感</Badge>
                          <Badge variant="secondary">清晰</Badge>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <h4 className="font-semibold flex items-center space-x-2">
                          <Moon className="h-4 w-4 text-primary" />
                          <span>环境光（Ambient Light）</span>
                        </h4>
                        <p className="text-sm text-muted-foreground">
                          无明确方向的漫反射光，如阴天。特点是没有明显阴影，明暗对比弱，氛围平和。
                        </p>
                        <div className="flex flex-wrap gap-2 mt-2">
                          <Badge variant="secondary">无阴影</Badge>
                          <Badge variant="secondary">平淡</Badge>
                          <Badge variant="secondary">柔和</Badge>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-2xl">光影的情感表达</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-4">
                      不同的光影处理能传达不同的情感和氛围。光不仅是技术，更是情感的语言。
                    </p>
                    <div className="space-y-3">
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2">高调光影（High Key）</h4>
                        <p className="text-sm text-muted-foreground">
                          整体明亮，暗部很少，给人轻松、愉快、纯净的感觉。适合表现快乐、希望、清新的主题。
                        </p>
                      </div>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2">低调光影（Low Key）</h4>
                        <p className="text-sm text-muted-foreground">
                          整体暗沉，亮部很少，给人神秘、压抑、严肃的感觉。适合表现悬疑、恐怖、深沉的主题。
                        </p>
                      </div>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2">侧光（Side Light）</h4>
                        <p className="text-sm text-muted-foreground">
                          光从侧面照射，一半亮一半暗，创造强烈的立体感和戏剧性。适合表现冲突、对立、张力。
                        </p>
                      </div>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2">逆光（Back Light）</h4>
                        <p className="text-sm text-muted-foreground">
                          光从背后照射，形成剪影或轮廓光，给人梦幻、浪漫、神圣的感觉。适合表现希望、温暖、怀旧。
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Examples Tab */}
              <TabsContent value="examples" className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>伦勃朗光</CardTitle>
                      <CardDescription>经典的侧光肖像</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="aspect-square bg-muted rounded-lg flex items-center justify-center mb-4">
                        <Image className="h-12 w-12 text-muted-foreground" />
                      </div>
                      <div className="p-3 bg-primary/5 rounded-lg">
                        <p className="text-sm">
                          <span className="font-medium">分析：</span>
                          45度侧上方光源，脸部一侧明亮，另一侧在阴影中形成三角形光斑，创造强烈的立体感和戏剧性。
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>卡拉瓦乔的明暗对照</CardTitle>
                      <CardDescription>极致的明暗对比</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="aspect-square bg-muted rounded-lg flex items-center justify-center mb-4">
                        <Image className="h-12 w-12 text-muted-foreground" />
                      </div>
                      <div className="p-3 bg-primary/5 rounded-lg">
                        <p className="text-sm">
                          <span className="font-medium">分析：</span>
                          强烈的点光源，深黑的背景衬托明亮的人物，创造戏剧性的舞台效果，突出情感张力。
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>印象派的光影</CardTitle>
                      <CardDescription>莫奈的光线变化</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="aspect-square bg-muted rounded-lg flex items-center justify-center mb-4">
                        <Image className="h-12 w-12 text-muted-foreground" />
                      </div>
                      <div className="p-3 bg-primary/5 rounded-lg">
                        <p className="text-sm">
                          <span className="font-medium">分析：</span>
                          捕捉不同时间的光线变化，用色彩表现光的温度和氛围，创造梦幻、流动的视觉体验。
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>电影光影</CardTitle>
                      <CardDescription>布莱德·皮特《搏击俱乐部》</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="aspect-square bg-muted rounded-lg flex items-center justify-center mb-4">
                        <Image className="h-12 w-12 text-muted-foreground" />
                      </div>
                      <div className="p-3 bg-primary/5 rounded-lg">
                        <p className="text-sm">
                          <span className="font-medium">分析：</span>
                          低调光影，冷色调，强烈的侧光和轮廓光，营造压抑、不安、分裂的心理氛围。
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              {/* Works Tab */}
              <TabsContent value="works">
                <Card>
                  <CardHeader>
                    <CardTitle>优秀学生作业</CardTitle>
                    <CardDescription>查看往届学生的光影构成作品</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-12 text-muted-foreground">
                      <Award className="h-16 w-16 mx-auto mb-4 opacity-50" />
                      <p>优秀作业正在收集整理中...</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Resources Tab */}
              <TabsContent value="resources" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>拓展资源</CardTitle>
                    <CardDescription>光影表现相关的参考资料和工具</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <a
                        href="https://www.canva.cn/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center space-x-3">
                          <Lightbulb className="h-5 w-5 text-primary" />
                          <span>Canva - 在线设计工具</span>
                        </div>
                        <ExternalLink className="h-4 w-4 text-muted-foreground" />
                      </a>
                      <a
                        href="https://www.zcool.com.cn/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center space-x-3">
                          <BookOpen className="h-5 w-5 text-primary" />
                          <span>站酷 - 光影设计作品参考</span>
                        </div>
                        <ExternalLink className="h-4 w-4 text-muted-foreground" />
                      </a>
                      <a
                        href="https://www.bilibili.com/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center space-x-3">
                          <BookOpen className="h-5 w-5 text-primary" />
                          <span>哔哩哔哩 - 素描光影教程</span>
                        </div>
                        <ExternalLink className="h-4 w-4 text-muted-foreground" />
                      </a>
                    </div>
                  </CardContent>
                </Card>

                {/* Common Pitfalls */}
                <Card className="border-destructive/50">
                  <CardHeader>
                    <div className="flex items-center space-x-2">
                      <AlertCircle className="h-5 w-5 text-destructive" />
                      <CardTitle>常见问题</CardTitle>
                    </div>
                    <CardDescription>光影表现中的常见错误</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex items-start space-x-2">
                          <span className="text-destructive font-bold">❌</span>
                          <p className="text-sm">光源不统一：不同物体的光源方向不一致</p>
                        </div>
                        <div className="flex items-start space-x-2 ml-6">
                          <span className="text-green-600 font-bold">✅</span>
                          <p className="text-sm font-medium text-green-600">确定统一的光源位置和方向！</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-start space-x-2">
                          <span className="text-destructive font-bold">❌</span>
                          <p className="text-sm">明暗过渡生硬：亮面和暗面之间没有过渡</p>
                        </div>
                        <div className="flex items-start space-x-2 ml-6">
                          <span className="text-green-600 font-bold">✅</span>
                          <p className="text-sm font-medium text-green-600">使用渐变创造柔和过渡！</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-start space-x-2">
                          <span className="text-destructive font-bold">❌</span>
                          <p className="text-sm">暗部纯黑：暗部没有任何细节和反光</p>
                        </div>
                        <div className="flex items-start space-x-2 ml-6">
                          <span className="text-green-600 font-bold">✅</span>
                          <p className="text-sm font-medium text-green-600">添加微弱的环境光和反光！</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-start space-x-2">
                          <span className="text-destructive font-bold">❌</span>
                          <p className="text-sm">高光位置错误：高光不在最凸出的位置</p>
                        </div>
                        <div className="flex items-start space-x-2 ml-6">
                          <span className="text-green-600 font-bold">✅</span>
                          <p className="text-sm font-medium text-green-600">高光应在最接近光源的凸起处！</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Next Steps */}
                <Card className="bg-primary/5 border-primary/20">
                  <CardHeader>
                    <CardTitle>下一步</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <p className="text-sm">太棒了！你已经掌握了光影表现的基本原理和技法。</p>
                      <p className="text-sm">光是设计的灵魂——它不仅塑造形态，更传递情感、营造氛围、讲述故事。</p>
                      <p className="text-sm">思考：在你的日常生活中，哪些时刻的光线最打动你？为什么？</p>
                      <p className="text-sm">准备：接下来我们将学习色彩的情感表达，结合光影，让你的设计更加丰富多彩！</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>

            {/* Navigation */}
            <div className="flex justify-between mt-12 pt-8 border-t">
              <Link href="/curriculum/4">
                <Button variant="outline">
                  <ChevronLeft className="h-4 w-4 mr-2" />
                  上一节：塑·空间幻觉
                </Button>
              </Link>
              <Link href="/curriculum">
                <Button>
                  返回课程大纲
                  <ChevronRight className="h-4 w-4 ml-2" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t py-8 bg-muted/30">
        <div className="container">
          <div className="text-center text-sm text-muted-foreground">
            <p>© 2025 数字设计构成课程</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

