import Navigation from "@/components/Navigation";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface Lesson {
  id: number;
  title: string;
  loop: 1 | 2 | 3;
  duration: string;
  objectives: string[];
  activities: string[];
  deliverables: string[];
}

const lessons: Lesson[] = [
  {
    id: 1,
    title: "启动 / AI竞技场 / 概念草图",
    loop: 1,
    duration: "3小时",
    objectives: [
      "理解课程目标和三轮螺旋教学法",
      "体验AI文生图工具的基本使用",
      "完成初步概念草图"
    ],
    activities: [
      "课程介绍与项目任务书解读",
      "AI竞技场：快速生成概念图",
      "手绘概念草图练习"
    ],
    deliverables: [
      "AI生成的概念图（3-5张）",
      "手绘概念草图"
    ]
  },
  {
    id: 2,
    title: "情绪体块 / 概念汇报",
    loop: 1,
    duration: "3小时",
    objectives: [
      "理解体块模型在概念表达中的作用",
      "学会快速制作情绪体块模型",
      "完成Loop 1概念汇报"
    ],
    activities: [
      "情绪体块模型制作",
      "概念方案整理",
      "小组汇报与反馈"
    ],
    deliverables: [
      "情绪体块模型照片",
      "概念汇报PPT",
      "设计逻辑日志#1"
    ]
  },
  {
    id: 3,
    title: "平面迭代",
    loop: 2,
    duration: "3小时",
    objectives: [
      "深入理解平面构成原理",
      "完成单元平面设计的多轮迭代",
      "掌握2D设计工具的使用"
    ],
    activities: [
      "平面构成理论学习",
      "单元平面设计迭代",
      "Canva/Pixlr工具实践"
    ],
    deliverables: [
      "平面构成迭代方案（3-5版）",
      "最终平面设计稿"
    ]
  },
  {
    id: 4,
    title: "精细手工草模",
    loop: 2,
    duration: "3小时",
    objectives: [
      "掌握精细手工模型制作技巧",
      "理解三维构成原理",
      "完成高质量物理模型"
    ],
    activities: [
      "手工模型制作技巧讲解",
      "精细草模制作",
      "模型细节优化"
    ],
    deliverables: [
      "精细手工草模",
      "制作过程记录"
    ]
  },
  {
    id: 5,
    title: "色板/材质定稿 / 模型拍摄",
    loop: 2,
    duration: "3小时",
    objectives: [
      "理解色彩构成原理",
      "完成色板和材质方案",
      "掌握模型摄影技巧"
    ],
    activities: [
      "色彩构成理论学习",
      "Adobe Color工具使用",
      "模型摄影实践"
    ],
    deliverables: [
      "色板方案",
      "高质量模型照片（多角度）"
    ]
  },
  {
    id: 6,
    title: "物理AI转译 V1.x",
    loop: 2,
    duration: "3小时",
    objectives: [
      "掌握AI图生图工作流",
      "完成模型照片的AI转译",
      "理解AI在设计迭代中的作用"
    ],
    activities: [
      "AI图生图工具使用",
      "提示词优化实践",
      "效果图迭代"
    ],
    deliverables: [
      "AI转译效果图 V1.x（3-5张）",
      "提示词记录"
    ]
  },
  {
    id: 7,
    title: "形态汇报",
    loop: 2,
    duration: "3小时",
    objectives: [
      "整理Loop 2成果",
      "完成形态方案汇报",
      "获取反馈并规划Loop 3"
    ],
    activities: [
      "方案整理与排版",
      "汇报演练",
      "小组汇报与评审"
    ],
    deliverables: [
      "形态汇报PPT",
      "设计逻辑日志#2"
    ]
  },
  {
    id: 8,
    title: "数字建模 / AI精修",
    loop: 3,
    duration: "3小时",
    objectives: [
      "掌握SketchUp基础建模",
      "完成数字素模",
      "进行AI精修优化"
    ],
    activities: [
      "SketchUp建模教学",
      "数字素模制作",
      "AI精修实践"
    ],
    deliverables: [
      "数字素模文件",
      "AI精修效果图"
    ]
  },
  {
    id: 9,
    title: "数字AI迭代 (方案 V2/V3...)",
    loop: 3,
    duration: "3小时",
    objectives: [
      "完成多轮AI方案迭代",
      "探索不同风格和可能性",
      "确定最终方案"
    ],
    activities: [
      "AI方案迭代",
      "方案对比与选择",
      "细节优化"
    ],
    deliverables: [
      "迭代方案系列（V2, V3...）",
      "最终方案效果图"
    ]
  },
  {
    id: 10,
    title: "5页方案书排版",
    loop: 3,
    duration: "3小时",
    objectives: [
      "掌握方案书排版技巧",
      "完成专业方案书",
      "整合所有设计成果"
    ],
    activities: [
      "方案书排版教学",
      "内容整理与编排",
      "视觉优化"
    ],
    deliverables: [
      "5页方案书（PDF）"
    ]
  },
  {
    id: 11,
    title: "汇报预演 & 修改",
    loop: 3,
    duration: "3小时",
    objectives: [
      "练习汇报技巧",
      "根据反馈优化方案",
      "准备最终汇报"
    ],
    activities: [
      "汇报演练",
      "同伴互评",
      "方案修改与完善"
    ],
    deliverables: [
      "修改后的方案书",
      "汇报演示文稿"
    ]
  },
  {
    id: 12,
    title: "最终汇报 / 课程总结",
    loop: 3,
    duration: "3小时",
    objectives: [
      "完成最终汇报",
      "展示完整设计过程",
      "反思学习收获"
    ],
    activities: [
      "最终汇报展示",
      "评审与点评",
      "课程总结与反思"
    ],
    deliverables: [
      "最终汇报",
      "设计逻辑日志#3",
      "完整作品集"
    ]
  }
];

const loopColors = {
  1: { bg: "bg-blue-50", border: "border-blue-200", text: "text-blue-700", badge: "bg-blue-100" },
  2: { bg: "bg-orange-50", border: "border-orange-200", text: "text-orange-700", badge: "bg-orange-100" },
  3: { bg: "bg-purple-50", border: "border-purple-200", text: "text-purple-700", badge: "bg-purple-100" }
};

const loopTitles = {
  1: "Loop 1: 概念冲刺",
  2: "Loop 2: 形态冲刺",
  3: "Loop 3: 精炼冲刺"
};

export default function Curriculum() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1 py-12">
        <div className="container">
          <div className="max-w-5xl mx-auto">
            <div className="text-center mb-12">
              <h1 className="text-4xl font-bold mb-4">课程大纲</h1>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                12节课程，36小时学习旅程，三轮螺旋迭代，从概念到精炼
              </p>
            </div>

            <div className="space-y-8">
              {[1, 2, 3].map((loop) => (
                <div key={loop} className="space-y-4">
                  <div className={`${loopColors[loop as 1 | 2 | 3].bg} ${loopColors[loop as 1 | 2 | 3].border} border-l-4 p-4 rounded-r-lg`}>
                    <h2 className={`text-2xl font-bold ${loopColors[loop as 1 | 2 | 3].text}`}>
                      {loopTitles[loop as 1 | 2 | 3]}
                    </h2>
                  </div>

                  <div className="grid gap-6">
                    {lessons.filter(lesson => lesson.loop === loop).map((lesson) => (
                      <Link key={lesson.id} href={`/curriculum/${lesson.id}`}>
                        <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                        <CardHeader>
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <Badge className={loopColors[loop as 1 | 2 | 3].badge}>
                                  第{lesson.id}节
                                </Badge>
                                <Badge variant="outline">{lesson.duration}</Badge>
                              </div>
                              <CardTitle className="text-xl">{lesson.title}</CardTitle>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div>
                            <h4 className="font-semibold mb-2 text-sm text-muted-foreground">学习目标</h4>
                            <ul className="space-y-1">
                              {lesson.objectives.map((obj, idx) => (
                                <li key={idx} className="flex items-start space-x-2 text-sm">
                                  <span className="text-primary mt-1">•</span>
                                  <span>{obj}</span>
                                </li>
                              ))}
                            </ul>
                          </div>

                          <div>
                            <h4 className="font-semibold mb-2 text-sm text-muted-foreground">核心活动</h4>
                            <ul className="space-y-1">
                              {lesson.activities.map((activity, idx) => (
                                <li key={idx} className="flex items-start space-x-2 text-sm">
                                  <span className="text-accent-foreground mt-1">→</span>
                                  <span>{activity}</span>
                                </li>
                              ))}
                            </ul>
                          </div>

                          <div>
                            <h4 className="font-semibold mb-2 text-sm text-muted-foreground">交付成果</h4>
                            <div className="flex flex-wrap gap-2">
                              {lesson.deliverables.map((deliverable, idx) => (
                                <Badge key={idx} variant="secondary" className="text-xs">
                                  {deliverable}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                      </Link>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t py-8 bg-muted/30">
        <div className="container">
          <div className="text-center text-sm text-muted-foreground">
            <p>© 2025 数字设计构成课程</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

