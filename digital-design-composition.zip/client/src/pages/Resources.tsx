import Navigation from "@/components/Navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Palette, Wrench, BookOpen, Video, Sparkles } from "lucide-react";

interface Resource {
  title: string;
  description: string;
  url: string;
  type: "tool" | "tutorial" | "article" | "video";
  tags?: string[];
}

const resources: { [key: string]: Resource[] } = {
  tools: [
    {
      title: "Canva可画",
      description: "在线设计工具，提供丰富的模板和设计资源，适合2D构成练习和方案排版",
      url: "https://www.canva.cn/",
      type: "tool",
      tags: ["2D设计", "排版", "初学者友好"]
    },
    {
      title: "Adobe Color",
      description: "专业配色工具，可以从图片提取色彩、创建配色方案、探索色彩关系",
      url: "https://color.adobe.com/",
      type: "tool",
      tags: ["配色", "色彩提取", "专业工具"]
    },
    {
      title: "即时设计",
      description: "专业UI/UX设计工具，浏览器打开即用，提供丰富的设计资源库",
      url: "https://js.design/",
      type: "tool",
      tags: ["UI设计", "协作", "资源库"]
    },
    {
      title: "SketchUp Free",
      description: "免费在线3D建模工具，适合快速创建数字素模",
      url: "https://www.sketchup.com/",
      type: "tool",
      tags: ["3D建模", "初学者友好"]
    },
    {
      title: "Pixlr",
      description: "在线图像编辑器，提供基础的图像处理功能",
      url: "https://pixlr.com/",
      type: "tool",
      tags: ["图像编辑", "在线工具"]
    }
  ],
  ai: [
    {
      title: "Midjourney提示词入门",
      description: "Midjourney官方提示词基础教程，了解如何编写有效的提示词",
      url: "https://docs.midjourney.com/hc/en-us/articles/32023408776205-Prompt-Basics",
      type: "article",
      tags: ["Midjourney", "提示词", "官方文档"]
    },
    {
      title: "拆解Midjourney提示词结构",
      description: "详细分析Midjourney提示词的组成部分：主体、风格、光线、参数等",
      url: "https://zhuanlan.zhihu.com/p/619209556",
      type: "article",
      tags: ["Midjourney", "提示词结构", "中文教程"]
    },
    {
      title: "通用文生图提示词指南",
      description: "7步教你用AI创作高质量图像，适用于各类AI工具",
      url: "https://blog.csdn.net/m0_71746299/article/details/145288853",
      type: "article",
      tags: ["文生图", "通用教程"]
    },
    {
      title: "AI绘画提示词原理揭秘",
      description: "保姆级教程，深入理解AI提示词的工作原理",
      url: "https://zhuanlan.zhihu.com/p/664892300",
      type: "article",
      tags: ["AI原理", "提示词"]
    },
    {
      title: "The ultimate guide to AI prompts",
      description: "AI提示词写作完整指南（英文），包含Persona、Task、Context、Format四要素",
      url: "https://www.atlassian.com/blog/artificial-intelligence/ultimate-guide-writing-ai-prompts",
      type: "article",
      tags: ["英文教程", "进阶"]
    }
  ],
  theory: [
    {
      title: "设计基础：点·线·面",
      description: "平面构成的形态要素详解，包含点、线、面的不同形态结合方法",
      url: "https://deerlight.design/basics-of-design-point-and-line-to-plane/",
      type: "article",
      tags: ["平面构成", "基础理论"]
    },
    {
      title: "点、线、面讲解，通俗易懂",
      description: "用简单易懂的方式讲解平面构成的基本元素",
      url: "https://www.shejidaren.com/xiangjie-dian-xian-mian.html",
      type: "article",
      tags: ["平面构成", "初学者友好"]
    },
    {
      title: "设计色彩理论全解",
      description: "详细讲解色彩管理、选色逻辑和配色板创建的原理",
      url: "https://js.design/special/article/design-colour-theory.html",
      type: "article",
      tags: ["色彩理论", "配色"]
    },
    {
      title: "色彩心理学的原理及应用",
      description: "探讨色彩对人的心理和情绪影响",
      url: "https://zhuanlan.zhihu.com/p/579652250",
      type: "article",
      tags: ["色彩心理学", "情绪设计"]
    },
    {
      title: "设计配色完整攻略",
      description: "色彩意义、色彩理论、色彩心理学的完整指南",
      url: "https://www.shutterstock.com/zh-Hant/blog/complete-guide-color-in-design",
      type: "article",
      tags: ["配色", "综合指南"]
    },
    {
      title: "Design Fundamentals: Elements & Principles",
      description: "伯克利大学图书馆的设计基础指南（英文）",
      url: "https://guides.lib.berkeley.edu/design",
      type: "article",
      tags: ["设计原理", "英文资源"]
    }
  ],
  platforms: [
    {
      title: "站酷（ZCOOL）",
      description: "中国最具人气的设计师互动平台，汇集大量优秀设计作品",
      url: "https://www.zcool.com.cn/",
      type: "tool",
      tags: ["设计社区", "作品展示"]
    },
    {
      title: "优设导航",
      description: "专业设计师导航网站，汇集各类设计资源和工具",
      url: "https://hao.uisdc.com/",
      type: "tool",
      tags: ["导航", "资源聚合"]
    },
    {
      title: "哔哩哔哩（B站）",
      description: "大量设计教程视频，搜索\"平面构成\"、\"色彩构成\"可找到相关课程",
      url: "https://www.bilibili.com/",
      type: "video",
      tags: ["视频教程", "中文"]
    },
    {
      title: "虎课网",
      description: "设计软件教学视频平台，提供PS、AI、C4D等软件教程",
      url: "https://huke88.com/",
      type: "video",
      tags: ["软件教程", "付费课程"]
    }
  ]
};

const categoryConfig = {
  tools: { label: "在线工具", icon: Wrench, description: "设计和创作工具" },
  ai: { label: "AI工具指南", icon: Sparkles, description: "AI提示词和应用教程" },
  theory: { label: "理论资料", icon: BookOpen, description: "构成原理和设计理论" },
  platforms: { label: "学习平台", icon: Video, description: "设计社区和教程平台" }
};

export default function Resources() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1 py-12">
        <div className="container">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h1 className="text-4xl font-bold mb-4">学习资源</h1>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                精选的在线工具、教程、理论资料和学习平台
              </p>
            </div>

            <Tabs defaultValue="tools" className="space-y-8">
              <TabsList className="grid w-full grid-cols-4 max-w-3xl mx-auto">
                {Object.entries(categoryConfig).map(([key, { label }]) => (
                  <TabsTrigger key={key} value={key}>{label}</TabsTrigger>
                ))}
              </TabsList>

              {Object.entries(categoryConfig).map(([key, config]) => {
                const { label, icon: Icon, description } = config;
                return (
                <TabsContent key={key} value={key} className="space-y-6">
                  <div className="text-center mb-8">
                    <div className="flex justify-center mb-3">
                      <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                        <Icon className="h-6 w-6 text-primary" />
                      </div>
                    </div>
                    <h2 className="text-2xl font-bold mb-2">{label}</h2>
                    <p className="text-muted-foreground">{description}</p>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    {resources[key].map((resource, idx) => (
                      <Card key={idx} className="hover:shadow-lg transition-shadow">
                        <CardHeader>
                          <div className="flex items-start justify-between">
                            <CardTitle className="text-lg flex-1">{resource.title}</CardTitle>
                            <a
                              href={resource.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-primary hover:text-primary/80 transition-colors"
                            >
                              <ExternalLink className="h-5 w-5" />
                            </a>
                          </div>
                          <CardDescription>{resource.description}</CardDescription>
                        </CardHeader>
                        {resource.tags && (
                          <CardContent>
                            <div className="flex flex-wrap gap-2">
                              {resource.tags.map((tag, tagIdx) => (
                                <Badge key={tagIdx} variant="secondary" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          </CardContent>
                        )}
                      </Card>
                    ))}
                  </div>
                </TabsContent>
                );
              })}
            </Tabs>

            <div className="mt-16 p-8 bg-muted/30 rounded-lg text-center">
              <h3 className="text-xl font-bold mb-2">提示</h3>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                所有外部链接均为国内可访问的合法网站。建议在课前预习时浏览相关资源，
                课中遇到问题时随时查阅。AI工具变化很快，资源会持续更新。
              </p>
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t py-8 bg-muted/30">
        <div className="container">
          <div className="text-center text-sm text-muted-foreground">
            <p>© 2025 数字设计构成课程</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

