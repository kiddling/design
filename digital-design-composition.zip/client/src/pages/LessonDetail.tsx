import Navigation from "@/components/Navigation";
import PromptGenerator from "@/components/PromptGenerator";
import WorkflowDiagram from "@/components/WorkflowDiagram";
import AnnotationGuide from "@/components/AnnotationGuide";
import PhotoTipsVisual from "@/components/PhotoTipsVisual";
import KnowledgeGraph from "@/components/KnowledgeGraph";
import LearningPath from "@/components/LearningPath";
import QuickNav from "@/components/QuickNav";
import RelatedContent from "@/components/RelatedContent";
import ElementQuiz from "@/components/ElementQuiz";
import ShareButton from "@/components/ShareButton";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Target, 
  BookOpen, 
  Lightbulb, 
  Image, 
  Award, 
  ExternalLink, 
  ChevronLeft, 
  ChevronRight,
  Camera,
  Pencil,
  Eye,
  AlertCircle,
  Sparkles,
  Brain,
  Network
} from "lucide-react";
import { Link } from "wouter";

export default function LessonDetail() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1 py-8">
        <div className="container">
          <div className="max-w-6xl mx-auto">
            {/* Header */}
            <div className="mb-8">
              <Link href="/curriculum">
                <Button variant="ghost" className="mb-4">
                  <ChevronLeft className="h-4 w-4 mr-2" />
                  返回课程大纲
                </Button>
              </Link>
              
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <Badge>第1节</Badge>
                    <Badge variant="outline">3小时</Badge>
                    <Badge variant="outline">课前10分钟 + 课中60-90分钟</Badge>
                  </div>
                  <h1 className="text-4xl font-bold mb-2">观·元素解构</h1>
                  <p className="text-xl text-muted-foreground">Visual Elements - Point, Line, Plane</p>
                </div>
                <ShareButton title="第1节：观·元素解构" description="学习点线面基础知识" />
              </div>
            </div>

            {/* Learning Objectives */}
            <Card className="mb-8 bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <Target className="h-5 w-5 text-primary" />
                  <CardTitle>学习目标</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="flex items-start space-x-3">
                    <span className="flex items-center justify-center h-8 w-8 rounded-full bg-primary/10 text-primary flex-shrink-0">1</span>
                    <div>
                      <p className="font-medium mb-1">观察力培养</p>
                      <p className="text-sm text-muted-foreground">激发观察兴趣，用设计师之眼发现身边的点、线、面元素</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <span className="flex items-center justify-center h-8 w-8 rounded-full bg-primary/10 text-primary flex-shrink-0">2</span>
                    <div>
                      <p className="font-medium mb-1">元素识别</p>
                      <p className="text-sm text-muted-foreground">理解点线面的本质特征及其在设计中的作用</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <span className="flex items-center justify-center h-8 w-8 rounded-full bg-primary/10 text-primary flex-shrink-0">3</span>
                    <div>
                      <p className="font-medium mb-1">工具应用</p>
                      <p className="text-sm text-muted-foreground">学习使用Canva进行视觉分析和元素标注</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <span className="flex items-center justify-center h-8 w-8 rounded-full bg-primary/10 text-primary flex-shrink-0">4</span>
                    <div>
                      <p className="font-medium mb-1">问题发现</p>
                      <p className="text-sm text-muted-foreground">培养批判性思维，发现空间中的设计问题</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Main Content Tabs */}
            <Tabs defaultValue="overview" className="space-y-6">
              <TabsList className="grid w-full grid-cols-9 text-xs md:text-sm">
                <TabsTrigger value="overview">
                  <Target className="h-4 w-4 mr-1 md:mr-2" />
                  <span className="hidden md:inline">学习导航</span>
                  <span className="md:hidden">导航</span>
                </TabsTrigger>
                <TabsTrigger value="knowledge">
                  <Network className="h-4 w-4 mr-1 md:mr-2" />
                  <span className="hidden md:inline">知识图谱</span>
                  <span className="md:hidden">图谱</span>
                </TabsTrigger>
                <TabsTrigger value="tasks">
                  <Pencil className="h-4 w-4 mr-2" />
                  任务卡片
                </TabsTrigger>
                <TabsTrigger value="tutorials">
                  <Camera className="h-4 w-4 mr-2" />
                  教程
                </TabsTrigger>
                <TabsTrigger value="theory">
                  <BookOpen className="h-4 w-4 mr-2" />
                  理论
                </TabsTrigger>
                <TabsTrigger value="examples">
                  <Image className="h-4 w-4 mr-2" />
                  案例
                </TabsTrigger>
                <TabsTrigger value="ai">
                  <Sparkles className="h-4 w-4 mr-2" />
                  AI应用
                </TabsTrigger>
                <TabsTrigger value="works">
                  <Award className="h-4 w-4 mr-2" />
                  优秀作业
                </TabsTrigger>
                <TabsTrigger value="resources">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  拓展
                </TabsTrigger>
              </TabsList>

              {/* Learning Overview Tab */}
              <TabsContent value="overview" className="space-y-6">
                <LearningPath />
              </TabsContent>

              {/* Knowledge Graph Tab */}
              <TabsContent value="knowledge" className="space-y-6">
                <KnowledgeGraph />
              </TabsContent>

              {/* Task Cards Tab */}
              <TabsContent value="tasks" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-2xl">寻宝游戏：发现你身边的点·线·面！</CardTitle>
                    <CardDescription className="text-base">
                      设计不在书本里，而在你的生活中！这节课，我们要像侦探一样，在校园、教室、街道中寻找隐藏的设计元素。
                      每一个窗户、每一盏灯、每一块地砖，都藏着点线面的秘密。
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Workflow Diagram */}
                    <WorkflowDiagram />

                    {/* Task Overview */}
                    <div className="p-4 bg-primary/5 border-l-4 border-primary rounded-lg">
                      <h4 className="font-semibold mb-2 flex items-center space-x-2">
                        <Target className="h-5 w-5 text-primary" />
                        <span>核心任务</span>
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        拍摄一张你身边的场景照片（教室、走廊、广场等），用圈画的方式标注出至少<strong className="text-primary">3个点、3条线、3个面</strong>，
                        并思考它们在空间中的作用和关系。
                      </p>
                    </div>

                    {/* Workflow Step 1 */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-lg flex items-center space-x-2">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground text-sm">1</span>
                        <span>步骤1：拍照 - 捕捉你的观察对象</span>
                      </h4>
                      <div className="ml-8 space-y-3">
                        <p className="text-muted-foreground">
                          选择一个你熟悉的空间，用手机或相机拍摄一张清晰的照片。
                        </p>
                        <div className="p-4 bg-muted/50 rounded-lg">
                          <p className="font-medium mb-2 text-sm">📸 拍摄技巧：</p>
                          <ul className="space-y-1">
                            <li className="text-sm flex items-start space-x-2">
                              <span className="text-primary mt-0.5">→</span>
                              <span><strong>光线充足</strong>：选择自然光充足的时间，避免阴影过重</span>
                            </li>
                            <li className="text-sm flex items-start space-x-2">
                              <span className="text-primary mt-0.5">→</span>
                              <span><strong>构图稳定</strong>：保持相机水平，避免倾斜</span>
                            </li>
                            <li className="text-sm flex items-start space-x-2">
                              <span className="text-primary mt-0.5">→</span>
                              <span><strong>元素丰富</strong>：选择包含多种元素的场景（家具、装饰、建筑细节等）</span>
                            </li>
                            <li className="text-sm flex items-start space-x-2">
                              <span className="text-primary mt-0.5">→</span>
                              <span><strong>焦点清晰</strong>：确保主要元素清晰可辨</span>
                            </li>
                          </ul>
                        </div>
                        <div className="p-3 bg-blue-50 border-l-4 border-blue-500 rounded-lg">
                          <p className="text-sm"><strong>💡 推荐场景：</strong>教室一角、图书馆书架、咖啡厅座位、建筑立面、公园长椅区域</p>
                        </div>
                      </div>
                    </div>

                    {/* Workflow Step 2 */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-lg flex items-center space-x-2">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground text-sm">2</span>
                        <span>步骤2：圈画 - 标注点线面元素</span>
                      </h4>
                      <div className="ml-8 space-y-3">
                        <p className="text-muted-foreground">
                          将照片导入Canva，使用形状和线条工具标注出你发现的点、线、面。
                        </p>
                        
                        {/* Annotation Guide Visual */}
                        <AnnotationGuide />

                        <div className="grid md:grid-cols-3 gap-4">
                          <div className="p-4 bg-red-50 border-2 border-red-200 rounded-lg">
                            <h5 className="font-semibold mb-2 text-red-700">🔴 寻找"点"</h5>
                            <p className="text-sm text-muted-foreground mb-2">
                              视觉焦点、小而集中的元素
                            </p>
                            <ul className="text-xs space-y-1 text-muted-foreground">
                              <li>• 灯泡、开关</li>
                              <li>• 门把手、螺丝钉</li>
                              <li>• 装饰品、标识</li>
                              <li>• 人的视线聚焦处</li>
                            </ul>
                            <div className="mt-2 pt-2 border-t border-red-200">
                              <p className="text-xs font-medium text-red-700">标注方式：用红色圆圈标注</p>
                            </div>
                          </div>

                          <div className="p-4 bg-blue-50 border-2 border-blue-200 rounded-lg">
                            <h5 className="font-semibold mb-2 text-blue-700">📏 寻找"线"</h5>
                            <p className="text-sm text-muted-foreground mb-2">
                              延伸的、连接的、引导的元素
                            </p>
                            <ul className="text-xs space-y-1 text-muted-foreground">
                              <li>• 墙角、门框边缘</li>
                              <li>• 栏杆、扶手</li>
                              <li>• 电线、管道</li>
                              <li>• 地砖缝隙、装饰线条</li>
                            </ul>
                            <div className="mt-2 pt-2 border-t border-blue-200">
                              <p className="text-xs font-medium text-blue-700">标注方式：用蓝色箭头或线条标注</p>
                            </div>
                          </div>

                          <div className="p-4 bg-green-50 border-2 border-green-200 rounded-lg">
                            <h5 className="font-semibold mb-2 text-green-700">▭ 寻找"面"</h5>
                            <p className="text-sm text-muted-foreground mb-2">
                              大面积的、包围的、背景的元素
                            </p>
                            <ul className="text-xs space-y-1 text-muted-foreground">
                              <li>• 墙面、地面、天花板</li>
                              <li>• 窗户玻璃、桌面</li>
                              <li>• 海报、黑板</li>
                              <li>• 家具表面</li>
                            </ul>
                            <div className="mt-2 pt-2 border-t border-green-200">
                              <p className="text-xs font-medium text-green-700">标注方式：用绿色半透明矩形标注</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Workflow Step 3 */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-lg flex items-center space-x-2">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground text-sm">3</span>
                        <span>步骤3：整理 - 制作元素分析卡片</span>
                      </h4>
                      <div className="ml-8 space-y-3">
                        <p className="text-muted-foreground">
                          在Canva中创建一个分析卡片，包含原图、标注图和文字说明。
                        </p>
                        <div className="p-4 bg-muted/50 rounded-lg">
                          <p className="font-medium mb-2 text-sm">📋 卡片内容：</p>
                          <div className="space-y-2">
                            <div className="flex items-start space-x-2">
                              <span className="text-primary font-bold">1.</span>
                              <p className="text-sm"><strong>场景描述：</strong>简要说明拍摄地点和场景（如"教室后墙书架区域"）</p>
                            </div>
                            <div className="flex items-start space-x-2">
                              <span className="text-primary font-bold">2.</span>
                              <p className="text-sm"><strong>元素清单：</strong>列出你标注的所有点、线、面及其位置</p>
                            </div>
                            <div className="flex items-start space-x-2">
                              <span className="text-primary font-bold">3.</span>
                              <p className="text-sm"><strong>关系分析：</strong>这些元素如何相互作用？哪些是主导元素？</p>
                            </div>
                            <div className="flex items-start space-x-2">
                              <span className="text-primary font-bold">4.</span>
                              <p className="text-sm"><strong>情感感受：</strong>这个空间给你什么感觉？（拥挤/开阔/有序/混乱）</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Thinking Scaffold */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-lg flex items-center space-x-2">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground text-sm">4</span>
                        <span>思考支架：5个透镜看空间</span>
                      </h4>
                      <div className="ml-8 space-y-2">
                        <p className="text-sm text-muted-foreground mb-3">
                          用这5个角度深入思考你观察的空间，发现更多设计的奥秘：
                        </p>
                        <div className="space-y-2">
                          <div className="p-3 bg-purple-50 border-l-4 border-purple-500 rounded-lg">
                            <p className="font-semibold text-sm mb-1">🔍 透镜1：功能视角</p>
                            <p className="text-xs text-muted-foreground">这些元素服务于什么功能？（照明、支撑、分隔、装饰）</p>
                          </div>
                          <div className="p-3 bg-orange-50 border-l-4 border-orange-500 rounded-lg">
                            <p className="font-semibold text-sm mb-1">👁️ 透镜2：视觉层次</p>
                            <p className="text-xs text-muted-foreground">你的视线首先看到什么？其次呢？为什么会有这样的顺序？</p>
                          </div>
                          <div className="p-3 bg-teal-50 border-l-4 border-teal-500 rounded-lg">
                            <p className="font-semibold text-sm mb-1">⚖️ 透镜3：平衡与节奏</p>
                            <p className="text-xs text-muted-foreground">元素分布是对称还是非对称？有没有重复的节奏感？</p>
                          </div>
                          <div className="p-3 bg-pink-50 border-l-4 border-pink-500 rounded-lg">
                            <p className="font-semibold text-sm mb-1">💭 透镜4：情感氛围</p>
                            <p className="text-xs text-muted-foreground">这个空间让你感到舒适还是压抑？温暖还是冷漠？</p>
                          </div>
                          <div className="p-3 bg-amber-50 border-l-4 border-amber-500 rounded-lg">
                            <p className="font-semibold text-sm mb-1">🔧 透镜5：改进机会</p>
                            <p className="text-xs text-muted-foreground">如果让你改进这个空间，你会调整什么？为什么？</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Difficulty Levels */}
                <Card className="border-2 border-primary/20">
                  <CardHeader>
                    <CardTitle>难度选择</CardTitle>
                    <CardDescription>根据自己的情况选择合适的挑战等级</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="p-4 bg-green-50 border-2 border-green-200 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-semibold text-green-700">Base 基础线</h4>
                          <Badge variant="outline" className="bg-green-100 text-green-700 border-green-300">推荐新手</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">
                          完成基本任务：拍摄1张照片，标注3个点、3条线、3个面，写简单说明。
                        </p>
                        <p className="text-xs text-green-700 font-medium">⏱️ 预计用时：30-45分钟</p>
                      </div>

                      <div className="p-4 bg-blue-50 border-2 border-blue-200 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-semibold text-blue-700">Advance 进阶</h4>
                          <Badge variant="outline" className="bg-blue-100 text-blue-700 border-blue-300">有一定基础</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">
                          拍摄2-3张不同场景的照片，每张标注5个以上元素，分析元素之间的关系，使用5个透镜深入思考。
                        </p>
                        <p className="text-xs text-blue-700 font-medium">⏱️ 预计用时：60-90分钟</p>
                      </div>

                      <div className="p-4 bg-purple-50 border-2 border-purple-200 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-semibold text-purple-700">Stretch 挑战</h4>
                          <Badge variant="outline" className="bg-purple-100 text-purple-700 border-purple-300">追求卓越</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">
                          拍摄一组照片（5张以上），对比分析不同空间的元素特点，提出改进方案，制作完整的视觉分析报告。
                        </p>
                        <p className="text-xs text-purple-700 font-medium">⏱️ 预计用时：90-120分钟</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Tutorials Tab */}
              <TabsContent value="tutorials" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Canva使用教程</CardTitle>
                    <CardDescription>从零开始学会用Canva进行视觉分析</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2 flex items-center space-x-2">
                          <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm">1</span>
                          <span>创建新设计</span>
                        </h4>
                        <p className="text-sm text-muted-foreground ml-8">
                          打开Canva，选择"自定义尺寸"，建议使用1920x1080px（横向）或1080x1920px（竖向），
                          根据你的照片方向选择。
                        </p>
                      </div>

                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2 flex items-center space-x-2">
                          <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm">2</span>
                          <span>上传照片</span>
                        </h4>
                        <p className="text-sm text-muted-foreground ml-8 mb-2">
                          点击左侧"上传"按钮，选择你拍摄的照片，将其拖拽到画布中，调整大小使其填满画布。
                        </p>
                        <p className="text-xs text-muted-foreground ml-8">
                          💡 小技巧：右键点击照片 → "设为背景"，可以锁定照片防止误移动。
                        </p>
                      </div>

                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2 flex items-center space-x-2">
                          <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm">3</span>
                          <span>标注"点"元素</span>
                        </h4>
                        <div className="ml-8 space-y-2">
                          <p className="text-sm text-muted-foreground">
                            点击左侧"元素" → 搜索"圆圈"或"circle" → 选择空心圆圈。
                          </p>
                          <ul className="text-xs space-y-1 text-muted-foreground">
                            <li>• 将圆圈拖到照片上，调整大小圈住"点"元素</li>
                            <li>• 点击圆圈，在顶部工具栏选择红色（#FF0000）</li>
                            <li>• 调整边框粗细（建议5-8px），确保清晰可见</li>
                            <li>• 复制圆圈（Ctrl+C / Cmd+C），标注其他点元素</li>
                          </ul>
                        </div>
                      </div>

                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2 flex items-center space-x-2">
                          <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm">4</span>
                          <span>标注"线"元素</span>
                        </h4>
                        <div className="ml-8 space-y-2">
                          <p className="text-sm text-muted-foreground">
                            点击左侧"元素" → 搜索"箭头"或"arrow" → 选择直线箭头。
                          </p>
                          <ul className="text-xs space-y-1 text-muted-foreground">
                            <li>• 将箭头拖到照片上，调整方向和长度沿着"线"元素</li>
                            <li>• 选择蓝色（#0066FF），调整粗细</li>
                            <li>• 也可以使用"线条"工具直接绘制</li>
                          </ul>
                        </div>
                      </div>

                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2 flex items-center space-x-2">
                          <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm">5</span>
                          <span>标注"面"元素</span>
                        </h4>
                        <div className="ml-8 space-y-2">
                          <p className="text-sm text-muted-foreground">
                            点击左侧"元素" → 搜索"矩形"或"rectangle" → 选择空心矩形。
                          </p>
                          <ul className="text-xs space-y-1 text-muted-foreground">
                            <li>• 将矩形拖到照片上，调整大小覆盖"面"元素</li>
                            <li>• 选择绿色（#00CC66），调整透明度到30-50%</li>
                            <li>• 或使用边框模式（无填充，只有绿色边框）</li>
                          </ul>
                        </div>
                      </div>

                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2 flex items-center space-x-2">
                          <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm">6</span>
                          <span>添加文字说明</span>
                        </h4>
                        <div className="ml-8 space-y-2">
                          <p className="text-sm text-muted-foreground">
                            点击左侧"文本" → 添加标题或正文文本框。
                          </p>
                          <ul className="text-xs space-y-1 text-muted-foreground">
                            <li>• 在照片旁边或底部添加场景描述</li>
                            <li>• 列出标注的元素清单</li>
                            <li>• 写下你的观察和思考</li>
                            <li>• 建议使用清晰易读的字体（如思源黑体、微软雅黑）</li>
                          </ul>
                        </div>
                      </div>

                      <div className="p-4 bg-primary/5 border-l-4 border-primary rounded-lg">
                        <h4 className="font-semibold mb-2">💡 进阶技巧</h4>
                        <ul className="text-sm space-y-1 text-muted-foreground">
                          <li>• 使用"图层"功能调整元素前后顺序</li>
                          <li>• 使用"对齐"工具让标注更整齐</li>
                          <li>• 使用"分组"功能将相关标注组合在一起</li>
                          <li>• 保存为模板，下次可以快速复用</li>
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>拍照技巧进阶</CardTitle>
                    <CardDescription>如何拍出更适合分析的照片</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {/* Photo Tips Visual */}
                    <PhotoTipsVisual />

                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2 text-green-700">✅ 好的示例</h4>
                        <ul className="text-sm space-y-2 text-muted-foreground">
                          <li>• 光线均匀，细节清晰</li>
                          <li>• 构图稳定，水平线平直</li>
                          <li>• 元素丰富但不杂乱</li>
                          <li>• 有明确的视觉焦点</li>
                          <li>• 包含多种类型的点线面</li>
                        </ul>
                      </div>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2 text-red-700">❌ 要避免的</h4>
                        <ul className="text-sm space-y-2 text-muted-foreground">
                          <li>• 逆光导致主体太暗</li>
                          <li>• 照片倾斜或模糊</li>
                          <li>• 元素过于单一或过于复杂</li>
                          <li>• 没有清晰的主体</li>
                          <li>• 距离太远看不清细节</li>
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Theory Tab */}
              <TabsContent value="theory" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-2xl">点线面：设计的基本语言</CardTitle>
                    <CardDescription>理解构成的三大基本元素</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <p className="text-muted-foreground">
                      就像文字是语言的基本单位，点、线、面是视觉设计的基本单位。任何复杂的设计，都可以分解为这三种元素的组合。
                      掌握它们，你就掌握了设计的基础语法。
                    </p>

                    {/* Point Theory */}
                    <div className="space-y-3">
                      <div className="flex items-center space-x-3 mb-3">
                        <div className="h-12 w-12 rounded-full bg-red-100 flex items-center justify-center">
                          <span className="text-2xl">•</span>
                        </div>
                        <div>
                          <h3 className="text-xl font-semibold">点（Point）</h3>
                          <p className="text-sm text-muted-foreground">视觉的起点，注意力的焦点</p>
                        </div>
                      </div>

                      <div className="p-4 border-l-4 border-red-500 bg-red-50 rounded-lg">
                        <h4 className="font-semibold mb-2">定义与特征</h4>
                        <p className="text-sm text-muted-foreground mb-3">
                          点是最小的视觉单位，没有长度和宽度（理论上），但在实际设计中，点是相对的——
                          相比周围元素，小而集中的就是点。点具有<strong>位置</strong>和<strong>聚焦</strong>的特性。
                        </p>
                        <div className="space-y-2">
                          <div className="p-3 bg-white rounded">
                            <p className="font-medium text-sm mb-1">🎯 视觉作用</p>
                            <ul className="text-xs space-y-1 text-muted-foreground">
                              <li>• <strong>吸引注意：</strong>人的视线会自然被点吸引</li>
                              <li>• <strong>标记位置：</strong>指示重要信息的所在</li>
                              <li>• <strong>创造节奏：</strong>多个点的排列形成视觉韵律</li>
                              <li>• <strong>暗示方向：</strong>点的排列可以引导视线移动</li>
                            </ul>
                          </div>
                          <div className="p-3 bg-white rounded">
                            <p className="font-medium text-sm mb-1">📐 设计应用</p>
                            <ul className="text-xs space-y-1 text-muted-foreground">
                              <li>• UI设计中的图标、按钮、通知小红点</li>
                              <li>• 建筑中的灯光、装饰物</li>
                              <li>• 平面设计中的Logo、标识</li>
                              <li>• 空间中的雕塑、家具单品</li>
                            </ul>
                          </div>
                        </div>
                      </div>

                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2">点的组合规律</h4>
                        <div className="grid md:grid-cols-3 gap-3">
                          <div className="text-center p-3 bg-white rounded">
                            <p className="font-medium text-sm mb-1">单点</p>
                            <p className="text-xs text-muted-foreground">孤立、突出、强调</p>
                          </div>
                          <div className="text-center p-3 bg-white rounded">
                            <p className="font-medium text-sm mb-1">两点</p>
                            <p className="text-xs text-muted-foreground">对比、对话、张力</p>
                          </div>
                          <div className="text-center p-3 bg-white rounded">
                            <p className="font-medium text-sm mb-1">多点</p>
                            <p className="text-xs text-muted-foreground">节奏、韵律、面化</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Line Theory */}
                    <div className="space-y-3">
                      <div className="flex items-center space-x-3 mb-3">
                        <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center">
                          <span className="text-2xl">—</span>
                        </div>
                        <div>
                          <h3 className="text-xl font-semibold">线（Line）</h3>
                          <p className="text-sm text-muted-foreground">连接与分割，引导与限定</p>
                        </div>
                      </div>

                      <div className="p-4 border-l-4 border-blue-500 bg-blue-50 rounded-lg">
                        <h4 className="font-semibold mb-2">定义与特征</h4>
                        <p className="text-sm text-muted-foreground mb-3">
                          线是点的运动轨迹，具有<strong>长度</strong>和<strong>方向</strong>，但宽度可以忽略不计。
                          线具有强烈的方向性和引导性，是空间中最活跃的元素。
                        </p>
                        <div className="space-y-2">
                          <div className="p-3 bg-white rounded">
                            <p className="font-medium text-sm mb-1">🎯 视觉作用</p>
                            <ul className="text-xs space-y-1 text-muted-foreground">
                              <li>• <strong>引导视线：</strong>线的方向引导观众的视线移动</li>
                              <li>• <strong>分割空间：</strong>线可以划分区域、创造边界</li>
                              <li>• <strong>连接元素：</strong>线连接不同的视觉元素，建立关系</li>
                              <li>• <strong>表达情感：</strong>不同类型的线传达不同情绪</li>
                            </ul>
                          </div>
                          <div className="p-3 bg-white rounded">
                            <p className="font-medium text-sm mb-1">📏 线的类型与情感</p>
                            <div className="space-y-2 mt-2">
                              <div className="flex items-center justify-between text-xs">
                                <span><strong>直线：</strong>理性、稳定、力量</span>
                                <div className="w-20 h-0.5 bg-gray-400"></div>
                              </div>
                              <div className="flex items-center justify-between text-xs">
                                <span><strong>曲线：</strong>柔和、优雅、流动</span>
                                <div className="w-20 h-0.5 bg-gray-400 rounded-full"></div>
                              </div>
                              <div className="flex items-center justify-between text-xs">
                                <span><strong>折线：</strong>动感、紧张、变化</span>
                                <div className="w-20 h-0.5 bg-gray-400"></div>
                              </div>
                              <div className="flex items-center justify-between text-xs">
                                <span><strong>虚线：</strong>轻盈、暗示、引导</span>
                                <div className="w-20 border-t border-dashed border-gray-400"></div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2">线的方向与心理</h4>
                        <div className="grid md:grid-cols-4 gap-3">
                          <div className="text-center p-3 bg-white rounded">
                            <p className="font-medium text-sm mb-1">水平线</p>
                            <p className="text-xs text-muted-foreground">平静、稳定、广阔</p>
                          </div>
                          <div className="text-center p-3 bg-white rounded">
                            <p className="font-medium text-sm mb-1">垂直线</p>
                            <p className="text-xs text-muted-foreground">高耸、庄严、力量</p>
                          </div>
                          <div className="text-center p-3 bg-white rounded">
                            <p className="font-medium text-sm mb-1">斜线</p>
                            <p className="text-xs text-muted-foreground">动感、不稳、紧张</p>
                          </div>
                          <div className="text-center p-3 bg-white rounded">
                            <p className="font-medium text-sm mb-1">曲线</p>
                            <p className="text-xs text-muted-foreground">柔美、自然、流畅</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Plane Theory */}
                    <div className="space-y-3">
                      <div className="flex items-center space-x-3 mb-3">
                        <div className="h-12 w-12 rounded bg-green-100 flex items-center justify-center">
                          <span className="text-2xl">▭</span>
                        </div>
                        <div>
                          <h3 className="text-xl font-semibold">面（Plane）</h3>
                          <p className="text-sm text-muted-foreground">空间的主体，视觉的舞台</p>
                        </div>
                      </div>

                      <div className="p-4 border-l-4 border-green-500 bg-green-50 rounded-lg">
                        <h4 className="font-semibold mb-2">定义与特征</h4>
                        <p className="text-sm text-muted-foreground mb-3">
                          面是线的运动轨迹，或多个点、线的集合，具有<strong>长度</strong>、<strong>宽度</strong>和<strong>形状</strong>。
                          面是空间的主要构成元素，占据视觉的主导地位。
                        </p>
                        <div className="space-y-2">
                          <div className="p-3 bg-white rounded">
                            <p className="font-medium text-sm mb-1">🎯 视觉作用</p>
                            <ul className="text-xs space-y-1 text-muted-foreground">
                              <li>• <strong>承载信息：</strong>面是内容的载体，如墙面、屏幕、纸张</li>
                              <li>• <strong>定义空间：</strong>面围合空间，创造内外、前后关系</li>
                              <li>• <strong>营造氛围：</strong>面的色彩、质感影响空间情绪</li>
                              <li>• <strong>建立层次：</strong>面的叠加创造深度和层次感</li>
                            </ul>
                          </div>
                          <div className="p-3 bg-white rounded">
                            <p className="font-medium text-sm mb-1">📐 面的形状与情感</p>
                            <div className="grid grid-cols-2 gap-2 mt-2">
                              <div className="text-xs">
                                <strong>几何形：</strong>规则、理性、现代
                              </div>
                              <div className="text-xs">
                                <strong>有机形：</strong>自然、柔和、亲切
                              </div>
                              <div className="text-xs">
                                <strong>规则面：</strong>秩序、稳定、专业
                              </div>
                              <div className="text-xs">
                                <strong>不规则面：</strong>活泼、创意、自由
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2">面的组合关系</h4>
                        <div className="grid md:grid-cols-3 gap-3">
                          <div className="text-center p-3 bg-white rounded">
                            <p className="font-medium text-sm mb-1">并置</p>
                            <p className="text-xs text-muted-foreground">平行、平等、对话</p>
                          </div>
                          <div className="text-center p-3 bg-white rounded">
                            <p className="font-medium text-sm mb-1">重叠</p>
                            <p className="text-xs text-muted-foreground">层次、深度、前后</p>
                          </div>
                          <div className="text-center p-3 bg-white rounded">
                            <p className="font-medium text-sm mb-1">穿插</p>
                            <p className="text-xs text-muted-foreground">交织、复杂、动感</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Point Line Plane Relationship */}
                <Card className="bg-gradient-to-br from-purple-50 to-blue-50 border-purple-200">
                  <CardHeader>
                    <CardTitle className="text-2xl">点线面的相互转化</CardTitle>
                    <CardDescription>理解元素之间的动态关系</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <p className="text-muted-foreground">
                        点、线、面不是绝对的，而是相对的。它们可以相互转化，取决于观察的距离、比例和语境。
                      </p>
                      <div className="grid md:grid-cols-3 gap-4">
                        <div className="p-4 bg-white rounded-lg shadow-sm">
                          <h4 className="font-semibold mb-2 text-red-700">点 → 线</h4>
                          <p className="text-sm text-muted-foreground mb-2">
                            当多个点排列成行，视觉上会连成线
                          </p>
                          <p className="text-xs text-muted-foreground">
                            例：一排路灯、虚线、点阵屏幕
                          </p>
                        </div>
                        <div className="p-4 bg-white rounded-lg shadow-sm">
                          <h4 className="font-semibold mb-2 text-blue-700">线 → 面</h4>
                          <p className="text-sm text-muted-foreground mb-2">
                            当多条线密集排列，视觉上会形成面
                          </p>
                          <p className="text-xs text-muted-foreground">
                            例：百叶窗、栅栏、线条纹理
                          </p>
                        </div>
                        <div className="p-4 bg-white rounded-lg shadow-sm">
                          <h4 className="font-semibold mb-2 text-green-700">面 → 点</h4>
                          <p className="text-sm text-muted-foreground mb-2">
                            当面缩小或距离拉远，会变成点
                          </p>
                          <p className="text-xs text-muted-foreground">
                            例：远处的建筑、地图上的城市
                          </p>
                        </div>
                      </div>
                      <div className="p-4 bg-amber-50 border-l-4 border-amber-500 rounded-lg">
                        <p className="text-sm font-medium mb-2">💡 设计启示</p>
                        <p className="text-sm text-muted-foreground">
                          理解这种转化关系，可以帮助你在不同尺度上思考设计。从远处看是一个点，走近看可能是一个复杂的面；
                          一条线可能由无数个点组成。这种多尺度的思维是优秀设计师的必备能力。
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Element Quiz */}
                <ElementQuiz />

                {/* Related Content */}
                <RelatedContent currentSection="theory" />
              </TabsContent>

              {/* Examples Tab */}
              <TabsContent value="examples" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>经典案例分析</CardTitle>
                    <CardDescription>从大师作品中学习点线面的运用</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {/* Example 1 */}
                      <div className="p-4 border-2 border-primary/20 rounded-lg">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <h4 className="font-semibold text-lg">蒙德里安《红黄蓝构成》</h4>
                            <p className="text-sm text-muted-foreground">几何抽象主义代表作</p>
                          </div>
                          <Badge>国际</Badge>
                        </div>
                        <div className="aspect-video bg-muted rounded-lg flex items-center justify-center mb-4">
                          <Image className="h-12 w-12 text-muted-foreground" />
                        </div>
                        <div className="space-y-3">
                          <div className="p-3 bg-red-50 rounded-lg">
                            <p className="text-sm"><strong className="text-red-700">点的运用：</strong>
                            虽然画面中没有明显的"点"，但线条的交叉点成为视觉焦点，引导视线在画面中游走。</p>
                          </div>
                          <div className="p-3 bg-blue-50 rounded-lg">
                            <p className="text-sm"><strong className="text-blue-700">线的运用：</strong>
                            粗黑色直线分割画面，创造理性、秩序的感觉。水平线和垂直线的交织形成稳定的网格结构。</p>
                          </div>
                          <div className="p-3 bg-green-50 rounded-lg">
                            <p className="text-sm"><strong className="text-green-700">面的运用：</strong>
                            红、黄、蓝三原色块和白色、灰色面形成对比，大小不同的面创造视觉平衡和节奏感。</p>
                          </div>
                          <div className="p-3 bg-purple-50 border-l-4 border-purple-500 rounded-lg">
                            <p className="text-sm"><strong>设计启示：</strong>
                            简单的元素通过精心的比例和位置安排，可以创造出强大的视觉力量。少即是多。</p>
                          </div>
                        </div>
                      </div>

                      {/* Example 2 */}
                      <div className="p-4 border-2 border-primary/20 rounded-lg">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <h4 className="font-semibold text-lg">故宫建筑群</h4>
                            <p className="text-sm text-muted-foreground">中国传统建筑的点线面</p>
                          </div>
                          <Badge>国内</Badge>
                        </div>
                        <div className="aspect-video bg-muted rounded-lg flex items-center justify-center mb-4">
                          <Image className="h-12 w-12 text-muted-foreground" />
                        </div>
                        <div className="space-y-3">
                          <div className="p-3 bg-red-50 rounded-lg">
                            <p className="text-sm"><strong className="text-red-700">点的运用：</strong>
                            屋顶的装饰、门钉、灯笼等元素作为视觉焦点，标记重要位置，增加细节趣味。</p>
                          </div>
                          <div className="p-3 bg-blue-50 rounded-lg">
                            <p className="text-sm"><strong className="text-blue-700">线的运用：</strong>
                            中轴线贯穿整个建筑群，强调对称和秩序。屋檐的曲线柔和了建筑的刚硬，增加优雅感。</p>
                          </div>
                          <div className="p-3 bg-green-50 rounded-lg">
                            <p className="text-sm"><strong className="text-green-700">面的运用：</strong>
                            红色墙面、黄色琉璃瓦屋顶、白色石台阶，色彩鲜明的面创造层次和等级感。</p>
                          </div>
                          <div className="p-3 bg-purple-50 border-l-4 border-purple-500 rounded-lg">
                            <p className="text-sm"><strong>设计启示：</strong>
                            对称的线性布局创造庄严感，曲线的运用增加柔和，色彩面的对比强化视觉冲击。</p>
                          </div>
                        </div>
                      </div>

                      {/* Example 3 */}
                      <div className="p-4 border-2 border-primary/20 rounded-lg">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <h4 className="font-semibold text-lg">苹果Apple Store设计</h4>
                            <p className="text-sm text-muted-foreground">极简主义商业空间</p>
                          </div>
                          <Badge>国际</Badge>
                        </div>
                        <div className="aspect-video bg-muted rounded-lg flex items-center justify-center mb-4">
                          <Image className="h-12 w-12 text-muted-foreground" />
                        </div>
                        <div className="space-y-3">
                          <div className="p-3 bg-red-50 rounded-lg">
                            <p className="text-sm"><strong className="text-red-700">点的运用：</strong>
                            产品陈列作为视觉焦点，每个产品都是一个"点"，吸引顾客注意。Logo作为品牌标识点。</p>
                          </div>
                          <div className="p-3 bg-blue-50 rounded-lg">
                            <p className="text-sm"><strong className="text-blue-700">线的运用：</strong>
                            简洁的货架线条、天花板的灯带线条，引导视线流动，创造开阔感。</p>
                          </div>
                          <div className="p-3 bg-green-50 rounded-lg">
                            <p className="text-sm"><strong className="text-green-700">面的运用：</strong>
                            大面积的白色墙面、木质桌面、玻璃幕墙，简洁的面让产品成为主角。</p>
                          </div>
                          <div className="p-3 bg-purple-50 border-l-4 border-purple-500 rounded-lg">
                            <p className="text-sm"><strong>设计启示：</strong>
                            极简的点线面运用，让空间通透、产品突出。少量元素，精心布局，创造高级感。</p>
                          </div>
                        </div>
                      </div>

                      {/* Example 4 */}
                      <div className="p-4 border-2 border-primary/20 rounded-lg">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <h4 className="font-semibold text-lg">上海外滩夜景</h4>
                            <p className="text-sm text-muted-foreground">城市光影的点线面</p>
                          </div>
                          <Badge>国内</Badge>
                        </div>
                        <div className="aspect-video bg-muted rounded-lg flex items-center justify-center mb-4">
                          <Image className="h-12 w-12 text-muted-foreground" />
                        </div>
                        <div className="space-y-3">
                          <div className="p-3 bg-red-50 rounded-lg">
                            <p className="text-sm"><strong className="text-red-700">点的运用：</strong>
                            建筑灯光、船只灯光、广告牌，无数的光点在夜空中闪烁，创造繁华感。</p>
                          </div>
                          <div className="p-3 bg-blue-50 rounded-lg">
                            <p className="text-sm"><strong className="text-blue-700">线的运用：</strong>
                            建筑轮廓线、江岸线、桥梁线条，勾勒出城市天际线，引导视线横向延展。</p>
                          </div>
                          <div className="p-3 bg-green-50 rounded-lg">
                            <p className="text-sm"><strong className="text-green-700">面的运用：</strong>
                            建筑立面、天空、江面，大面积的暗色衬托明亮的点线，创造戏剧性对比。</p>
                          </div>
                          <div className="p-3 bg-purple-50 border-l-4 border-purple-500 rounded-lg">
                            <p className="text-sm"><strong>设计启示：</strong>
                            点的密集创造繁华，线的延伸创造广阔，面的对比创造层次。光影是城市的化妆师。</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* More Examples Link */}
                <Card className="bg-primary/5 border-primary/20">
                  <CardHeader>
                    <CardTitle>更多案例参考</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <p className="text-sm text-muted-foreground mb-3">
                        想看更多点线面的应用案例？这些网站有丰富的设计作品可以参考：
                      </p>
                      <div className="grid md:grid-cols-2 gap-2">
                        <a href="https://www.zcool.com.cn/" target="_blank" rel="noopener noreferrer" 
                           className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors">
                          <span className="text-sm">站酷 - 中国设计师社区</span>
                          <ExternalLink className="h-4 w-4 text-muted-foreground" />
                        </a>
                        <a href="https://www.behance.net/" target="_blank" rel="noopener noreferrer" 
                           className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors">
                          <span className="text-sm">Behance - 全球创意平台</span>
                          <ExternalLink className="h-4 w-4 text-muted-foreground" />
                        </a>
                        <a href="https://www.pinterest.com/" target="_blank" rel="noopener noreferrer" 
                           className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors">
                          <span className="text-sm">Pinterest - 灵感图库</span>
                          <ExternalLink className="h-4 w-4 text-muted-foreground" />
                        </a>
                        <a href="https://www.archdaily.cn/" target="_blank" rel="noopener noreferrer" 
                           className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors">
                          <span className="text-sm">ArchDaily - 建筑设计</span>
                          <ExternalLink className="h-4 w-4 text-muted-foreground" />
                        </a>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Related Content */}
                <RelatedContent currentSection="examples" />
              </TabsContent>

              {/* AI Application Tab */}
              <TabsContent value="ai" className="space-y-6">
                {/* Prompt Generator */}
                <PromptGenerator />

                <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200">
                  <CardHeader>
                    <div className="flex items-center space-x-2">
                      <Sparkles className="h-5 w-5 text-purple-600" />
                      <CardTitle>AI辅助设计：点线面生成</CardTitle>
                    </div>
                    <CardDescription>
                      学会用AI工具快速生成点线面构成作品，提升创作效率
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <p className="text-muted-foreground">
                      AI绘画工具（如Midjourney、Stable Diffusion、文心一格等）可以帮助你快速生成点线面构成的灵感图。
                      关键是学会如何用准确的提示词（Prompt）描述你想要的效果。
                    </p>

                    {/* Midjourney Prompts */}
                    <div className="space-y-4">
                      <h4 className="font-semibold text-lg">Midjourney / Stable Diffusion 提示词模板</h4>
                      
                      <div className="p-4 bg-white border-2 border-purple-200 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <h5 className="font-semibold">点元素构成</h5>
                          <Badge variant="outline" className="bg-red-100 text-red-700">Point</Badge>
                        </div>
                        <div className="p-3 bg-gray-50 rounded font-mono text-xs mb-2">
                          abstract composition with dots, scattered points pattern, minimalist design, 
                          geometric dots arrangement, black and white, clean background, 
                          Bauhaus style, --ar 1:1 --v 6
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">
                          <strong>中文翻译：</strong>抽象构成，点状元素，散布的点图案，极简设计，几何点排列，黑白，干净背景，包豪斯风格
                        </p>
                        <div className="p-2 bg-blue-50 rounded text-xs">
                          <strong>关键词解析：</strong>
                          <ul className="mt-1 space-y-1">
                            <li>• <code>abstract composition</code> - 抽象构成</li>
                            <li>• <code>dots / points</code> - 点元素</li>
                            <li>• <code>scattered / arranged</code> - 散布/排列</li>
                            <li>• <code>Bauhaus style</code> - 包豪斯风格（几何、理性）</li>
                          </ul>
                        </div>
                      </div>

                      <div className="p-4 bg-white border-2 border-blue-200 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <h5 className="font-semibold">线元素构成</h5>
                          <Badge variant="outline" className="bg-blue-100 text-blue-700">Line</Badge>
                        </div>
                        <div className="p-3 bg-gray-50 rounded font-mono text-xs mb-2">
                          abstract linear composition, dynamic lines, intersecting straight lines, 
                          geometric line art, black lines on white background, modernist design, 
                          rhythm and movement, --ar 16:9 --v 6
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">
                          <strong>中文翻译：</strong>抽象线性构成，动态线条，交叉直线，几何线条艺术，白底黑线，现代主义设计，节奏与动感
                        </p>
                        <div className="p-2 bg-blue-50 rounded text-xs">
                          <strong>关键词解析：</strong>
                          <ul className="mt-1 space-y-1">
                            <li>• <code>linear composition</code> - 线性构成</li>
                            <li>• <code>intersecting lines</code> - 交叉线条</li>
                            <li>• <code>dynamic / static</code> - 动态/静态</li>
                            <li>• <code>rhythm and movement</code> - 节奏与动感</li>
                          </ul>
                        </div>
                      </div>

                      <div className="p-4 bg-white border-2 border-green-200 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <h5 className="font-semibold">面元素构成</h5>
                          <Badge variant="outline" className="bg-green-100 text-green-700">Plane</Badge>
                        </div>
                        <div className="p-3 bg-gray-50 rounded font-mono text-xs mb-2">
                          abstract geometric composition, overlapping shapes, rectangular planes, 
                          color blocks, Mondrian inspired, primary colors, balanced composition, 
                          De Stijl movement, --ar 1:1 --v 6
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">
                          <strong>中文翻译：</strong>抽象几何构成，重叠形状，矩形平面，色块，蒙德里安风格，三原色，平衡构成，风格派运动
                        </p>
                        <div className="p-2 bg-blue-50 rounded text-xs">
                          <strong>关键词解析：</strong>
                          <ul className="mt-1 space-y-1">
                            <li>• <code>geometric shapes</code> - 几何形状</li>
                            <li>• <code>overlapping</code> - 重叠</li>
                            <li>• <code>color blocks</code> - 色块</li>
                            <li>• <code>Mondrian / De Stijl</code> - 蒙德里安/风格派</li>
                          </ul>
                        </div>
                      </div>

                      <div className="p-4 bg-white border-2 border-purple-200 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <h5 className="font-semibold">点线面综合构成</h5>
                          <Badge variant="outline" className="bg-purple-100 text-purple-700">Combined</Badge>
                        </div>
                        <div className="p-3 bg-gray-50 rounded font-mono text-xs mb-2">
                          abstract composition combining points lines and planes, Bauhaus design, 
                          geometric elements, black white and red, balanced layout, modernist art, 
                          constructivism style, --ar 3:2 --v 6
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">
                          <strong>中文翻译：</strong>点线面综合抽象构成，包豪斯设计，几何元素，黑白红配色，平衡布局，现代主义艺术，构成主义风格
                        </p>
                        <div className="p-2 bg-blue-50 rounded text-xs">
                          <strong>关键词解析：</strong>
                          <ul className="mt-1 space-y-1">
                            <li>• <code>combining points lines and planes</code> - 点线面结合</li>
                            <li>• <code>Bauhaus / Constructivism</code> - 包豪斯/构成主义</li>
                            <li>• <code>balanced layout</code> - 平衡布局</li>
                          </ul>
                        </div>
                      </div>
                    </div>

                    {/* Chinese AI Tools */}
                    <div className="space-y-4">
                      <h4 className="font-semibold text-lg">国内AI工具提示词示例</h4>
                      
                      <div className="p-4 bg-white border-2 border-orange-200 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <h5 className="font-semibold">文心一格 / 通义万相</h5>
                          <Badge variant="outline">中文提示词</Badge>
                        </div>
                        <div className="space-y-3">
                          <div>
                            <p className="text-sm font-medium mb-1">点元素：</p>
                            <div className="p-2 bg-gray-50 rounded text-sm">
                              抽象几何构成，点状元素，圆点排列，极简主义，黑白配色，包豪斯风格，高清，艺术摄影
                            </div>
                          </div>
                          <div>
                            <p className="text-sm font-medium mb-1">线元素：</p>
                            <div className="p-2 bg-gray-50 rounded text-sm">
                              抽象线条构成，交叉直线，几何线条艺术，现代主义设计，简洁，黑色线条白色背景
                            </div>
                          </div>
                          <div>
                            <p className="text-sm font-medium mb-1">面元素：</p>
                            <div className="p-2 bg-gray-50 rounded text-sm">
                              几何色块构成，矩形平面，蒙德里安风格，红黄蓝三原色，平衡构图，现代艺术
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Tips */}
                    <div className="p-4 bg-amber-50 border-l-4 border-amber-500 rounded-lg">
                      <h4 className="font-semibold mb-2 flex items-center space-x-2">
                        <Lightbulb className="h-5 w-5 text-amber-600" />
                        <span>AI提示词技巧</span>
                      </h4>
                      <ul className="space-y-2 text-sm text-muted-foreground">
                        <li className="flex items-start space-x-2">
                          <span className="text-amber-600 mt-0.5">→</span>
                          <span><strong>明确元素：</strong>清楚说明要点、线还是面，或者它们的组合</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <span className="text-amber-600 mt-0.5">→</span>
                          <span><strong>指定风格：</strong>包豪斯、蒙德里安、极简主义等风格关键词很有效</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <span className="text-amber-600 mt-0.5">→</span>
                          <span><strong>控制色彩：</strong>指定配色方案（如black and white, primary colors）</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <span className="text-amber-600 mt-0.5">→</span>
                          <span><strong>调整比例：</strong>使用--ar参数控制画面比例（1:1正方形，16:9横向等）</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <span className="text-amber-600 mt-0.5">→</span>
                          <span><strong>迭代优化：</strong>第一次生成不满意，调整关键词再试，多尝试几次</span>
                        </li>
                      </ul>
                    </div>

                    {/* AI as Inspiration */}
                    <div className="p-4 bg-blue-50 border-l-4 border-blue-500 rounded-lg">
                      <h4 className="font-semibold mb-2 flex items-center space-x-2">
                        <Brain className="h-5 w-5 text-blue-600" />
                        <span>AI是灵感工具，不是替代品</span>
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        AI生成的图像可以作为你的灵感来源和参考，但不要直接提交AI生成的作品。
                        你应该从AI图像中学习构图、配色、元素关系，然后用自己的方式重新创作。
                        真正的学习发生在你动手实践的过程中。
                      </p>
                    </div>
                  </CardContent>
                </Card>

                {/* AI Tools Links */}
                <Card>
                  <CardHeader>
                    <CardTitle>AI工具推荐</CardTitle>
                    <CardDescription>国内可访问的AI绘画工具</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <a href="https://yige.baidu.com/" target="_blank" rel="noopener noreferrer" 
                         className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors">
                        <div>
                          <p className="font-medium">文心一格</p>
                          <p className="text-xs text-muted-foreground">百度出品，中文友好</p>
                        </div>
                        <ExternalLink className="h-4 w-4 text-muted-foreground" />
                      </a>
                      <a href="https://tongyi.aliyun.com/wanxiang/" target="_blank" rel="noopener noreferrer" 
                         className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors">
                        <div>
                          <p className="font-medium">通义万相</p>
                          <p className="text-xs text-muted-foreground">阿里出品，免费使用</p>
                        </div>
                        <ExternalLink className="h-4 w-4 text-muted-foreground" />
                      </a>
                      <a href="https://www.tiamat.world/" target="_blank" rel="noopener noreferrer" 
                         className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors">
                        <div>
                          <p className="font-medium">Tiamat</p>
                          <p className="text-xs text-muted-foreground">国内Stable Diffusion平台</p>
                        </div>
                        <ExternalLink className="h-4 w-4 text-muted-foreground" />
                      </a>
                    </div>
                  </CardContent>
                </Card>

                {/* Related Content */}
                <RelatedContent currentSection="ai" />
              </TabsContent>

              {/* Works Tab */}
              <TabsContent value="works">
                <Card>
                  <CardHeader>
                    <CardTitle>优秀学生作业</CardTitle>
                    <CardDescription>查看往届学生的点线面分析作品</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-12 text-muted-foreground">
                      <Award className="h-16 w-16 mx-auto mb-4 opacity-50" />
                      <p>优秀作业正在收集整理中...</p>
                      <p className="text-sm mt-2">你的作品也许会成为下一届的优秀范例！</p>
                    </div>
                  </CardContent>
                </Card>

                {/* Related Content */}
                <RelatedContent currentSection="tasks" />
              </TabsContent>

              {/* Resources Tab */}
              <TabsContent value="resources" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>拓展资源</CardTitle>
                    <CardDescription>深入学习点线面构成的参考资料</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-semibold mb-3">📚 在线教程</h4>
                        <div className="space-y-2">
                          <a href="https://www.bilibili.com/video/BV1xx411c7mD/" target="_blank" rel="noopener noreferrer" 
                             className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors">
                            <div>
                              <p className="font-medium text-sm">平面构成基础教程</p>
                              <p className="text-xs text-muted-foreground">B站 - 详细讲解点线面原理</p>
                            </div>
                            <ExternalLink className="h-4 w-4 text-muted-foreground" />
                          </a>
                          <a href="https://www.canva.cn/learn/" target="_blank" rel="noopener noreferrer" 
                             className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors">
                            <div>
                              <p className="font-medium text-sm">Canva设计学院</p>
                              <p className="text-xs text-muted-foreground">官方教程，从入门到精通</p>
                            </div>
                            <ExternalLink className="h-4 w-4 text-muted-foreground" />
                          </a>
                        </div>
                      </div>

                      <div>
                        <h4 className="font-semibold mb-3">🎨 设计灵感</h4>
                        <div className="space-y-2">
                          <a href="https://www.zcool.com.cn/" target="_blank" rel="noopener noreferrer" 
                             className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors">
                            <div>
                              <p className="font-medium text-sm">站酷</p>
                              <p className="text-xs text-muted-foreground">中国设计师社区，海量作品</p>
                            </div>
                            <ExternalLink className="h-4 w-4 text-muted-foreground" />
                          </a>
                          <a href="https://www.pinterest.com/" target="_blank" rel="noopener noreferrer" 
                             className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors">
                            <div>
                              <p className="font-medium text-sm">Pinterest</p>
                              <p className="text-xs text-muted-foreground">全球最大灵感图库</p>
                            </div>
                            <ExternalLink className="h-4 w-4 text-muted-foreground" />
                          </a>
                          <a href="https://www.behance.net/" target="_blank" rel="noopener noreferrer" 
                             className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors">
                            <div>
                              <p className="font-medium text-sm">Behance</p>
                              <p className="text-xs text-muted-foreground">Adobe旗下创意平台</p>
                            </div>
                            <ExternalLink className="h-4 w-4 text-muted-foreground" />
                          </a>
                        </div>
                      </div>

                      <div>
                        <h4 className="font-semibold mb-3">📖 推荐书籍</h4>
                        <div className="space-y-2">
                          <div className="p-3 border rounded-lg">
                            <p className="font-medium text-sm">《平面构成》- 朝仓直巳</p>
                            <p className="text-xs text-muted-foreground">经典教材，系统讲解构成原理</p>
                          </div>
                          <div className="p-3 border rounded-lg">
                            <p className="font-medium text-sm">《点线面》- 康定斯基</p>
                            <p className="text-xs text-muted-foreground">抽象艺术大师的理论著作</p>
                          </div>
                          <div className="p-3 border rounded-lg">
                            <p className="font-medium text-sm">《设计的觉醒》- 田中一光</p>
                            <p className="text-xs text-muted-foreground">日本设计大师的设计哲学</p>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h4 className="font-semibold mb-3">🔧 实用工具</h4>
                        <div className="space-y-2">
                          <a href="https://www.canva.cn/" target="_blank" rel="noopener noreferrer" 
                             className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors">
                            <div>
                              <p className="font-medium text-sm">Canva</p>
                              <p className="text-xs text-muted-foreground">在线设计工具，本课程主要工具</p>
                            </div>
                            <ExternalLink className="h-4 w-4 text-muted-foreground" />
                          </a>
                          <a href="https://www.figma.com/" target="_blank" rel="noopener noreferrer" 
                             className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors">
                            <div>
                              <p className="font-medium text-sm">Figma</p>
                              <p className="text-xs text-muted-foreground">专业UI设计工具（进阶）</p>
                            </div>
                            <ExternalLink className="h-4 w-4 text-muted-foreground" />
                          </a>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Common Pitfalls */}
                <Card className="border-destructive/50">
                  <CardHeader>
                    <div className="flex items-center space-x-2">
                      <AlertCircle className="h-5 w-5 text-destructive" />
                      <CardTitle>常见问题与陷阱</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex items-start space-x-2">
                          <span className="text-destructive font-bold">❌</span>
                          <div>
                            <p className="text-sm font-medium">陷阱1：标注太少或太多</p>
                            <p className="text-xs text-muted-foreground">太少看不出分析深度，太多画面混乱</p>
                          </div>
                        </div>
                        <div className="flex items-start space-x-2 ml-6">
                          <span className="text-green-600 font-bold">✅</span>
                          <p className="text-sm font-medium text-green-600">建议标注8-12个元素，重点突出！</p>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex items-start space-x-2">
                          <span className="text-destructive font-bold">❌</span>
                          <div>
                            <p className="text-sm font-medium">陷阱2：只标注不思考</p>
                            <p className="text-xs text-muted-foreground">机械地圈画，没有分析元素关系和作用</p>
                          </div>
                        </div>
                        <div className="flex items-start space-x-2 ml-6">
                          <span className="text-green-600 font-bold">✅</span>
                          <p className="text-sm font-medium text-green-600">用5个透镜深入思考，写下你的观察！</p>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex items-start space-x-2">
                          <span className="text-destructive font-bold">❌</span>
                          <div>
                            <p className="text-sm font-medium">陷阱3：照片质量差</p>
                            <p className="text-xs text-muted-foreground">模糊、太暗、构图歪斜，影响分析</p>
                          </div>
                        </div>
                        <div className="flex items-start space-x-2 ml-6">
                          <span className="text-green-600 font-bold">✅</span>
                          <p className="text-sm font-medium text-green-600">光线充足、构图稳定、细节清晰！</p>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex items-start space-x-2">
                          <span className="text-destructive font-bold">❌</span>
                          <div>
                            <p className="text-sm font-medium">陷阱4：元素分类混乱</p>
                            <p className="text-xs text-muted-foreground">把线标成点，把面标成线</p>
                          </div>
                        </div>
                        <div className="flex items-start space-x-2 ml-6">
                          <span className="text-green-600 font-bold">✅</span>
                          <p className="text-sm font-medium text-green-600">理解相对性：小而集中是点，延伸是线，大面积是面！</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Next Steps */}
                <Card className="bg-primary/5 border-primary/20">
                  <CardHeader>
                    <CardTitle>下一步</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <p className="text-sm">太棒了！你已经完成了设计构成的第一步——学会观察和分析点线面。</p>
                      <p className="text-sm">记住：<strong>设计不在书本里，而在你的生活中。</strong>保持好奇心，用设计师之眼看世界。</p>
                      <p className="text-sm">思考：今天回家的路上，你能发现多少个有趣的点线面组合？</p>
                      <p className="text-sm">准备：下一节课我们将学习<strong>材质发现</strong>，开始关注物体的表面质感！</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>

            {/* Navigation */}
            <div className="flex justify-between mt-12 pt-8 border-t">
              <Link href="/curriculum">
                <Button variant="outline">
                  <ChevronLeft className="h-4 w-4 mr-2" />
                  返回课程大纲
                </Button>
              </Link>
              <Link href="/curriculum/2">
                <Button>
                  下一节：触·材质发现
                  <ChevronRight className="h-4 w-4 ml-2" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t py-8 bg-muted/30">
        <div className="container">
          <div className="text-center text-sm text-muted-foreground">
            <p>© 2025 数字设计构成课程 · 用设计师之眼看世界</p>
          </div>
        </div>
      </footer>
      
      {/* Quick Navigation and Back to Top */}
      <QuickNav />
    </div>
  );
}

