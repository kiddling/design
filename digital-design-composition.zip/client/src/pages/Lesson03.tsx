import Navigation from "@/components/Navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Target, 
  BookOpen, 
  Lightbulb, 
  Image, 
  Award, 
  ExternalLink, 
  ChevronLeft, 
  ChevronRight,
  Camera,
  Pencil,
  Eye,
  AlertCircle,
  Scale
} from "lucide-react";
import { Link } from "wouter";

export default function Lesson03() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1 py-8">
        <div className="container">
          <div className="max-w-6xl mx-auto">
            {/* Header */}
            <div className="mb-8">
              <Link href="/curriculum">
                <Button variant="ghost" className="mb-4">
                  <ChevronLeft className="h-4 w-4 mr-2" />
                  返回课程大纲
                </Button>
              </Link>
              
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <Badge>第3节</Badge>
                    <Badge variant="outline">3小时</Badge>
                    <Badge variant="outline">课前20分钟 + 课中90分钟</Badge>
                  </div>
                  <h1 className="text-4xl font-bold mb-2">构·动态平衡</h1>
                  <p className="text-xl text-muted-foreground">Dynamic Balance</p>
                </div>
              </div>
            </div>

            {/* Learning Objectives */}
            <Card className="mb-8">
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <Target className="h-5 w-5 text-primary" />
                  <CardTitle>学习目标</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span>理解平衡的概念及其在设计中的重要性</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span>掌握对称平衡、非对称平衡和放射平衡三种基本类型</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span>学会运用点、线、面元素创造平衡构成</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span>培养视觉平衡感知能力，能够判断和调整构成的平衡状态</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Main Content Tabs */}
            <Tabs defaultValue="tasks" className="space-y-6">
              <TabsList className="grid w-full grid-cols-6">
                <TabsTrigger value="tasks">
                  <Scale className="h-4 w-4 mr-2" />
                  任务卡片
                </TabsTrigger>
                <TabsTrigger value="tutorials">
                  <Camera className="h-4 w-4 mr-2" />
                  教程
                </TabsTrigger>
                <TabsTrigger value="theory">
                  <BookOpen className="h-4 w-4 mr-2" />
                  理论
                </TabsTrigger>
                <TabsTrigger value="examples">
                  <Image className="h-4 w-4 mr-2" />
                  案例
                </TabsTrigger>
                <TabsTrigger value="works">
                  <Award className="h-4 w-4 mr-2" />
                  优秀作业
                </TabsTrigger>
                <TabsTrigger value="resources">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  拓展
                </TabsTrigger>
              </TabsList>

              {/* Tasks Tab */}
              <TabsContent value="tasks" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-2xl">平衡构成练习：让画面稳定起来</CardTitle>
                    <CardDescription className="text-base">
                      平衡不等于对称！这节课，我们要用前两节课收集的点、线、面元素，
                      创作三种不同类型的平衡构成，体会视觉重量的分配与平衡的艺术。
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Task 1 */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-lg flex items-center space-x-2">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground text-sm">1</span>
                        <span>任务1：对称平衡构成（Base难度）</span>
                      </h4>
                      <p className="text-muted-foreground ml-8">
                        创作一幅以中轴线为基准的对称构成，左右两侧元素镜像对称。
                      </p>
                      <div className="ml-8 p-4 bg-muted/50 rounded-lg">
                        <p className="font-medium mb-2 text-sm">💡 创作要求：</p>
                        <ul className="space-y-1">
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>画布尺寸：正方形（如1080x1080px）</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>使用至少5个元素（点、线、面的组合）</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>中轴线两侧完全对称或近似对称</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>可以使用你拍摄的材质照片作为元素</span>
                          </li>
                        </ul>
                      </div>
                    </div>

                    {/* Task 2 */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-lg flex items-center space-x-2">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground text-sm">2</span>
                        <span>任务2：非对称平衡构成（Advance难度）</span>
                      </h4>
                      <p className="text-muted-foreground ml-8">
                        创作一幅非对称但视觉平衡的构成，通过大小、颜色、位置的调整达到平衡。
                      </p>
                      <div className="ml-8 p-4 bg-muted/50 rounded-lg">
                        <p className="font-medium mb-2 text-sm">💡 创作要求：</p>
                        <ul className="space-y-1">
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>画布尺寸：正方形或横向矩形</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>使用至少7个不同大小、形状的元素</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>左右两侧视觉重量相等但形式不同</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>运用对比：大与小、多与少、深色与浅色</span>
                          </li>
                        </ul>
                      </div>
                    </div>

                    {/* Task 3 */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-lg flex items-center space-x-2">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground text-sm">3</span>
                        <span>任务3：放射平衡构成（Stretch难度）</span>
                      </h4>
                      <p className="text-muted-foreground ml-8">
                        创作一幅以中心点为基准向四周放射的平衡构成，展现动态的平衡美感。
                      </p>
                      <div className="ml-8 p-4 bg-muted/50 rounded-lg">
                        <p className="font-medium mb-2 text-sm">💡 创作要求：</p>
                        <ul className="space-y-1">
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>画布尺寸：正方形</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>确定一个明确的视觉中心</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>元素从中心向外放射或围绕中心旋转</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>可以是规则放射（如花瓣）或自由放射（如爆炸）</span>
                          </li>
                        </ul>
                      </div>
                    </div>

                    {/* Workflow */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-lg flex items-center space-x-2">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground text-sm">4</span>
                        <span>工作流程</span>
                      </h4>
                      <div className="ml-8 space-y-2">
                        <div className="p-3 bg-primary/5 rounded-lg">
                          <p className="font-medium text-sm mb-1">步骤1：准备元素</p>
                          <p className="text-sm text-muted-foreground">从前两节课的照片中提取元素，或使用Canva的形状工具创建基础图形</p>
                        </div>
                        <div className="p-3 bg-primary/5 rounded-lg">
                          <p className="font-medium text-sm mb-1">步骤2：草图构思</p>
                          <p className="text-sm text-muted-foreground">在纸上或脑海中构思布局，确定平衡类型和元素位置</p>
                        </div>
                        <div className="p-3 bg-primary/5 rounded-lg">
                          <p className="font-medium text-sm mb-1">步骤3：数字创作</p>
                          <p className="text-sm text-muted-foreground">在Canva中实现构成，不断调整元素的大小、位置、颜色</p>
                        </div>
                        <div className="p-3 bg-primary/5 rounded-lg">
                          <p className="font-medium text-sm mb-1">步骤4：平衡检验</p>
                          <p className="text-sm text-muted-foreground">眯起眼睛看画面，感受视觉重量是否平衡，是否有倾斜感</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Balance Thinking */}
                <Card className="border-2 border-primary/20">
                  <CardHeader>
                    <div className="flex items-center space-x-2">
                      <Eye className="h-5 w-5 text-primary" />
                      <CardTitle>平衡感知训练</CardTitle>
                    </div>
                    <CardDescription>
                      如何判断你的构成是否平衡？
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="p-4 bg-muted/30 rounded-lg">
                      <h4 className="font-semibold mb-2">方法1：眯眼测试</h4>
                      <p className="text-sm text-muted-foreground">
                        眯起眼睛，模糊细节，只看整体的明暗分布。如果感觉画面向一侧倾斜，说明不平衡。
                      </p>
                    </div>
                    <div className="p-4 bg-muted/30 rounded-lg">
                      <h4 className="font-semibold mb-2">方法2：想象天平</h4>
                      <p className="text-sm text-muted-foreground">
                        想象画面中央有一个支点，左右两侧的元素是砝码。大的、深色的、靠近边缘的元素更重。
                      </p>
                    </div>
                    <div className="p-4 bg-muted/30 rounded-lg">
                      <h4 className="font-semibold mb-2">方法3：旋转观察</h4>
                      <p className="text-sm text-muted-foreground">
                        将画面旋转90度或180度观察，如果在任何角度都感觉稳定，说明平衡性好。
                      </p>
                    </div>
                    <div className="p-4 bg-muted/30 rounded-lg">
                      <h4 className="font-semibold mb-2">方法4：请他人评价</h4>
                      <p className="text-sm text-muted-foreground">
                        让同学或朋友看你的作品，问他们第一眼的感受是稳定还是不稳定。
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Tutorials Tab */}
              <TabsContent value="tutorials" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Canva构成创作技巧</CardTitle>
                    <CardDescription>如何在Canva中高效创作平衡构成</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ol className="space-y-3">
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">1</span>
                        <div>
                          <p className="font-medium">使用网格和参考线</p>
                          <p className="text-sm text-muted-foreground">打开网格视图，帮助你精确对齐元素，创建对称构成时特别有用</p>
                        </div>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">2</span>
                        <div>
                          <p className="font-medium">善用图层功能</p>
                          <p className="text-sm text-muted-foreground">将元素分层管理，方便调整前后关系和透明度</p>
                        </div>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">3</span>
                        <div>
                          <p className="font-medium">复制与镜像</p>
                          <p className="text-sm text-muted-foreground">创建对称构成时，先做一半，然后复制并水平翻转</p>
                        </div>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">4</span>
                        <div>
                          <p className="font-medium">调整透明度和混合模式</p>
                          <p className="text-sm text-muted-foreground">通过透明度创造层次感，使用混合模式产生特殊视觉效果</p>
                        </div>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">5</span>
                        <div>
                          <p className="font-medium">保存多个版本</p>
                          <p className="text-sm text-muted-foreground">在调整过程中保存不同版本，方便对比和回退</p>
                        </div>
                      </li>
                    </ol>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>视觉重量调节技巧</CardTitle>
                    <CardDescription>如何让非对称构成达到平衡</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2">大小对比</h4>
                        <p className="text-sm text-muted-foreground">
                          一个大元素可以用多个小元素平衡。例如：左侧一个大圆，右侧三个小圆。
                        </p>
                      </div>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2">颜色深浅</h4>
                        <p className="text-sm text-muted-foreground">
                          深色元素视觉重量大于浅色。一个小的深色块可以平衡一个大的浅色块。
                        </p>
                      </div>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2">位置距离</h4>
                        <p className="text-sm text-muted-foreground">
                          离中心越远的元素，视觉重量越大。小元素放在边缘可以平衡中心的大元素。
                        </p>
                      </div>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2">密度对比</h4>
                        <p className="text-sm text-muted-foreground">
                          密集的元素群可以平衡稀疏但体积大的元素。
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Theory Tab */}
              <TabsContent value="theory" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-2xl">平衡的三种基本类型</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-3">
                      <h3 className="text-xl font-semibold">对称平衡（Symmetrical Balance）</h3>
                      <p className="text-muted-foreground">
                        以中轴线为基准，左右两侧的元素在形状、大小、颜色、位置上完全相同或近似相同。
                      </p>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <p className="font-medium mb-2 text-sm">特点：</p>
                        <div className="space-y-1">
                          <p className="text-sm">✓ 稳定、庄重、正式</p>
                          <p className="text-sm">✓ 容易达成，视觉舒适</p>
                          <p className="text-sm">✓ 可能显得单调、缺乏变化</p>
                        </div>
                        <p className="font-medium mt-3 mb-2 text-sm">应用场景：</p>
                        <div className="flex flex-wrap gap-2">
                          <Badge variant="secondary">建筑立面</Badge>
                          <Badge variant="secondary">Logo设计</Badge>
                          <Badge variant="secondary">正式海报</Badge>
                          <Badge variant="secondary">传统艺术</Badge>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <h3 className="text-xl font-semibold">非对称平衡（Asymmetrical Balance）</h3>
                      <p className="text-muted-foreground">
                        左右两侧的元素在形式上不同，但通过大小、颜色、位置等因素的调整，达到视觉重量的平衡。
                      </p>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <p className="font-medium mb-2 text-sm">特点：</p>
                        <div className="space-y-1">
                          <p className="text-sm">✓ 动态、活泼、现代</p>
                          <p className="text-sm">✓ 富有变化和趣味性</p>
                          <p className="text-sm">✓ 需要更多设计经验和调整</p>
                        </div>
                        <p className="font-medium mt-3 mb-2 text-sm">应用场景：</p>
                        <div className="flex flex-wrap gap-2">
                          <Badge variant="secondary">现代网页</Badge>
                          <Badge variant="secondary">杂志排版</Badge>
                          <Badge variant="secondary">艺术海报</Badge>
                          <Badge variant="secondary">产品摄影</Badge>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <h3 className="text-xl font-semibold">放射平衡（Radial Balance）</h3>
                      <p className="text-muted-foreground">
                        元素从一个中心点向四周放射或围绕中心旋转，各个方向的视觉重量相等。
                      </p>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <p className="font-medium mb-2 text-sm">特点：</p>
                        <div className="space-y-1">
                          <p className="text-sm">✓ 强烈的中心感和向心力</p>
                          <p className="text-sm">✓ 动感、节奏感强</p>
                          <p className="text-sm">✓ 容易吸引视线聚焦</p>
                        </div>
                        <p className="font-medium mt-3 mb-2 text-sm">应用场景：</p>
                        <div className="flex flex-wrap gap-2">
                          <Badge variant="secondary">花窗图案</Badge>
                          <Badge variant="secondary">曼陀罗</Badge>
                          <Badge variant="secondary">Logo设计</Badge>
                          <Badge variant="secondary">装饰图案</Badge>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-2xl">影响视觉重量的因素</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="p-4 border-l-4 border-primary">
                        <h4 className="font-semibold mb-1">大小（Size）</h4>
                        <p className="text-sm text-muted-foreground">元素越大，视觉重量越大</p>
                      </div>
                      <div className="p-4 border-l-4 border-primary">
                        <h4 className="font-semibold mb-1">颜色（Color）</h4>
                        <p className="text-sm text-muted-foreground">深色、暖色、饱和度高的颜色视觉重量更大</p>
                      </div>
                      <div className="p-4 border-l-4 border-primary">
                        <h4 className="font-semibold mb-1">位置（Position）</h4>
                        <p className="text-sm text-muted-foreground">离中心越远、越靠近边缘的元素视觉重量越大</p>
                      </div>
                      <div className="p-4 border-l-4 border-primary">
                        <h4 className="font-semibold mb-1">密度（Density）</h4>
                        <p className="text-sm text-muted-foreground">元素越密集、细节越多，视觉重量越大</p>
                      </div>
                      <div className="p-4 border-l-4 border-primary">
                        <h4 className="font-semibold mb-1">形状（Shape）</h4>
                        <p className="text-sm text-muted-foreground">不规则、复杂的形状比规则、简单的形状视觉重量更大</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Examples Tab */}
              <TabsContent value="examples" className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>经典对称构成</CardTitle>
                      <CardDescription>蒙德里安风格的对称平衡</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="aspect-square bg-muted rounded-lg flex items-center justify-center mb-4">
                        <Image className="h-12 w-12 text-muted-foreground" />
                      </div>
                      <div className="p-3 bg-primary/5 rounded-lg">
                        <p className="text-sm">
                          <span className="font-medium">分析：</span>
                          垂直和水平线条将画面分割成对称的区域，色块的分布也呈现镜像对称，营造稳定感。
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>非对称平衡杰作</CardTitle>
                      <CardDescription>康定斯基的动态构成</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="aspect-square bg-muted rounded-lg flex items-center justify-center mb-4">
                        <Image className="h-12 w-12 text-muted-foreground" />
                      </div>
                      <div className="p-3 bg-primary/5 rounded-lg">
                        <p className="text-sm">
                          <span className="font-medium">分析：</span>
                          大小不一的几何形状通过位置和颜色的巧妙安排达到平衡，充满动感和张力。
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>放射平衡典范</CardTitle>
                      <CardDescription>哥特式玫瑰窗</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="aspect-square bg-muted rounded-lg flex items-center justify-center mb-4">
                        <Image className="h-12 w-12 text-muted-foreground" />
                      </div>
                      <div className="p-3 bg-primary/5 rounded-lg">
                        <p className="text-sm">
                          <span className="font-medium">分析：</span>
                          从中心向外放射的花瓣图案，每个方向的视觉重量相等，形成完美的放射平衡。
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>现代非对称设计</CardTitle>
                      <CardDescription>网页布局中的平衡应用</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="aspect-square bg-muted rounded-lg flex items-center justify-center mb-4">
                        <Image className="h-12 w-12 text-muted-foreground" />
                      </div>
                      <div className="p-3 bg-primary/5 rounded-lg">
                        <p className="text-sm">
                          <span className="font-medium">分析：</span>
                          左侧大图片与右侧多个小文本块形成平衡，现代而富有层次感。
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              {/* Works Tab */}
              <TabsContent value="works">
                <Card>
                  <CardHeader>
                    <CardTitle>优秀学生作业</CardTitle>
                    <CardDescription>查看往届学生的平衡构成作品</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-12 text-muted-foreground">
                      <Award className="h-16 w-16 mx-auto mb-4 opacity-50" />
                      <p>优秀作业正在收集整理中...</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Resources Tab */}
              <TabsContent value="resources" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>拓展资源</CardTitle>
                    <CardDescription>构成设计相关的参考资料和工具</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <a
                        href="https://www.canva.cn/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center space-x-3">
                          <Lightbulb className="h-5 w-5 text-primary" />
                          <span>Canva - 在线设计工具</span>
                        </div>
                        <ExternalLink className="h-4 w-4 text-muted-foreground" />
                      </a>
                      <a
                        href="https://www.zcool.com.cn/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center space-x-3">
                          <BookOpen className="h-5 w-5 text-primary" />
                          <span>站酷 - 设计作品参考</span>
                        </div>
                        <ExternalLink className="h-4 w-4 text-muted-foreground" />
                      </a>
                      <a
                        href="https://www.shejidaren.com/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center space-x-3">
                          <BookOpen className="h-5 w-5 text-primary" />
                          <span>设计达人 - 设计理论学习</span>
                        </div>
                        <ExternalLink className="h-4 w-4 text-muted-foreground" />
                      </a>
                    </div>
                  </CardContent>
                </Card>

                {/* Common Pitfalls */}
                <Card className="border-destructive/50">
                  <CardHeader>
                    <div className="flex items-center space-x-2">
                      <AlertCircle className="h-5 w-5 text-destructive" />
                      <CardTitle>常见问题</CardTitle>
                    </div>
                    <CardDescription>平衡构成中的常见错误</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex items-start space-x-2">
                          <span className="text-destructive font-bold">❌</span>
                          <p className="text-sm">元素过于分散：画面四处都有元素，没有重点，缺乏整体感</p>
                        </div>
                        <div className="flex items-start space-x-2 ml-6">
                          <span className="text-green-600 font-bold">✅</span>
                          <p className="text-sm font-medium text-green-600">集中布局，留出呼吸空间！</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-start space-x-2">
                          <span className="text-destructive font-bold">❌</span>
                          <p className="text-sm">对称过于僵硬：完全镜像对称，缺乏变化和趣味</p>
                        </div>
                        <div className="flex items-start space-x-2 ml-6">
                          <span className="text-green-600 font-bold">✅</span>
                          <p className="text-sm font-medium text-green-600">在对称中加入细微变化！</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-start space-x-2">
                          <span className="text-destructive font-bold">❌</span>
                          <p className="text-sm">非对称失衡：一侧过重，画面明显倾斜</p>
                        </div>
                        <div className="flex items-start space-x-2 ml-6">
                          <span className="text-green-600 font-bold">✅</span>
                          <p className="text-sm font-medium text-green-600">用眯眼测试检查平衡！</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-start space-x-2">
                          <span className="text-destructive font-bold">❌</span>
                          <p className="text-sm">放射中心不明确：看不出从哪里放射，缺乏向心力</p>
                        </div>
                        <div className="flex items-start space-x-2 ml-6">
                          <span className="text-green-600 font-bold">✅</span>
                          <p className="text-sm font-medium text-green-600">强化中心元素，明确放射方向！</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Next Steps */}
                <Card className="bg-primary/5 border-primary/20">
                  <CardHeader>
                    <CardTitle>下一步</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <p className="text-sm">太棒了！你已经掌握了平衡构成的基本原理和创作方法。</p>
                      <p className="text-sm">平衡不仅是视觉的，更是设计思维的体现——如何在变化中寻找稳定，在对比中创造和谐。</p>
                      <p className="text-sm">思考：在你的日常生活中，哪些设计运用了平衡原理？它们是对称还是非对称？</p>
                      <p className="text-sm">准备：接下来我们将学习更多构成规律，如节奏、韵律、对比等，让你的设计更加丰富多彩！</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>

            {/* Navigation */}
            <div className="flex justify-between mt-12 pt-8 border-t">
              <Link href="/curriculum/2">
                <Button variant="outline">
                  <ChevronLeft className="h-4 w-4 mr-2" />
                  上一节：触·材质发现
                </Button>
              </Link>
              <Link href="/curriculum">
                <Button>
                  返回课程大纲
                  <ChevronRight className="h-4 w-4 ml-2" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t py-8 bg-muted/30">
        <div className="container">
          <div className="text-center text-sm text-muted-foreground">
            <p>© 2025 数字设计构成课程</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

