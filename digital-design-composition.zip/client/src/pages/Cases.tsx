import Navigation from "@/components/Navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Construction } from "lucide-react";

export default function Cases() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1 py-12">
        <div className="container">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h1 className="text-4xl font-bold mb-4">案例库</h1>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                优秀学生作品和专业设计案例展示
              </p>
            </div>

            <Card className="max-w-2xl mx-auto">
              <CardHeader>
                <div className="flex justify-center mb-4">
                  <Construction className="h-16 w-16 text-muted-foreground" />
                </div>
                <CardTitle className="text-center">内容建设中</CardTitle>
                <CardDescription className="text-center">
                  案例库正在收集整理中，即将上线
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-sm text-muted-foreground">
                  <p>案例库将包含：</p>
                  <ul className="space-y-2 ml-4">
                    <li>• 按专业分类（环艺/产品/视传/数媒/公艺）</li>
                    <li>• 按构成原理分类（平面/色彩/空间）</li>
                    <li>• 按难度等级分类（Base/Advance/Stretch）</li>
                    <li>• 学生优秀作品展示</li>
                    <li>• 专业设计师作品参考</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <footer className="border-t py-8 bg-muted/30">
        <div className="container">
          <div className="text-center text-sm text-muted-foreground">
            <p>© 2025 数字设计构成课程</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

