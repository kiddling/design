import Navigation from "@/components/Navigation";
import DifficultyBadge, { DifficultyLevel } from "@/components/DifficultyBadge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ExternalLink } from "lucide-react";

interface KnowledgeCard {
  id: string;
  title: string;
  category: "plane" | "color" | "space";
  description: string;
  theory: string[];
  examples: string[];
  difficulty: DifficultyLevel;
  resources: { title: string; url: string }[];
}

const knowledgeCards: KnowledgeCard[] = [
  {
    id: "plane-point",
    title: "点的构成",
    category: "plane",
    description: "点是最基本的构成元素，具有位置、大小、形状等属性，可以产生聚集、发散、渐变等视觉效果。",
    theory: [
      "点的规律构成：按照一定规律排列的点可以形成秩序感",
      "点的自由构成：随机分布的点可以产生动态感和自然感",
      "点的线化构成：点的连续排列可以形成线的视觉效果",
      "点的面化构成：密集的点可以形成面的感觉"
    ],
    examples: [
      "波点艺术（草间弥生）",
      "像素艺术",
      "星空图案"
    ],
    difficulty: "Base",
    resources: [
      { title: "设计基础：点·线·面", url: "https://deerlight.design/basics-of-design-point-and-line-to-plane/" },
      { title: "UI设计基础理论篇之【点线面】", url: "https://zhuanlan.zhihu.com/p/430254732" }
    ]
  },
  {
    id: "plane-line",
    title: "线的构成",
    category: "plane",
    description: "线具有方向性、动态感和分割空间的作用，可以表达情绪和引导视线。",
    theory: [
      "直线：稳定、理性、力量感",
      "曲线：柔和、优雅、流动感",
      "折线：动态、节奏、变化感",
      "线的粗细、疏密、方向变化可以产生丰富的视觉效果"
    ],
    examples: [
      "蒙德里安的几何抽象",
      "等高线地图",
      "流线型设计"
    ],
    difficulty: "Base",
    resources: [
      { title: "点、线、面讲解，通俗易懂", url: "https://www.shejidaren.com/xiangjie-dian-xian-mian.html" }
    ]
  },
  {
    id: "plane-surface",
    title: "面的构成",
    category: "plane",
    description: "面是由线围合而成，具有形状、大小、位置等属性，是平面构成的主要元素。",
    theory: [
      "几何形：规则、理性、秩序感（圆形、方形、三角形等）",
      "有机形：自然、感性、生动感（不规则形状）",
      "面的重叠、透叠、分割可以产生空间感和层次感",
      "正负形：图形与背景的关系"
    ],
    examples: [
      "包豪斯海报设计",
      "剪纸艺术",
      "拼贴画"
    ],
    difficulty: "Advance",
    resources: [
      { title: "平面设计入门: 设计原理", url: "https://edu.gcfglobal.org/en/tr_zh-cn-beginning-graphic-design/-fundamentals-of-design/1/" }
    ]
  },
  {
    id: "color-theory",
    title: "色彩三要素",
    category: "color",
    description: "色相、明度、纯度是色彩的三个基本属性，理解它们是掌握色彩构成的基础。",
    theory: [
      "色相（Hue）：色彩的相貌，如红、橙、黄、绿、青、蓝、紫",
      "明度（Value）：色彩的明暗程度",
      "纯度（Saturation）：色彩的鲜艳程度",
      "三要素的变化可以产生无限的色彩组合"
    ],
    examples: [
      "色相环",
      "明度渐变",
      "饱和度对比"
    ],
    difficulty: "Base",
    resources: [
      { title: "基础知识：配色原理", url: "https://zhuanlan.zhihu.com/p/59899474" },
      { title: "Adobe Color工具", url: "https://color.adobe.com/" }
    ]
  },
  {
    id: "color-emotion",
    title: "色彩心理与情绪",
    category: "color",
    description: "不同的色彩会引发不同的心理感受和情绪反应，理解色彩心理学有助于设计中的情绪表达。",
    theory: [
      "暖色系（红、橙、黄）：温暖、兴奋、活力",
      "冷色系（蓝、绿、紫）：冷静、理性、宁静",
      "中性色（黑、白、灰）：平衡、专业、简约",
      "文化差异：不同文化对色彩的理解和情感联想可能不同"
    ],
    examples: [
      "品牌色彩策略",
      "电影色调设计",
      "空间氛围营造"
    ],
    difficulty: "Advance",
    resources: [
      { title: "色彩心理学的原理及应用", url: "https://zhuanlan.zhihu.com/p/579652250" },
      { title: "Color Psychology", url: "https://londonimageinstitute.com/how-to-empower-yourself-with-color-psychology/" }
    ]
  },
  {
    id: "color-harmony",
    title: "配色原理",
    category: "color",
    description: "掌握配色原理可以创造和谐、有层次的色彩组合。",
    theory: [
      "单色配色：使用同一色相的不同明度和纯度",
      "类似色配色：使用色相环上相邻的颜色",
      "互补色配色：使用色相环上相对的颜色，对比强烈",
      "三角配色：使用色相环上等距的三个颜色"
    ],
    examples: [
      "单色调海报",
      "互补色对比设计",
      "自然界的配色"
    ],
    difficulty: "Advance",
    resources: [
      { title: "设计配色完整攻略", url: "https://www.shutterstock.com/zh-Hant/blog/complete-guide-color-in-design" },
      { title: "设计色彩理论全解", url: "https://js.design/special/article/design-colour-theory.html" }
    ]
  },
  {
    id: "space-scale",
    title: "空间与尺度",
    category: "space",
    description: "空间的尺度关系影响人的感知和体验，理解尺度是空间设计的基础。",
    theory: [
      "人体尺度：以人的身体尺寸为参照",
      "空间尺度：空间的大小、高度、比例关系",
      "尺度对比：大小对比可以产生戏剧性效果",
      "模块化尺度：使用标准单元进行组合"
    ],
    examples: [
      "建筑空间设计",
      "家具人机工程学",
      "模块化建筑"
    ],
    difficulty: "Advance",
    resources: []
  },
  {
    id: "space-rhythm",
    title: "空间节奏",
    category: "space",
    description: "空间中的重复、渐变、韵律可以创造节奏感和秩序感。",
    theory: [
      "重复：相同元素的反复出现产生秩序感",
      "渐变：元素的逐渐变化产生动态感",
      "韵律：有规律的变化产生节奏感",
      "对比：强弱、大小、疏密的对比产生张力"
    ],
    examples: [
      "柱廊空间",
      "阶梯设计",
      "立面韵律"
    ],
    difficulty: "Stretch",
    resources: []
  }
];

const categories = {
  plane: { label: "平面构成", description: "探索点、线、面的构成原理与视觉表现" },
  color: { label: "色彩构成", description: "理解色彩理论、心理与配色方法" },
  space: { label: "空间构成", description: "掌握三维空间的尺度、节奏与秩序" }
};

export default function Knowledge() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1 py-12">
        <div className="container">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h1 className="text-4xl font-bold mb-4">知识卡片</h1>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                构成原理的理论要点、案例分析和实践练习
              </p>
            </div>

            <Tabs defaultValue="plane" className="space-y-8">
              <TabsList className="grid w-full grid-cols-3 max-w-2xl mx-auto">
                <TabsTrigger value="plane">平面构成</TabsTrigger>
                <TabsTrigger value="color">色彩构成</TabsTrigger>
                <TabsTrigger value="space">空间构成</TabsTrigger>
              </TabsList>

              {Object.entries(categories).map(([key, { label, description }]) => (
                <TabsContent key={key} value={key} className="space-y-6">
                  <div className="text-center mb-8">
                    <h2 className="text-2xl font-bold mb-2">{label}</h2>
                    <p className="text-muted-foreground">{description}</p>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    {knowledgeCards
                      .filter(card => card.category === key)
                      .map(card => (
                        <Card key={card.id} className="hover:shadow-lg transition-shadow">
                          <CardHeader>
                            <div className="flex items-start justify-between mb-2">
                              <CardTitle className="text-xl">{card.title}</CardTitle>
                              <DifficultyBadge level={card.difficulty} />
                            </div>
                            <CardDescription>{card.description}</CardDescription>
                          </CardHeader>
                          <CardContent className="space-y-4">
                            <div>
                              <h4 className="font-semibold mb-2 text-sm">理论要点</h4>
                              <ul className="space-y-1">
                                {card.theory.map((point, idx) => (
                                  <li key={idx} className="flex items-start space-x-2 text-sm">
                                    <span className="text-primary mt-1">•</span>
                                    <span>{point}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>

                            <div>
                              <h4 className="font-semibold mb-2 text-sm">案例参考</h4>
                              <div className="flex flex-wrap gap-2">
                                {card.examples.map((example, idx) => (
                                  <Badge key={idx} variant="secondary" className="text-xs">
                                    {example}
                                  </Badge>
                                ))}
                              </div>
                            </div>

                            {card.resources.length > 0 && (
                              <div>
                                <h4 className="font-semibold mb-2 text-sm">拓展资源</h4>
                                <div className="space-y-1">
                                  {card.resources.map((resource, idx) => (
                                    <a
                                      key={idx}
                                      href={resource.url}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="flex items-center space-x-1 text-sm text-primary hover:underline"
                                    >
                                      <ExternalLink className="h-3 w-3" />
                                      <span>{resource.title}</span>
                                    </a>
                                  ))}
                                </div>
                              </div>
                            )}
                          </CardContent>
                        </Card>
                      ))}
                  </div>
                </TabsContent>
              ))}
            </Tabs>
          </div>
        </div>
      </main>

      <footer className="border-t py-8 bg-muted/30">
        <div className="container">
          <div className="text-center text-sm text-muted-foreground">
            <p>© 2025 数字设计构成课程</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

