import Navigation from "@/components/Navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Target, 
  BookOpen, 
  Lightbulb, 
  Image, 
  Award, 
  ExternalLink, 
  ChevronLeft, 
  ChevronRight,
  Palette,
  Heart,
  Eye,
  AlertCircle,
  Sparkles
} from "lucide-react";
import { Link } from "wouter";

export default function Lesson06() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1 py-8">
        <div className="container">
          <div className="max-w-6xl mx-auto">
            {/* Header */}
            <div className="mb-8">
              <Link href="/curriculum">
                <Button variant="ghost" className="mb-4">
                  <ChevronLeft className="h-4 w-4 mr-2" />
                  返回课程大纲
                </Button>
              </Link>
              
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <Badge>第6节</Badge>
                    <Badge variant="outline">3小时</Badge>
                    <Badge variant="outline">课前20分钟 + 课中90分钟</Badge>
                  </div>
                  <h1 className="text-4xl font-bold mb-2">色·情感联想</h1>
                  <p className="text-xl text-muted-foreground">Color and Emotion</p>
                </div>
              </div>
            </div>

            {/* Learning Objectives */}
            <Card className="mb-8">
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <Target className="h-5 w-5 text-primary" />
                  <CardTitle>学习目标</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span>理解色彩三要素：色相、明度、饱和度</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span>掌握色彩心理学：不同颜色的情感联想和文化含义</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span>学会运用配色原理：对比色、邻近色、三角色、互补色</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span>培养色彩敏感度，能够用色彩表达特定情感和氛围</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Main Content Tabs */}
            <Tabs defaultValue="tasks" className="space-y-6">
              <TabsList className="grid w-full grid-cols-6">
                <TabsTrigger value="tasks">
                  <Palette className="h-4 w-4 mr-2" />
                  任务卡片
                </TabsTrigger>
                <TabsTrigger value="tutorials">
                  <Sparkles className="h-4 w-4 mr-2" />
                  教程
                </TabsTrigger>
                <TabsTrigger value="theory">
                  <BookOpen className="h-4 w-4 mr-2" />
                  理论
                </TabsTrigger>
                <TabsTrigger value="examples">
                  <Image className="h-4 w-4 mr-2" />
                  案例
                </TabsTrigger>
                <TabsTrigger value="works">
                  <Award className="h-4 w-4 mr-2" />
                  优秀作业
                </TabsTrigger>
                <TabsTrigger value="resources">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  拓展
                </TabsTrigger>
              </TabsList>

              {/* Tasks Tab */}
              <TabsContent value="tasks" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-2xl">色彩的情感力量</CardTitle>
                    <CardDescription className="text-base">
                      色彩是最直接的情感语言！红色让人兴奋，蓝色让人平静，黄色让人愉悦。这节课，我们要学习
                      如何用色彩表达情感、营造氛围、传递信息，让设计作品更有感染力。
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Task 1 */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-lg flex items-center space-x-2">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground text-sm">1</span>
                        <span>任务1：单色情感表达（Base难度）</span>
                      </h4>
                      <p className="text-muted-foreground ml-8">
                        选择一种颜色，通过改变明度和饱和度，创作一幅表达特定情感的构成。
                      </p>
                      <div className="ml-8 p-4 bg-muted/50 rounded-lg">
                        <p className="font-medium mb-2 text-sm">💡 创作要求：</p>
                        <ul className="space-y-1">
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>画布尺寸：正方形（如1080x1080px）</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>选择一种基础色相（如红/蓝/黄/绿）</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>确定要表达的情感（如快乐/悲伤/平静/激动）</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>通过调整明度和饱和度创造5-7个色阶</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>用几何形状组合，表现情感的强度和节奏</span>
                          </li>
                        </ul>
                      </div>
                    </div>

                    {/* Task 2 */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-lg flex items-center space-x-2">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground text-sm">2</span>
                        <span>任务2：对比色情感冲突（Advance难度）</span>
                      </h4>
                      <p className="text-muted-foreground ml-8">
                        使用对比色或互补色，创作一幅表现情感冲突或对立的构成。
                      </p>
                      <div className="ml-8 p-4 bg-muted/50 rounded-lg">
                        <p className="font-medium mb-2 text-sm">💡 创作要求：</p>
                        <ul className="space-y-1">
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>画布尺寸：横向矩形</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>选择一对互补色（如红-绿/蓝-橙/黄-紫）</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>表现对立的情感（如冷-暖/动-静/喜-悲）</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>通过面积、位置、形状创造视觉张力</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>可以添加中性色（黑/白/灰）调和或强化对比</span>
                          </li>
                        </ul>
                      </div>
                    </div>

                    {/* Task 3 */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-lg flex items-center space-x-2">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground text-sm">3</span>
                        <span>任务3：多色氛围叙事（Stretch难度）</span>
                      </h4>
                      <p className="text-muted-foreground ml-8">
                        使用3-5种颜色，创作一幅具有叙事性和氛围感的复杂配色构成。
                      </p>
                      <div className="ml-8 p-4 bg-muted/50 rounded-lg">
                        <p className="font-medium mb-2 text-sm">💡 创作要求：</p>
                        <ul className="space-y-1">
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>画布尺寸：自由选择</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>选择一个主题场景（如日出/雨夜/森林/城市）</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>建立主色调，确定整体氛围（暖/冷/明亮/暗沉）</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>运用邻近色或类似色创造和谐感</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>添加少量对比色作为视觉焦点</span>
                          </li>
                          <li className="text-sm flex items-start space-x-2">
                            <span className="text-primary mt-0.5">→</span>
                            <span>通过色彩渐变和过渡讲述故事或表达情绪变化</span>
                          </li>
                        </ul>
                      </div>
                    </div>

                    {/* Workflow */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-lg flex items-center space-x-2">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground text-sm">4</span>
                        <span>工作流程</span>
                      </h4>
                      <div className="ml-8 space-y-2">
                        <div className="p-3 bg-primary/5 rounded-lg">
                          <p className="font-medium text-sm mb-1">步骤1：确定情感目标</p>
                          <p className="text-sm text-muted-foreground">明确你想表达的情感或氛围：快乐、悲伤、平静、激动、神秘...</p>
                        </div>
                        <div className="p-3 bg-primary/5 rounded-lg">
                          <p className="font-medium text-sm mb-1">步骤2：选择主色调</p>
                          <p className="text-sm text-muted-foreground">根据情感目标选择合适的色相和色温（暖色/冷色）</p>
                        </div>
                        <div className="p-3 bg-primary/5 rounded-lg">
                          <p className="font-medium text-sm mb-1">步骤3：建立配色方案</p>
                          <p className="text-sm text-muted-foreground">确定配色关系（单色/邻近色/对比色/互补色），调整明度和饱和度</p>
                        </div>
                        <div className="p-3 bg-primary/5 rounded-lg">
                          <p className="font-medium text-sm mb-1">步骤4：测试和调整</p>
                          <p className="text-sm text-muted-foreground">观察整体效果，调整色彩比例和强度，确保情感表达准确</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Color Sensitivity Training */}
                <Card className="border-2 border-primary/20">
                  <CardHeader>
                    <div className="flex items-center space-x-2">
                      <Eye className="h-5 w-5 text-primary" />
                      <CardTitle>色彩敏感度训练</CardTitle>
                    </div>
                    <CardDescription>
                      如何培养对色彩的感知力？
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="p-4 bg-muted/30 rounded-lg">
                      <h4 className="font-semibold mb-2">练习1：色彩情绪日记</h4>
                      <p className="text-sm text-muted-foreground">
                        每天记录让你印象深刻的颜色，思考它给你的感觉：温暖、冰冷、舒适、压抑...
                      </p>
                    </div>
                    <div className="p-4 bg-muted/30 rounded-lg">
                      <h4 className="font-semibold mb-2">练习2：色彩联想游戏</h4>
                      <p className="text-sm text-muted-foreground">
                        看到一种颜色，快速联想3个词：红色→热情、危险、喜庆；蓝色→平静、理性、忧郁。
                      </p>
                    </div>
                    <div className="p-4 bg-muted/30 rounded-lg">
                      <h4 className="font-semibold mb-2">练习3：观察配色实例</h4>
                      <p className="text-sm text-muted-foreground">
                        分析电影海报、品牌logo、艺术作品的配色，思考为什么这样配色，传达了什么情感。
                      </p>
                    </div>
                    <div className="p-4 bg-muted/30 rounded-lg">
                      <h4 className="font-semibold mb-2">练习4：色彩对比实验</h4>
                      <p className="text-sm text-muted-foreground">
                        同一个颜色放在不同背景上，感受会完全不同。尝试改变背景色，观察色彩的变化。
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Tutorials Tab */}
              <TabsContent value="tutorials" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Canva配色技巧</CardTitle>
                    <CardDescription>如何在Canva中创建和谐的配色方案</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ol className="space-y-3">
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">1</span>
                        <div>
                          <p className="font-medium">使用色轮工具</p>
                          <p className="text-sm text-muted-foreground">Canva内置色轮，可以快速找到互补色、邻近色、三角色等配色方案。</p>
                        </div>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">2</span>
                        <div>
                          <p className="font-medium">提取图片配色</p>
                          <p className="text-sm text-muted-foreground">上传一张喜欢的图片，Canva会自动提取主要颜色，生成调色板。</p>
                        </div>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">3</span>
                        <div>
                          <p className="font-medium">保存调色板</p>
                          <p className="text-sm text-muted-foreground">创建自己的品牌调色板，保存常用颜色，保持设计一致性。</p>
                        </div>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">4</span>
                        <div>
                          <p className="font-medium">调整色彩参数</p>
                          <p className="text-sm text-muted-foreground">使用HSB模式（色相/饱和度/明度）精确调整颜色，创造微妙的色彩变化。</p>
                        </div>
                      </li>
                      <li className="flex items-start space-x-3">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary text-sm font-medium flex-shrink-0">5</span>
                        <div>
                          <p className="font-medium">应用渐变效果</p>
                          <p className="text-sm text-muted-foreground">使用渐变工具创造色彩过渡，让配色更柔和、更有层次感。</p>
                        </div>
                      </li>
                    </ol>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>配色实用技巧</CardTitle>
                    <CardDescription>让你的配色更专业</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2">技巧1：60-30-10法则</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          主色占60%，辅助色占30%，强调色占10%。这是最经典的配色比例。
                        </p>
                        <p className="text-xs text-muted-foreground">
                          例如：蓝色背景60% + 白色内容30% + 橙色按钮10%
                        </p>
                      </div>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2">技巧2：降低饱和度</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          高饱和度的颜色很刺眼。适当降低饱和度，让配色更柔和、更高级。
                        </p>
                        <p className="text-xs text-muted-foreground">
                          纯红色太刺眼，降低饱和度变成砖红色更舒适
                        </p>
                      </div>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2">技巧3：统一色温</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          暖色系（红橙黄）或冷色系（蓝绿紫）统一使用，避免色温混乱。
                        </p>
                        <p className="text-xs text-muted-foreground">
                          除非刻意制造对比，否则不要混用暖色和冷色
                        </p>
                      </div>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2">技巧4：使用中性色过渡</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          黑白灰是万能色，可以调和任何配色，让画面更平衡。
                        </p>
                        <p className="text-xs text-muted-foreground">
                          强烈的对比色之间加入灰色过渡，减少视觉冲击
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Theory Tab */}
              <TabsContent value="theory" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-2xl">色彩三要素</CardTitle>
                    <CardDescription>理解色彩的基本属性</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <p className="text-muted-foreground">
                      任何颜色都可以用三个属性来描述：色相、明度、饱和度。掌握这三个要素，就能精确控制色彩。
                    </p>

                    <div className="space-y-4">
                      <div className="p-4 border-l-4 border-red-500">
                        <h4 className="font-semibold mb-1">1. 色相（Hue）</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          色彩的相貌，即我们说的"什么颜色"：红、橙、黄、绿、蓝、紫等。
                        </p>
                        <p className="text-xs text-muted-foreground">
                          色相环：12种基本色相按照彩虹顺序排列成圆环，相邻的是邻近色，相对的是互补色。
                        </p>
                      </div>

                      <div className="p-4 border-l-4 border-gray-500">
                        <h4 className="font-semibold mb-1">2. 明度（Value/Lightness）</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          色彩的明暗程度，从黑到白的变化。明度高的颜色看起来更亮，明度低的更暗。
                        </p>
                        <p className="text-xs text-muted-foreground">
                          同一色相，加白色提高明度（粉红），加黑色降低明度（深红）。
                        </p>
                      </div>

                      <div className="p-4 border-l-4 border-blue-500">
                        <h4 className="font-semibold mb-1">3. 饱和度（Saturation/Chroma）</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          色彩的纯度和鲜艳程度。饱和度高的颜色鲜艳、纯净，饱和度低的颜色灰暗、柔和。
                        </p>
                        <p className="text-xs text-muted-foreground">
                          加入灰色降低饱和度，颜色会变得更柔和、更高级。
                        </p>
                      </div>
                    </div>

                    <div className="p-4 bg-primary/5 rounded-lg">
                      <p className="text-sm font-medium mb-2">💡 实用技巧：</p>
                      <ul className="space-y-1 text-sm text-muted-foreground">
                        <li>• 改变色相 → 改变情感（红色激情，蓝色平静）</li>
                        <li>• 改变明度 → 改变重量感（明亮轻盈，暗沉厚重）</li>
                        <li>• 改变饱和度 → 改变精致度（高饱和活泼，低饱和优雅）</li>
                      </ul>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-2xl">色彩心理学</CardTitle>
                    <CardDescription>不同颜色的情感联想</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="p-4 bg-red-50 border-l-4 border-red-500 rounded-lg">
                        <h4 className="font-semibold mb-2 text-red-700">🔴 红色</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          热情、激动、危险、力量、爱情、喜庆
                        </p>
                        <p className="text-xs text-muted-foreground">
                          应用：餐饮（刺激食欲）、促销（紧迫感）、警告标识
                        </p>
                      </div>

                      <div className="p-4 bg-orange-50 border-l-4 border-orange-500 rounded-lg">
                        <h4 className="font-semibold mb-2 text-orange-700">🟠 橙色</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          活力、温暖、友好、创意、乐观
                        </p>
                        <p className="text-xs text-muted-foreground">
                          应用：儿童产品、运动品牌、创意行业
                        </p>
                      </div>

                      <div className="p-4 bg-yellow-50 border-l-4 border-yellow-500 rounded-lg">
                        <h4 className="font-semibold mb-2 text-yellow-700">🟡 黄色</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          快乐、阳光、希望、警示、轻快
                        </p>
                        <p className="text-xs text-muted-foreground">
                          应用：儿童教育、快餐品牌、警示标识
                        </p>
                      </div>

                      <div className="p-4 bg-green-50 border-l-4 border-green-500 rounded-lg">
                        <h4 className="font-semibold mb-2 text-green-700">🟢 绿色</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          自然、健康、平衡、成长、安全
                        </p>
                        <p className="text-xs text-muted-foreground">
                          应用：环保产品、医疗健康、金融（安全感）
                        </p>
                      </div>

                      <div className="p-4 bg-blue-50 border-l-4 border-blue-500 rounded-lg">
                        <h4 className="font-semibold mb-2 text-blue-700">🔵 蓝色</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          平静、理性、信任、专业、忧郁
                        </p>
                        <p className="text-xs text-muted-foreground">
                          应用：科技公司、金融机构、医疗行业
                        </p>
                      </div>

                      <div className="p-4 bg-purple-50 border-l-4 border-purple-500 rounded-lg">
                        <h4 className="font-semibold mb-2 text-purple-700">🟣 紫色</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          神秘、高贵、浪漫、创意、奢华
                        </p>
                        <p className="text-xs text-muted-foreground">
                          应用：奢侈品、美容产品、艺术设计
                        </p>
                      </div>

                      <div className="p-4 bg-pink-50 border-l-4 border-pink-500 rounded-lg">
                        <h4 className="font-semibold mb-2 text-pink-700">🩷 粉色</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          温柔、甜美、浪漫、少女、关怀
                        </p>
                        <p className="text-xs text-muted-foreground">
                          应用：女性产品、母婴用品、甜品品牌
                        </p>
                      </div>

                      <div className="p-4 bg-gray-50 border-l-4 border-gray-500 rounded-lg">
                        <h4 className="font-semibold mb-2 text-gray-700">⚫ 黑白灰</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          黑：高级、神秘、权威；白：纯净、简洁、现代；灰：中性、稳重、优雅
                        </p>
                        <p className="text-xs text-muted-foreground">
                          应用：奢侈品牌、极简设计、专业服务
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-2xl">配色原理</CardTitle>
                    <CardDescription>常用的配色方法</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2">1. 单色配色（Monochromatic）</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          使用同一色相，通过改变明度和饱和度创造层次。
                        </p>
                        <div className="flex items-center space-x-2 mt-2">
                          <Badge variant="secondary">统一和谐</Badge>
                          <Badge variant="secondary">简洁优雅</Badge>
                          <Badge variant="secondary">易于掌握</Badge>
                        </div>
                      </div>

                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2">2. 邻近色配色（Analogous）</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          使用色轮上相邻的2-3种颜色，如黄-橙-红，蓝-蓝绿-绿。
                        </p>
                        <div className="flex items-center space-x-2 mt-2">
                          <Badge variant="secondary">自然和谐</Badge>
                          <Badge variant="secondary">柔和舒适</Badge>
                          <Badge variant="secondary">有层次感</Badge>
                        </div>
                      </div>

                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2">3. 互补色配色（Complementary）</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          使用色轮上相对的两种颜色，如红-绿，蓝-橙，黄-紫。
                        </p>
                        <div className="flex items-center space-x-2 mt-2">
                          <Badge variant="secondary">强烈对比</Badge>
                          <Badge variant="secondary">视觉冲击</Badge>
                          <Badge variant="secondary">活力动感</Badge>
                        </div>
                      </div>

                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2">4. 三角色配色（Triadic）</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          使用色轮上等距的三种颜色，如红-黄-蓝，橙-绿-紫。
                        </p>
                        <div className="flex items-center space-x-2 mt-2">
                          <Badge variant="secondary">丰富多彩</Badge>
                          <Badge variant="secondary">平衡活泼</Badge>
                          <Badge variant="secondary">视觉丰富</Badge>
                        </div>
                      </div>

                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold mb-2">5. 分裂互补色配色（Split-Complementary）</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          选一个基色，再选其互补色两侧的颜色，如蓝+橙红+橙黄。
                        </p>
                        <div className="flex items-center space-x-2 mt-2">
                          <Badge variant="secondary">对比柔和</Badge>
                          <Badge variant="secondary">层次丰富</Badge>
                          <Badge variant="secondary">不易出错</Badge>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Examples Tab */}
              <TabsContent value="examples" className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>蒙德里安的几何抽象</CardTitle>
                      <CardDescription>三原色+黑白灰</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="aspect-square bg-muted rounded-lg flex items-center justify-center mb-4">
                        <Image className="h-12 w-12 text-muted-foreground" />
                      </div>
                      <div className="p-3 bg-primary/5 rounded-lg">
                        <p className="text-sm">
                          <span className="font-medium">分析：</span>
                          使用红黄蓝三原色+黑白灰，简洁有力，表现理性、秩序、现代感。色块面积不同，创造视觉平衡。
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>梵高《星空》</CardTitle>
                      <CardDescription>蓝黄对比</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="aspect-square bg-muted rounded-lg flex items-center justify-center mb-4">
                        <Image className="h-12 w-12 text-muted-foreground" />
                      </div>
                      <div className="p-3 bg-primary/5 rounded-lg">
                        <p className="text-sm">
                          <span className="font-medium">分析：</span>
                          深蓝夜空与金黄星光形成强烈对比，表现梦幻、激动、不安的情绪。冷暖对比创造戏剧张力。
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>可口可乐品牌色</CardTitle>
                      <CardDescription>红白配色</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="aspect-square bg-muted rounded-lg flex items-center justify-center mb-4">
                        <Image className="h-12 w-12 text-muted-foreground" />
                      </div>
                      <div className="p-3 bg-primary/5 rounded-lg">
                        <p className="text-sm">
                          <span className="font-medium">分析：</span>
                          经典的红白配色，红色代表热情、活力、快乐，白色增加清爽感。简单但极具辨识度和感染力。
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Instagram渐变logo</CardTitle>
                      <CardDescription>彩虹渐变</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="aspect-square bg-muted rounded-lg flex items-center justify-center mb-4">
                        <Image className="h-12 w-12 text-muted-foreground" />
                      </div>
                      <div className="p-3 bg-primary/5 rounded-lg">
                        <p className="text-sm">
                          <span className="font-medium">分析：</span>
                          从紫到粉到橙到黄的渐变，表现多彩、创意、年轻、活力。渐变让色彩过渡自然，充满现代感。
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              {/* Works Tab */}
              <TabsContent value="works">
                <Card>
                  <CardHeader>
                    <CardTitle>优秀学生作业</CardTitle>
                    <CardDescription>查看往届学生的色彩构成作品</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-12 text-muted-foreground">
                      <Award className="h-16 w-16 mx-auto mb-4 opacity-50" />
                      <p>优秀作业正在收集整理中...</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Resources Tab */}
              <TabsContent value="resources" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>拓展资源</CardTitle>
                    <CardDescription>色彩设计相关的参考资料和工具</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <a
                        href="https://www.canva.cn/colors/color-wheel/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center space-x-3">
                          <Palette className="h-5 w-5 text-primary" />
                          <span>Canva色轮 - 配色方案生成器</span>
                        </div>
                        <ExternalLink className="h-4 w-4 text-muted-foreground" />
                      </a>
                      <a
                        href="https://color.adobe.com/zh/create/color-wheel"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center space-x-3">
                          <Palette className="h-5 w-5 text-primary" />
                          <span>Adobe Color - 专业配色工具</span>
                        </div>
                        <ExternalLink className="h-4 w-4 text-muted-foreground" />
                      </a>
                      <a
                        href="https://www.zcool.com.cn/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center space-x-3">
                          <BookOpen className="h-5 w-5 text-primary" />
                          <span>站酷 - 色彩设计作品参考</span>
                        </div>
                        <ExternalLink className="h-4 w-4 text-muted-foreground" />
                      </a>
                    </div>
                  </CardContent>
                </Card>

                {/* Common Pitfalls */}
                <Card className="border-destructive/50">
                  <CardHeader>
                    <div className="flex items-center space-x-2">
                      <AlertCircle className="h-5 w-5 text-destructive" />
                      <CardTitle>常见问题</CardTitle>
                    </div>
                    <CardDescription>配色中的常见错误</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex items-start space-x-2">
                          <span className="text-destructive font-bold">❌</span>
                          <p className="text-sm">颜色太多：使用超过5种主要颜色，画面混乱</p>
                        </div>
                        <div className="flex items-start space-x-2 ml-6">
                          <span className="text-green-600 font-bold">✅</span>
                          <p className="text-sm font-medium text-green-600">限制在3-4种主要颜色！</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-start space-x-2">
                          <span className="text-destructive font-bold">❌</span>
                          <p className="text-sm">饱和度过高：所有颜色都是纯色，刺眼不舒服</p>
                        </div>
                        <div className="flex items-start space-x-2 ml-6">
                          <span className="text-green-600 font-bold">✅</span>
                          <p className="text-sm font-medium text-green-600">适当降低饱和度，更优雅！</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-start space-x-2">
                          <span className="text-destructive font-bold">❌</span>
                          <p className="text-sm">对比不足：颜色太相似，缺乏层次和焦点</p>
                        </div>
                        <div className="flex items-start space-x-2 ml-6">
                          <span className="text-green-600 font-bold">✅</span>
                          <p className="text-sm font-medium text-green-600">增加明度或色相对比！</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-start space-x-2">
                          <span className="text-destructive font-bold">❌</span>
                          <p className="text-sm">忽视文化差异：不同文化对颜色的理解不同</p>
                        </div>
                        <div className="flex items-start space-x-2 ml-6">
                          <span className="text-green-600 font-bold">✅</span>
                          <p className="text-sm font-medium text-green-600">了解目标受众的文化背景！</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Next Steps */}
                <Card className="bg-primary/5 border-primary/20">
                  <CardHeader>
                    <CardTitle>下一步</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <p className="text-sm">恭喜！你已经掌握了色彩的基本理论和配色方法。</p>
                      <p className="text-sm">色彩是设计师最强大的武器——它能瞬间传递情感、建立氛围、影响决策。</p>
                      <p className="text-sm">思考：你最喜欢的颜色是什么？它给你什么感觉？为什么？</p>
                      <p className="text-sm">准备：接下来我们将进入第二轮迭代，学习更高级的设计技法！</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>

            {/* Navigation */}
            <div className="flex justify-between mt-12 pt-8 border-t">
              <Link href="/curriculum/5">
                <Button variant="outline">
                  <ChevronLeft className="h-4 w-4 mr-2" />
                  上一节：光·明暗表现
                </Button>
              </Link>
              <Link href="/curriculum">
                <Button>
                  返回课程大纲
                  <ChevronRight className="h-4 w-4 ml-2" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t py-8 bg-muted/30">
        <div className="container">
          <div className="text-center text-sm text-muted-foreground">
            <p>© 2025 数字设计构成课程</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

