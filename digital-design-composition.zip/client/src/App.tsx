import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Curriculum from "./pages/Curriculum";
import Knowledge from "./pages/Knowledge";
import Cases from "./pages/Cases";
import Resources from "./pages/Resources";
import LessonDetail from "./pages/LessonDetail";
import Lesson02 from "./pages/Lesson02";
import Lesson03 from "./pages/Lesson03";
import Lesson04 from "./pages/Lesson04";
import Lesson05 from "./pages/Lesson05";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/curriculum"} component={Curriculum} />
      <Route path={"/knowledge"} component={Knowledge} />
      <Route path={"/cases"} component={Cases} />
      <Route path={"/resources"} component={Resources} />
      <Route path="/curriculum/1" component={LessonDetail} />
      <Route path="/curriculum/2" component={Lesson02} />
      <Route path="/curriculum/3" component={Lesson03} />
      <Route path="/curriculum/4" component={Lesson04} />
      <Route path="/curriculum/5" component={Lesson05} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
